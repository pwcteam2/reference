package com.monitor.exception;

import org.joda.time.DateTime;

/**
 * This class will be used to generate json out of objects as by ObjectMapper.
 * We are using it because while using a container like tomcat, when thrown
 * exception in Spring filter like CustomFilter, it is returning Html response.
 * But we need a json response.	
 * 
 * @author Wittybrains
 *
 */
public class RestException {

	private long timestamp;
	
	private int status;
	
	private String exception;
	
	private String message;
	
	private String path;

	public RestException(String message, String path) {
		this.timestamp = DateTime.now().getMillis();
		this.status = 500;
		this.exception = this.getClass().getName();
		this.message = message;
		this.path = path;
	}

	/**
	 * @return the timestamp
	 */
	public long getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(int status) {
		this.status = status;
	}

	/**
	 * @return the exception
	 */
	public String getException() {
		return exception;
	}

	/**
	 * @param exception the exception to set
	 */
	public void setException(String exception) {
		this.exception = exception;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the path
	 */
	public String getPath() {
		return path;
	}

	/**
	 * @param path the path to set
	 */
	public void setPath(String path) {
		this.path = path;
	}
	
}
