package com.monitor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.monitor.domain.MonitorSheetHistory;

@Repository
public interface MonitorSheetHistoryRepository extends JpaRepository<MonitorSheetHistory, Long>{

	public List<MonitorSheetHistory> findAll();
	
	public MonitorSheetHistory findByMonitorSheetHistoryId(Long monitorSheetHistoryId);
}
