package com.monitor.repository;

import java.sql.Time;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.monitor.domain.Shift;

public interface ShiftRepository extends JpaRepository<Shift, Long>{

	public List<Shift> findAll();
	
	public Shift findByShiftId(long shiftId);
	
	public List<Shift> findByShiftIdIn(Long[] shiftId);
	
	public Shift findByStartTimeGreaterThanEqualAndEndTimeLessThanEqual(
			Time startTime,Time endTime);
}
