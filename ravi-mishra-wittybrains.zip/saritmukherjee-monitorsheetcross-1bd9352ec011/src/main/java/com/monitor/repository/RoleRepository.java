package com.monitor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;




import com.monitor.domain.Role;


public interface RoleRepository extends JpaRepository<Role, Long> {
	
	
	/**
	 * Find by id
	 * @param id
	 * @return Role
	 */
	Role findByRoleId(Integer RoleId);
	
	/**
	 * Find all roles
	 * @return Roles
	 */
	List<Role> findAll();
		

}
