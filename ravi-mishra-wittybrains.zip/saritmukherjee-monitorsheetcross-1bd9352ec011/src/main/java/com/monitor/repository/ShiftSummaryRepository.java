package com.monitor.repository;

import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.monitor.domain.Shift;
import com.monitor.domain.ShiftSummary;

public interface ShiftSummaryRepository extends JpaRepository<ShiftSummary, Long>{

	public List<ShiftSummary> findAll();
	
	public ShiftSummary findByShiftSummaryId(long shiftSummaryId);
	
	public ShiftSummary findByShiftShiftIdAndShiftDate(Long shiftId,DateTime ShiftDate);
	
	public List<ShiftSummary> findByShiftShiftIdInAndShiftDateBetweenOrderByShiftDate(List<Long> shiftId, DateTime startDate,DateTime endDate);

	public ShiftSummary findByShiftAndShiftDate(Shift shift,DateTime date);

	@Query(value="Select count(*)  from ShiftSummary s where s.shift.shiftId = (:shiftId) and s.shiftDate = (:shiftDate) and s.approved = (:approved)")
	public Long getUnapprovedCountByShiftAndCreatedDateAndApproved(@Param("shiftId") long shiftId,@Param("shiftDate") DateTime shiftDate,@Param("approved") boolean approved);

	@Query(value="Select count(*)  from ShiftSummary s where s.shift.shiftId = (:shiftId) and s.shiftDate = (:shiftDate)")
	public Long checkIfEntriesExist(@Param("shiftId") long shiftId,@Param("shiftDate") DateTime shiftDate);
}
