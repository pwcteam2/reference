package com.monitor.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.monitor.domain.Category;
import com.monitor.domain.SubCategory;

public interface SubCategoryRepository extends JpaRepository<SubCategory, Long> {

	/**
	 * Find by id
	 * 
	 * @param id
	 * @return SubCategory
	 */
	public SubCategory findBySubCategoryId(Long subCategoryId);

	/**
	 * Find by SubCategoryName
	 * 
	 * @param SubCategoryName
	 * @return SubCategory
	 */
	public SubCategory findBySubCategoryNameAndCategoryCategoryId(String subCategoryName,Long CategoryId);

	/**
	 * Find by categoryId
	 * 
	 * @param categoryId
	 * @return SubCategory
	 */
	public List<SubCategory> findByCategoryCategoryId(Long categoryId);
	
	/**
	 * Find all Category
	 * 
	 * @return Category
	 */
	public Set<SubCategory> findAllByOrderBySubCategoryNameAsc();

	/**
	 * Count by Category
	 * 
	 * @return count
	 */

	public long countByCategory(Category category);

	@Query(value = "SELECT * FROM sub_category sc join category c on sc.category_id = c.category_id where pod_id = :podId and sc.disabled = :disabled", nativeQuery = true)
	public Set<SubCategory> findByCategoryPodPodIdAndDisabledOrderByCategoryNameAsc(@Param("podId") Long podId,@Param("disabled") boolean disabled);

	public Long countByCategoryPodPodIdAndDisabled(Long podId, Boolean disabled);
}
