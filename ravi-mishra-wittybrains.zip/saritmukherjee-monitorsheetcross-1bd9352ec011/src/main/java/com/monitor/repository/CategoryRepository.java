package com.monitor.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.monitor.domain.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {

	/**
	 * Find by id
	 * 
	 * @param id
	 * @return Category
	 */
	public Category findByCategoryId(Long categoryId);

	/**
	 * Find by CategoryName
	 * 
	 * @param CategoryName
	 * @return Category
	 */
	public Category findByCategoryName(String CategoryName);

	/**
	 * Find by CategoryName and pod
	 * 
	 * @param CategoryName
	 * @return Category
	 */
	public Category findByCategoryNameAndPodPodId(String CategoryName,Long podId);

	/**
	 * Find all Category by pod
	 * 
	 * @return Category
	 */
	public Set<Category> findByPodPodIdOrderByCreatedDateAsc(Long podId);
	
	/**Find all categories and the disable state given.
	 * @param podId
	 * @param disabled
	 * @return
	 */
	public Set<Category> findByPodPodIdAndDisabledOrderByCreatedDateAsc(Long podId, boolean disabled);
	
	public Long countByPodPodIdAndDisabled(Long podId, Boolean disabled);

	public Long countByPodPodId(Long podId);

}
