package com.monitor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.monitor.domain.User;

public interface UserRepositiry extends JpaRepository<User, Long> {

	public User findByUserIdAndActiveAndDeleted(long userId,boolean active,boolean deleted);
	
	public List<User> findAll();
	
	public User findByEmail(String email);
	
	public User findByEmployeeCode(String employeeCode);
	
	public User findByUserId(long userId);
	
}
