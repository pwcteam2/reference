package com.monitor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.monitor.domain.TimeBracketDuration;

public interface TimeBracketDurationRepository extends JpaRepository<TimeBracketDuration, Long> {

	public List<TimeBracketDuration> findAll();
	
	public TimeBracketDuration findOne(Long timeBracketDurationId);
	
	public TimeBracketDuration findByDuration(Integer duration);
}
