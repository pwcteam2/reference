package com.monitor.repository;

import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.monitor.domain.PodHistory;
import com.monitor.enums.PodAction;

@Repository
public interface PodHistoryRepository extends JpaRepository<PodHistory, Long> {

	public List<PodHistory> findAll();

	public PodHistory findByPodHistoryId(Long podHistoryId);
	
	public List<PodHistory> findByPodPodIdAndCreatedDateBetweenOrderByCreatedDateAsc(Long podId, DateTime startDate, DateTime endDate);
	
//	@Query(value = "SELECT ph FROM PodHistory ph where ((ph.podHistoryId not IN (select tph.podHistoryId from PodHistory tph group by tph.configurationVersion having count(*) = 1) and (ph.pod.podId = :podId)) or ph.podAction = :a) and ph.createdDate between :s and :e")
//	public List<PodHistory> findSheets(@Param("podId") Long podId,@Param("a") PodAction podAction, @Param("s") DateTime startDate,@Param("e") DateTime endDate);
//	
//	@Query(value = "SELECT ph FROM PodHistory ph where ((ph.podHistoryId not IN (select tph.podHistoryId from PodHistory tph group by tph.configurationVersion having count(*) = 1) and (ph.pod.podId = :podId)) and ((ph.createdDate between :s and :e) or ph.podAction = :a))")
//	public List<PodHistory> findSheets(@Param("podId") Long podId,@Param("a") PodAction podAction, @Param("s") DateTime startDate,@Param("e") DateTime endDate);
//	
//	@Query(value = "SELECT ph FROM PodHistory ph where ((ph.podHistoryId not IN (select tph.podHistoryId from PodHistory tph group by tph.configurationVersion having count(*) = 1) and (ph.pod.podId = :podId)) or ph.podAction = :a)")
//	public List<PodHistory> findSheets(@Param("podId") Long podId,@Param("a") PodAction podAction);
//	
//	@Query(value = "SELECT * FROM pod_history where pod_history_id not IN (select pod_history_id from pod_history group by configuration_version having count(*) = 1) and pod = :podId", nativeQuery = true)
//	public List<PodHistory> findSheets(@Param("podId") Long podId);
	
	public PodHistory findTop1ByPodPodIdAndCreatedDateLessThanEqualOrderByCreatedDateDesc(Long podId, DateTime createdDate);
	
	public Long countByPodPodIdAndCreatedDateBetweenAndPodActionNot(Long podId, DateTime stDate, DateTime edDate, PodAction podAction);
}
