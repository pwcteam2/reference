package com.monitor.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.monitor.domain.Location;
import com.monitor.domain.Pod;


public interface PodRepository extends JpaRepository<Pod, Long> {
	
	
	/**
	 * Find by id
	 * @param id
	 * @return Pod
	 */
	public Pod findByPodId(Long podId);
	
	/**
	 * Find all Pod
	 * @return Pod
	 */
	public Set<Pod> findAllByOrderByPodNameAsc();


	/**
	 * Find all Pod
	 * @return Pod
	 */

	public Pod findByPodName(String podName);
	
	/**
	 * 
	 * @param List of podId
	 * @return set of pods
	 */
	
	public Set<Pod> findByPodIdIn(List<Long> podId);
	
	@Query("select p.podId from Pod p")
	public Long[] getAllIds();
	
	public Pod findByPodNameInAndLocationLocationIdIn(String podName, Long locationId);
	
	public Set<Pod> findAllByLocationLocationIdInOrderByCreatedDateAsc(Long locationId);
	
	public Set<Pod> findByLocationLocationIdAndDisabledOrderByPodNameAsc(Long locationId, Boolean disabled);
	
	public long countByLocation(@Param("location") Location location);
}
