package com.monitor.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.monitor.domain.Location;
import com.sun.org.apache.xpath.internal.operations.Bool;

public interface LocationRepository extends JpaRepository<Location, Long> {

	public Location findByLocationId(Long locationId);

	public Location findByLocationName(String locationName);

	public Set<Location> findAllByOrderByCreatedDateAsc();

	public Set<Location> findByDisabledOrderByLocationNameAsc(Boolean disabled);

	public Set<Location> findByLocationIdInOrderByCreatedDateAsc(List<Long> locationId);

	public Set<Location> findByLocationIdInAndDisabled(List<Long> locationId, Boolean disabled);

	@Query("select l.locationId from Location l")
	public Long[] getAllIds();
}
