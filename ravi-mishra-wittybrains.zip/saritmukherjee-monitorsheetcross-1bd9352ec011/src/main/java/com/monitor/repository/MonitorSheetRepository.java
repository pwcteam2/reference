package com.monitor.repository;

import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.monitor.domain.MonitorSheet;
import com.monitor.domain.Pod;
import com.monitor.domain.Shift;
import com.monitor.enums.Status;

@Repository
public interface MonitorSheetRepository extends JpaRepository<MonitorSheet, Long> {

	public List<MonitorSheet> findAll();

	public MonitorSheet findByMonitorId(Long monitorId);

	public List<MonitorSheet> findByMonitorIdIn(List<Long> monitorId);

	public List<MonitorSheet> findByPodPodIdAndShiftDateAndShiftShiftId(Long podId, DateTime shiftDate, Long shiftId);

	public List<MonitorSheet> findByPodPodIdAndShiftDateAndShiftShiftIdAndStatusNotOrderByCreatedDateDesc(Long podId,
			DateTime shiftDate, Long shiftId, Status status);

	public List<MonitorSheet> findByPodAndStatus(Pod pod, Status status);
	
	public List<MonitorSheet> findByPodAndShiftAndShiftDateAndStatus(Pod pod, Shift shift, DateTime shiftDate, Status status);
	
	public List<MonitorSheet> findByPodAndShiftAndShiftDateAndTimeBracketIdAndStatusNot(Pod pod, Shift shift, DateTime shiftDate, Long timeBracketId, Status status);

	public List<MonitorSheet> findByPodAndStatusIn(Pod pod, List<Status> statusList);
	
	/**Used for count number of entry of a channel in monitor sheet details table.
	 * @param channelId
	 * @return
	 */
	@Query("Select COUNT(ms) from MonitorSheet ms join ms.monitorSheetDetails msd join msd.channel ch where ch.channelId = :channelId")
	public Long countByChannelId(@Param("channelId")Long channelId);
	
	public Long countByShiftDateAndShiftShiftId(DateTime shiftDate, Long shiftId);
	
	public Long countByShiftDateAndShiftShiftIdAndStatusNot(DateTime shiftDate, Long shiftId, Status status);
	
	public Long countByShiftDateAndShiftShiftIdAndStatusIn(DateTime shiftDate, Long shiftId, List<Status> statusList);
	
	public List<MonitorSheet> findByShiftDateAndShiftShiftId(DateTime shiftDate, Long shiftId);
	
	public Long countByPodPodId(Long podId);
	
//	public MonitorSheet findByPodPodIdAndShiftShiftIdAndTimeBracketIdAndStatusAndCreatedDateBetweenOrderByPodCreatedDateAscCreatedDateAsc(
//			Long podId, Long shiftId, Long timeBracketId, Status status, DateTime startDate, DateTime endDate);
	
	public MonitorSheet findByPodPodIdAndShiftShiftIdAndTimeBracketIdAndStatusAndShiftDateOrderByPodCreatedDateAscCreatedDateAsc(
			Long podId, Long shiftId, Long timeBracketId, Status status, DateTime shiftDate);

	public MonitorSheet findTop1ByStatusAndPodPodIdOrderByCreatedDateDesc(Status status, Long podId);
	
	public MonitorSheet findTop1ByStatusAndPodPodIdAndCreatedDateLessThanOrderByCreatedDateDesc(Status status, Long podId, DateTime createdDate);

	public MonitorSheet findTop1ByStatusAndPodPodIdOrderByCreatedDateAsc(Status status, Long podId);

	public MonitorSheet findTop1ByStatusAndPodPodIdAndCreatedDateLessThanEqualOrderByCreatedDateAsc(Status status, Long podId,
			DateTime createdDate);
}
