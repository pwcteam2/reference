package com.monitor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.monitor.domain.TextField;

public interface TextFieldRepository extends JpaRepository<TextField, Long> {

	public List<TextField> findAll();

	public TextField findByTextFieldId(Long textFieldId);
	
	public Long countBySubCategorySubCategoryId(Long subCategoryId);
}
