package com.monitor.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.monitor.domain.Channel;
import com.monitor.domain.Pod;

public interface ChannelRepository extends JpaRepository<Channel, Long> {

	/**
	 * Find by id
	 * 
	 * @param id
	 * @return Channel
	 */
	public Channel findByChannelId(Long channelId);

	/**
	 * Find all Channel
	 * 
	 * @return Channel
	 */
	public Set<Channel> findAllByOrderByChannelNameAsc();

	public Set<Channel> findByPodPodIdOrderByCreatedDateAsc(Long podId);

	/**
	 * Find by ChannelName
	 * 
	 * @param ChannelName
	 * @return Channel
	 */
	public Channel findByChannelName(String channelName);

	/**
	 * Find by nocNumber
	 * 
	 * @param nocNumber
	 * @return Channel
	 */
	public Channel findByNocNumberAndPodPodId(String nocNumber, Long channelId);

	public Set<Channel> findByChannelIdInOrderByChannelName(List<Long> ids);

	public long countByPod(@Param("pod") Pod pod);

	@Query("select c.channelId from Channel c")
	public Long[] getAllIds();

	public Channel findByChannelNameInAndPodPodIdIn(String channelName, Long podId);

	public Long countByPodPodId(Long podId);

	public List<Channel> findByPodPodIdAndDisabledOrderByCreatedDateAsc(Long podId, Boolean disabled);
	
	public Long countByPodPodIdAndDisabled(Long podId, Boolean disabled);
}
