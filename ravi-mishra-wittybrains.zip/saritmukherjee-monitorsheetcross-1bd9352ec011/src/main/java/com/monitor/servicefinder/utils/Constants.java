package com.monitor.servicefinder.utils;

/**Used for storing lengths of various entities.
 * @author Wittybrains
 *
 */
public class Constants {

	public static final Integer LOCATION_LENGTH = 15;
	
	public static final Integer POD_LENGTH = 10;
	
	public static final Integer CHANNEL_LENGTH = 15;
	
	public static final Integer NOC_LENGTH = 5;
	
	public static final Integer CATEGORY_LENGTH = 15;
	
	public static final Integer SUB_CATEGORY_LENGTH = 8;
	
	public static final Integer TEXT_FIELD_LENGTH = 15;
}
