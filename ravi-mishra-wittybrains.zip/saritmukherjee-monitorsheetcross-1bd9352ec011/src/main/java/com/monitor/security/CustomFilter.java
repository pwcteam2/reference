package com.monitor.security;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.monitor.domain.User;
import com.monitor.exception.RestException;
import com.monitor.service.UserService;

/**
 * Used for verifying credentials of an user with every request. If an user
 * details is changes while logged in, this will cause an exception.
 * 
 * @author Wittybrains
 *
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 1)
public class CustomFilter extends GenericFilterBean {

	@Autowired
	private TokenStore tokenStore;

	@Autowired
	@Lazy
	private UserService userService;

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		String token = extractHeaderToken(req);

		// Verifying if token is present and valid by tokenStore
		if (token != null && !token.isEmpty() && tokenStore.readAuthentication(token) != null) {
			OAuth2Authentication auth = tokenStore.readAuthentication(token);

			User user = userService.findByEmail(auth.getName());

			String errorMessage = null;
			if (user == null) {
				errorMessage = "The email or password you entered is incorrect";
			} else if (user.isDeleted()) {
				errorMessage = "Deleted Account, Please contact Manager";
			} else if (!user.isActive()) {
				// Don't change the error message for this as it is binded with
				// the frontend.Your account has been deactivated. Please
				// contact manager.
				errorMessage = "Your account has been deactivated. Please contact manager";
			}
			if (errorMessage != null && !errorMessage.isEmpty()) {
				RestException exception = new RestException(errorMessage, "");
				res.setStatus(500);
				res.setContentType("application/json");
				res.setCharacterEncoding("UTF-8");
				res.getWriter().write(new ObjectMapper().writeValueAsString(exception));
			}
			MDC.put("email", user.getEmail());
		}

		chain.doFilter(request, response);

	}

	// Used for extracting the Bearer token from the HttpRequest
	protected String extractHeaderToken(HttpServletRequest request) {
		Enumeration<String> headers = request.getHeaders("Authorization");
		while (headers.hasMoreElements()) { // typically there is only one (most
											// servers enforce that)
			String value = headers.nextElement();
			if ((value.toLowerCase().startsWith(OAuth2AccessToken.BEARER_TYPE.toLowerCase()))) {
				String authHeaderValue = value.substring(OAuth2AccessToken.BEARER_TYPE.length()).trim();
				// Add this here for the auth details later. Would be better to
				// change the signature of this method.
				request.setAttribute(OAuth2AuthenticationDetails.ACCESS_TOKEN_TYPE,
						value.substring(0, OAuth2AccessToken.BEARER_TYPE.length()).trim());
				int commaIndex = authHeaderValue.indexOf(',');
				if (commaIndex > 0) {
					authHeaderValue = authHeaderValue.substring(0, commaIndex);
				}
				return authHeaderValue;
			}
		}

		return null;
	}

}
