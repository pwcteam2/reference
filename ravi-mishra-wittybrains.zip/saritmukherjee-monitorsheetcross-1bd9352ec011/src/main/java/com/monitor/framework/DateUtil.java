package com.monitor.framework;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

@Component
public class DateUtil {

	/**
	 * Reset the time from date (set to 00:00:00)
	 *
	 * @param date the Date
	 * @return the Date
	 */
	public static Date resetTime(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}
	
	/**
	 * Remove the time from date
	 *
	 * @param date the Date
	 * @param format the date format (like "MM/dd/YYYY")
	 * @return the date string in above format
	 */
	public static String removeTime(Date date , String format) {
		DateFormat outputFormatter = new SimpleDateFormat(format);
		return outputFormatter.format(date);
	}
	
	/**
	 * Remove the time from date
	 *
	 * @param date the Date
	 * @param format the date format (like "MM/dd/YYYY")
	 * @return the date string in above format
	 */
	public static String removeTime(DateTime date , String format) {
		DateFormat outputFormatter = new SimpleDateFormat(format);
		return outputFormatter.format(date.toDate());
	}
	
	/**
	 * Remove the time from date in and produce date in "dd/MM/yyyy" format
	 * 
	 * @param date the Date
	 * @return the date string
	 */
	public static String removeTime(Date date) {
		DateFormat outputFormatter = new SimpleDateFormat("dd/MM/yyyy");
		return outputFormatter.format(date);
	}
	
	/**
	 * Remove the time from date in and produce date in "dd/MM/yyyy" format
	 * 
	 * @param date the Date
	 * @return the date string
	 */
	public static String removeTime(DateTime date) {
		DateFormat outputFormatter = new SimpleDateFormat("dd/MM/yyyy");
		return outputFormatter.format(date.toDate());
	}

}