package com.monitor.excelhelper;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsView;

/**
 * Created by Rajiv Singh Gahunia on 2017-12-26.
 */
public class ExcelView extends AbstractXlsView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		// change the file name
		response.setHeader("Content-Disposition", "attachment; filename=\"my-xls-file.xlsx\"");

	//	@SuppressWarnings("unchecked")
//		List<MonitorSheetOldDTO> monitorSheetListDto = (List<MonitorSheetOldDTO>) model.get("monitorSheetList");
//		Map<String, List<MonitorSheetOldDTO>> monitorSheetPodMap = new HashMap<String, List<MonitorSheetOldDTO>>();
//		Map<String, List<MonitorSheetOldDTO>> monitorSheetLocationMap = new HashMap<String, List<MonitorSheetOldDTO>>();
//
//		Map<DateTime, List<MonitorSheetOldDTO>> monitorSheetDtoMap = monitorSheetListDto.stream()
//				.collect(Collectors.groupingBy(MonitorSheetOldDTO::getShiftDate));
//
//		LinkedHashMap<DateTime, List<MonitorSheetOldDTO>> sortedDate = monitorSheetDtoMap.entrySet().stream()
//				.sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
//						(oldValue, newValue) -> oldValue, LinkedHashMap::new));
//
//		Sheet document = workbook.createSheet("Leave Details");
//		CExcelTable table = new CExcelTable(workbook, document, 9, new int[] { 1, 1, 1, 1, 1, 1, 1, 1, 2 });
//
//		for (DateTime modifiedDate : sortedDate.keySet()) {
//			// groupingLocation wise
//			List<MonitorSheetOldDTO> monitorSheetDtoList = monitorSheetDtoMap.get(modifiedDate);
//			monitorSheetLocationMap = monitorSheetDtoList.stream()
//					.collect(Collectors.groupingBy(MonitorSheetOldDTO::getLocationName));
//			LinkedHashMap<String, List<MonitorSheetOldDTO>> sortedLocation = monitorSheetLocationMap.entrySet().stream()
//					.sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
//							(oldValue, newValue) -> oldValue, LinkedHashMap::new));
//			
//			table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//					CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//			table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//					CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//			table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//					CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//			table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//					CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//			table.AddCell(new CExcelTableCell(
//					"Date : " + DateUtil.getDateWithMonthInString(
//							com.monitor.framework.DateUtil.removeTime(modifiedDate, "dd-MM-yyyy")),
//					Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 4, CellStyle.ALIGN_CENTER,
//					CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//			table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//					CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//
//			for (String locationName : sortedLocation.keySet()) {
//
//				// grouping pod wise
//				List<MonitorSheetOldDTO> monitorSheetLocationList = monitorSheetLocationMap.get(locationName);
//				monitorSheetPodMap = monitorSheetLocationList.stream()
//						.collect(Collectors.groupingBy(MonitorSheetOldDTO::getPodName));
//				LinkedHashMap<String, List<MonitorSheetOldDTO>> sortedPod = monitorSheetPodMap.entrySet().stream()
//						.sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey,
//								Map.Entry::getValue, (oldValue, newValue) -> oldValue, LinkedHashMap::new));
//
//				for (String podName : sortedPod.keySet()) {
//					List<MonitorSheetOldDTO> monitorSheetPodList = monitorSheetPodMap.get(podName);
//
//					// grouping channel wise
//					Map<String, List<MonitorSheetOldDTO>> monitorSheetChannelMap = monitorSheetPodList.stream()
//							.collect(Collectors.groupingBy(MonitorSheetOldDTO::getChannelName));
//					LinkedHashMap<String, List<MonitorSheetOldDTO>> sortedChannel = monitorSheetChannelMap.entrySet()
//							.stream().sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey,
//									Map.Entry::getValue, (oldValue, newValue) -> oldValue, LinkedHashMap::new));
//
//					
//
//					for (String channelName : sortedChannel.keySet()) {
//						List<MonitorSheetOldDTO> monitorSheetChannelList = monitorSheetChannelMap.get(channelName);
//						// grouping shift wise
//						Map<String, List<MonitorSheetOldDTO>> monitorSheetShiftMap = monitorSheetChannelList.stream()
//								.collect(Collectors.groupingBy(MonitorSheetOldDTO::getShiftName));
//						LinkedHashMap<String, List<MonitorSheetOldDTO>> sortedShift = monitorSheetShiftMap.entrySet()
//								.stream().sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey,
//										Map.Entry::getValue, (oldValue, newValue) -> oldValue, LinkedHashMap::new));
//						String supervisorRemark = "";
//						for (String shift : sortedShift.keySet()) {
//							List<MonitorSheetOldDTO> finalList = monitorSheetShiftMap.get(shift);
//							finalList.sort((MonitorSheetOldDTO m1, MonitorSheetOldDTO m2) -> m1.getCreatedDate()
//									.compareTo(m2.getCreatedDate()));
//
//							table.AddCell(new CExcelTableCell("Location " + locationName, Font.BOLDWEIGHT_BOLD,
//									HSSFColor.SKY_BLUE.index, 9, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_TOP));
//							
//							table.AddCell(new CExcelTableCell("Pod " + podName, Font.BOLDWEIGHT_BOLD,
//									HSSFColor.SKY_BLUE.index, 9, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_TOP));
//
//							table.AddCell(new CExcelTableCell("Channel " + channelName, Font.BOLDWEIGHT_BOLD,
//									HSSFColor.SKY_BLUE.index, 9, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_TOP));
//
//							table.AddCell(new CExcelTableCell("Shift " + shift, Font.BOLDWEIGHT_BOLD,
//									HSSFColor.SKY_BLUE.index, 9, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_TOP));
//
//							// table = new CExcelTable(workbook, document, 9,
//							// new int[] { 1,1, 1, 1, 1,1,1,1,2});
//							table.AddCell(new CExcelTableCell("S No", Font.BOLDWEIGHT_BOLD, HSSFColor.SKY_BLUE.index, 1,
//									CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP));
//							table.AddCell(new CExcelTableCell("Time", Font.BOLDWEIGHT_BOLD, HSSFColor.SKY_BLUE.index, 1,
//									CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP));
//							table.AddCell(new CExcelTableCell("Program", Font.BOLDWEIGHT_BOLD, HSSFColor.SKY_BLUE.index,
//									1, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP));
//							table.AddCell(new CExcelTableCell("Audio", Font.BOLDWEIGHT_BOLD, HSSFColor.SKY_BLUE.index,
//									1, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP));
//							table.AddCell(new CExcelTableCell("Bug", Font.BOLDWEIGHT_BOLD, HSSFColor.SKY_BLUE.index, 1,
//									CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP));
//							table.AddCell(new CExcelTableCell("Subtitle", Font.BOLDWEIGHT_BOLD,
//									HSSFColor.SKY_BLUE.index, 1, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP));
//							table.AddCell(new CExcelTableCell("U/O", Font.BOLDWEIGHT_BOLD, HSSFColor.SKY_BLUE.index, 1,
//									CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP));
//							table.AddCell(new CExcelTableCell("Operator", Font.BOLDWEIGHT_BOLD,
//									HSSFColor.SKY_BLUE.index, 1, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP));
//							table.AddCell(new CExcelTableCell("Remarks", Font.BOLDWEIGHT_BOLD, HSSFColor.SKY_BLUE.index,
//									1, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP));
//
//							int sno = 0;
//							for (MonitorSheetOldDTO sheet : finalList) {
//								++sno;
//								supervisorRemark = sheet.getSupervisorRemark();
//
//								String formattedDate = new SimpleDateFormat("HH:mm:ss")
//										.format(sheet.getCreatedDate().toDate());
//								table.AddCell(new CExcelTableCell(sno + ""));
//								table.AddCell(new CExcelTableCell(formattedDate));
//								table.AddCell(new CExcelTableCell(getStringForBoolean(sheet.getProgram())));
//								table.AddCell(new CExcelTableCell(getStringForBoolean(sheet.getAudio())));
//								table.AddCell(new CExcelTableCell(getStringForBoolean(sheet.getBug())));
//								table.AddCell(new CExcelTableCell(getStringForBoolean(sheet.getSubtitle())));
//								table.AddCell(new CExcelTableCell(getStringForBoolean(sheet.getUno())));
//								table.AddCell(new CExcelTableCell(sheet.getOperatorName()));
//								table.AddCell(new CExcelTableCell(sheet.getRemark()));
//							}
//							// table.CreateTable();
//
//						}
//
//						table.AddCell(
//								new CExcelTableCell("Supervisor remark: " + supervisorRemark, Font.BOLDWEIGHT_BOLD,
//										HSSFColor.WHITE.index, 9, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_TOP));
//
//						// adding rows to add empty space
//						table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//								CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//						table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//								CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//						table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//								CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//						table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//								CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//						table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//								CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//						table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//								CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//						table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//								CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//						table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//								CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//						table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
//								CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_TOP, CellStyle.BORDER_NONE));
//
//					}
//
//				}
//
//			}
//		}
//		table.CreateTable();
	}

	private String getStringForBoolean(Boolean boolValue) {
		if (boolValue == null) {
			return "N/A";
		}

		if (boolValue) {
			return "Yes";
		}

		return "False";
	}
}
