package com.monitor.excelhelper;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;

public class CExcelTableCell {
	public String text = "";
	public int fontSize = 10;
	public short boldWeight = Font.BOLDWEIGHT_NORMAL;
	public short backgroundColorIndex;
	public short halign = CellStyle.ALIGN_LEFT;
	public short valign = CellStyle.VERTICAL_TOP;
	public short border = CellStyle.BORDER_NONE;
	public int colSpan = 1;
	public short borderColorIndex = IndexedColors.BLACK.getIndex();
	public int pictureIndex = 100;
	public Boolean header = false;
	public short fontColor = (short)0;

	public CExcelTableCell(String text) {
		this.text = text;
	}

	public CExcelTableCell(String text, short boldWeight) {
		this.text = text;
		this.boldWeight = boldWeight;
	}

	public CExcelTableCell(String text, short boldWeight, short backgroundColorIndex) {
		this.text = text;
		this.boldWeight = boldWeight;
		this.backgroundColorIndex = (short) backgroundColorIndex;
	}

	public CExcelTableCell(String text, short boldWeight, short backgroundColorIndex, int colSpan) {
		this.text = text;
		this.boldWeight = boldWeight;
		this.backgroundColorIndex = (short) backgroundColorIndex;
		this.colSpan = colSpan;
	}

	public CExcelTableCell(String text, short boldWeight, short backgroundColorIndex, int colSpan, short halign, short valign) {
		this.text = text;
		this.boldWeight = boldWeight;
		this.backgroundColorIndex = (short) backgroundColorIndex;
		this.colSpan = colSpan;
		this.halign = halign;
		this.valign = valign;
	}
	
	public CExcelTableCell(String text, short boldWeight, short backgroundColorIndex, int colSpan, short halign, short valign, short border ) {
		this.text = text;
		this.boldWeight = boldWeight;
		this.backgroundColorIndex = (short) backgroundColorIndex;
		this.colSpan = colSpan;
		this.halign = halign;
		this.valign = valign;
		this.border = border;
	}
	
	public CExcelTableCell(String text, short boldWeight, short backgroundColorIndex, int colSpan, short halign, short valign, short border, int fontColor) {
		this.text = text;
		this.boldWeight = boldWeight;
		this.backgroundColorIndex = (short) backgroundColorIndex;
		this.colSpan = colSpan;
		this.halign = halign;
		this.valign = valign;
		this.border = border;
		this.fontColor = (short)fontColor;
	}
	
	public CExcelTableCell(String text, short boldWeight, short backgroundColorIndex, int colSpan, short halign, short valign, short border, Boolean header) {
		this.text = text;
		this.boldWeight = boldWeight;
		this.backgroundColorIndex = (short) backgroundColorIndex;
		this.colSpan = colSpan;
		this.halign = halign;
		this.valign = valign;
		this.border = border;
		this.header = header;
	}
	
	public CExcelTableCell(String text, short boldWeight, int colSpan, short halign, short valign, short border ) {
		this.text = text;
		this.boldWeight = boldWeight;
		this.colSpan = colSpan;
		this.halign = halign;
		this.valign = valign;
		this.border = border;
	}
	
	public CExcelTableCell(String text, short boldWeight, int colSpan, short halign, short valign, short border, short borderColorIndex, Boolean header) {
		this.text = text;
		this.boldWeight = boldWeight;
		this.colSpan = colSpan;
		this.halign = halign;
		this.valign = valign;
		this.border = border;
		this.borderColorIndex = borderColorIndex;
		this.header = header;
	}
	
	public CExcelTableCell(String text, short boldWeight, short backgroundColorIndex, int colSpan, short halign, short valign, short border, short borderColorIndex) {
		this.text = text;
		this.boldWeight = boldWeight;
		this.backgroundColorIndex = backgroundColorIndex;
		this.colSpan = colSpan;
		this.halign = halign;
		this.valign = valign;
		this.border = border;
		this.borderColorIndex = borderColorIndex;
	}
	
	public CExcelTableCell(String text, short boldWeight, short backgroundColorIndex, int colSpan, short halign, short valign, short border, short borderColorIndex, int pictureIndex) {
		this.text = text;
		this.boldWeight = boldWeight;
		this.backgroundColorIndex = backgroundColorIndex;
		this.colSpan = colSpan;
		this.halign = halign;
		this.valign = valign;
		this.border = border;
		this.borderColorIndex = borderColorIndex;
		this.pictureIndex = pictureIndex;
	}

	public CExcelTableCell(String text, short boldWeight, short backgroundColorIndex, int colSpan, short halign, short valign, short border, short borderColorIndex, Boolean header) {
		this.text = text;
		this.boldWeight = boldWeight;
		this.backgroundColorIndex = backgroundColorIndex;
		this.colSpan = colSpan;
		this.halign = halign;
		this.valign = valign;
		this.border = border;
		this.borderColorIndex = borderColorIndex;
		this.header = header;
	}
}
