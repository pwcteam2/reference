package com.monitor.excelhelper;

import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.monitor.servicefinder.utils.MathUtils;

public class CExcelTable {

	public int numberOfColumns;
	public int[] columnsWidth;
	public int rowOffset = 0;
	public int columnOffset = 0;
	private ArrayList<CExcelTableCell> cells = new ArrayList<CExcelTableCell>();
	private XSSFWorkbook workbook;
	private Sheet sheet;
	private final int NORMAL_WIDTH_MULTIPLIER = 10;

	protected ArrayList<Font> fonts = new ArrayList<Font>();
	protected ArrayList<XSSFCellStyle> cellStyles = new ArrayList<XSSFCellStyle>();

	public CExcelTable(XSSFWorkbook workbook, Sheet sheet, int numberOfColumns, int[] columnsWidth) {
		this.workbook = workbook;
		this.sheet = sheet;
		this.numberOfColumns = numberOfColumns;
		this.columnsWidth = columnsWidth;
	}

	public void reset(int numberOfColumns, int[] columnsWidth, int rowOffset) {
		this.numberOfColumns = numberOfColumns;
		this.columnsWidth = columnsWidth;
		this.rowOffset = rowOffset;
		this.columnOffset = 0;
		cells = new ArrayList<>();
	}

	public int getRowOffset() {
		return this.rowOffset;
	}

	public void AddCell(String text) {
		cells.add(new CExcelTableCell(text));
	}

	public void AddCell(CExcelTableCell cell) {
		cells.add(cell);
	}

	protected CellStyle GetCellStyle(CExcelTableCell newCell) {
		XSSFCellStyle theCellStyle = null;
		for (XSSFCellStyle cs : cellStyles) {
			if (cs.getAlignment() != newCell.halign)
				continue;
			if (cs.getVerticalAlignment() != newCell.valign)
				continue;
			if (newCell.backgroundColorIndex == 0 && cs.getFillPattern() != HSSFCellStyle.NO_FILL)
				continue;
			if (newCell.backgroundColorIndex != 0 && (cs.getFillPattern() != HSSFCellStyle.SOLID_FOREGROUND
					|| cs.getFillForegroundColor() != newCell.backgroundColorIndex))
				continue;
			if (workbook.getFontAt(cs.getFontIndex()).getBoldweight() != newCell.boldWeight)
				continue;

			theCellStyle = cs;
		}

		if (theCellStyle == null) {
			theCellStyle = GetNewCellStyle(newCell);
			Font theFont = GetNewFont(newCell);
			theCellStyle.setFont(theFont);
			this.cellStyles.add(theCellStyle);
		}

		theCellStyle.setBorderBottom(newCell.border);
		theCellStyle.setBorderTop(newCell.border);
		theCellStyle.setBorderLeft(newCell.border);
		theCellStyle.setBorderRight(newCell.border);
		theCellStyle.setBottomBorderColor(newCell.borderColorIndex);
		theCellStyle.setLeftBorderColor(newCell.borderColorIndex);
		theCellStyle.setTopBorderColor(newCell.borderColorIndex);
		theCellStyle.setRightBorderColor(newCell.borderColorIndex);
		return theCellStyle;
	}

	protected XSSFCellStyle GetNewCellStyle(CExcelTableCell newCell) {
		XSSFCellStyle newCellStyle = workbook.createCellStyle();
		newCellStyle.setAlignment(newCell.halign);
		newCellStyle.setVerticalAlignment(newCell.valign);
		if (newCell.backgroundColorIndex == 0) {
			newCellStyle.setFillPattern(HSSFCellStyle.NO_FILL);
		} else {
			newCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			newCellStyle.setFillForegroundColor(newCell.backgroundColorIndex);
		}
		return newCellStyle;
	}

	protected Font GetNewFont(CExcelTableCell newCell) {
		Font newFont = workbook.createFont();
		newFont.setBoldweight(newCell.boldWeight);
		if(newCell.fontColor != 0)
		newFont.setColor(newCell.fontColor);
		return newFont;
	}

	public int CreateTable() {
		setColumnsWidth();
		int rowIndex = rowOffset;
		int columnIndex = columnOffset;
		Row row = null;

		for (CExcelTableCell cellObj : cells) {
			CellStyle cellStyle = GetCellStyle(cellObj);
			if(columnIndex > numberOfColumns && !cellObj.header)
				columnIndex = 0;
			if (columnIndex % numberOfColumns == 0) {
				if (!cellObj.header) {
					columnIndex = 0;
					row = sheet.createRow(rowIndex++);
				}
			}

			Cell cell = null;
			int startColIndex = columnIndex;
			for (int j = 0; j < cellObj.colSpan; j++) {

				cell = row.createCell((short) columnIndex++);
				cell.setCellStyle(cellStyle);

				try {
					double f = Double.valueOf(cellObj.text);
					cell.setCellValue(MathUtils.removeTrailingZeros(f));
				} catch (Exception e) {
					// if(cellObj.pictureIndex != 100) {
					// CreationHelper helper = workbook.getCreationHelper();
					// XSSFDrawing drawing = (XSSFDrawing)
					// sheet.createDrawingPatriarch();
					// ClientAnchor anchor = helper.createClientAnchor();
					// anchor.setCol1(columnIndex - 1);
					// anchor.setRow1(rowIndex - 1);
					// anchor.setRow2(rowIndex);
					// anchor.setCol2(columnIndex);
					// anchor.setDx1(20);
					// anchor.setDx2(20);
					// anchor.setDy1(0);
					// anchor.setDy2(0);
					// anchor.setAnchorType(ClientAnchor.MOVE_DONT_RESIZE);
					// final Picture pict = drawing.createPicture(anchor,
					// cellObj.pictureIndex);
					// pict.resize(0.98, 0.95);
					// }

					cell.setCellValue(cellObj.text);
				}
			}

			if (cellObj.colSpan > 1) {
				sheet.addMergedRegion(new CellRangeAddress(rowIndex - 1, rowIndex - 1, startColIndex, columnIndex - 1));
			}
		}
		return rowIndex;
	}

	private void setColumnsWidth() {
		for (int i = 0; i < columnsWidth.length; i++) {
			sheet.setColumnWidth(i, columnsWidth[i] * 255 * NORMAL_WIDTH_MULTIPLIER);
		}
	}
}