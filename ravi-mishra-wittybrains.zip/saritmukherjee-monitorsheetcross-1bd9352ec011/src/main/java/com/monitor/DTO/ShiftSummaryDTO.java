package com.monitor.DTO;

import org.joda.time.DateTime;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.monitor.domain.ShiftSummary;
import com.monitor.enums.Status;
import com.monitor.servicefinder.utils.DateTimeDeserializer;

public class ShiftSummaryDTO {

	private Long shiftSummaryId;
	private Boolean approved;
	private String summary;
	private DateTime shiftDate;
	private Long shiftId;
	private String shiftName;
	private String logsState;
	private Status mailSent;
	
	public ShiftSummaryDTO(ShiftSummary shiftSummary,String logsState){
		this.shiftDate = shiftSummary.getShiftDate();
		this.approved = shiftSummary.getApproved();
		this.summary =  shiftSummary.getSummary();
		this.shiftId =  shiftSummary.getShift().getShiftId();
		this.shiftName = shiftSummary.getShift().getName();
		this.shiftSummaryId = shiftSummary.getShiftSummaryId();
		this.logsState = logsState;
		this.mailSent = shiftSummary.getMailSent()? Status.SENT : Status.PENDING;
	}

	
	public ShiftSummaryDTO(){
	
	}
	

	public Long getShiftSummaryId() {
		return shiftSummaryId;
	}
	public void setShiftSummaryId(Long shiftSummaryId) {
		this.shiftSummaryId = shiftSummaryId;
	}
	
	public Boolean getApproved() {
		return approved;
	}
	public void setApproved(Boolean approved) {
		this.approved = approved;
	}
	
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	
	public DateTime getShiftDate() {
		return shiftDate;
	}
	
	@JsonDeserialize(using=DateTimeDeserializer.class)
	public void setShiftDate(DateTime shiftDate) {
		this.shiftDate = shiftDate;
				//.withZone(DateTimeZone.forID("Asia/Kolkata"));
		
	}
	
	public Long getShiftId() {
		return shiftId;
	}
	public void setShiftId(Long shiftId) {
		this.shiftId = shiftId;
	}

	public String getShiftName() {
		return shiftName;
	}

	public void setShiftName(String shiftName) {
		this.shiftName = shiftName;
	}

	public String getLogsState() {
		return logsState;
	}

	public void setLogsState(String logsState) {
		this.logsState = logsState;
	}

	public Status getMailSent() {
		return mailSent;
	}

	public void setMailSent(Status mailSent) {
		this.mailSent = mailSent;
	}

}
