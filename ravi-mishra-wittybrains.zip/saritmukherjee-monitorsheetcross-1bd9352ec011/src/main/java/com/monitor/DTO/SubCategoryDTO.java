package com.monitor.DTO;


public class SubCategoryDTO {
	private Long subCategoryId;
	private String subCategoryName;
	private Long categoryId;
	private boolean disabled;

	public SubCategoryDTO(){
		
	}
	
	public SubCategoryDTO(Long subCategoryId, String subCategoryName,
			boolean disabled,Long categoryId) {
		this.subCategoryId = subCategoryId;
		this.subCategoryName = subCategoryName;
		this.categoryId = categoryId;
		this.disabled = disabled;
	}

	public Long getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(Long subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public boolean isDisabled() {
		return disabled;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}
	
}
