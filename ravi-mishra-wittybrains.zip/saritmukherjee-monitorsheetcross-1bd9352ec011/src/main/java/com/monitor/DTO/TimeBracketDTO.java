package com.monitor.DTO;

import org.joda.time.DateTime;

import com.monitor.servicefinder.utils.Constants;

/**
 * TimeBracketDTO is used to hold the unique id of a time bracket for a given
 * pod. As well as the start time of the time bracket and the string of the time
 * duration of the bracket.
 * 
 * @author Wittybrains
 *
 */
public class TimeBracketDTO {

	private Long timeBracketId;

	private String timeBracketValue;

	private DateTime timeBracketStartTime;

	private Long podId;
	
	private Integer timeBracketInMinutes;

	public TimeBracketDTO() {
	}

	public TimeBracketDTO(Long timeBracketId, DateTime timeBracketStartTime, Integer timeBracketInMinutes, Long podId) {
		this.timeBracketId = timeBracketId;
		this.timeBracketValue = timeBracketStartTime.toString("HH:mm") + " - "
				+ timeBracketStartTime.plusMinutes(timeBracketInMinutes).toString("HH:mm");
		this.timeBracketStartTime = timeBracketStartTime;
		this.podId = podId;
		this.timeBracketInMinutes = timeBracketInMinutes;
	}

	/**
	 * @return the timeBracketId
	 */
	public Long getTimeBracketId() {
		return timeBracketId;
	}

	/**
	 * @param timeBracketId the timeBracketId to set
	 */
	public void setTimeBracketId(Long timeBracketId) {
		this.timeBracketId = timeBracketId;
	}

	/**
	 * @return the timeBracketValue
	 */
	public String getTimeBracketValue() {
		return timeBracketValue;
	}

	/**
	 * @param timeBracketValue the timeBracketValue to set
	 */
	public void setTimeBracketValue(String timeBracketValue) {
		this.timeBracketValue = timeBracketValue;
	}

	/**
	 * @return the timeBracketStartTime
	 */
	public DateTime getTimeBracketStartTime() {
		return timeBracketStartTime;
	}

	/**
	 * @param timeBracketStartTime the timeBracketStartTime to set
	 */
	public void setTimeBracketStartTime(DateTime timeBracketStartTime) {
		this.timeBracketStartTime = timeBracketStartTime;
	}

	/**
	 * @return the podId
	 */
	public Long getPodId() {
		return podId;
	}

	/**
	 * @param podId the podId to set
	 */
	public void setPodId(Long podId) {
		this.podId = podId;
	}

	/**
	 * @return the timeBracketInMinutes
	 */
	public Integer getTimeBracketInMinutes() {
		return timeBracketInMinutes;
	}

	/**
	 * @param timeBracketInMinutes the timeBracketInMinutes to set
	 */
	public void setTimeBracketInMinutes(Integer timeBracketInMinutes) {
		this.timeBracketInMinutes = timeBracketInMinutes;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TimeBracketDTO [timeBracketId=" + timeBracketId + ", timeBracketValue=" + timeBracketValue
				+ ", timeBracketStartTime=" + timeBracketStartTime + ", podId=" + podId + ", timeBracketInMinutes="
				+ timeBracketInMinutes + "]";
	}
}
