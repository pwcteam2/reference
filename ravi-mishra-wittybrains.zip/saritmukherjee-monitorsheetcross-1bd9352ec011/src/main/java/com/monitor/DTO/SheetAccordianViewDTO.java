package com.monitor.DTO;

import org.joda.time.DateTime;

import com.monitor.enums.Status;
import com.monitor.utils.DateUtil;

public class SheetAccordianViewDTO {

	private Long monitorId;

	private String operatorName;

	private Long operatorId;

	private String startTime;

	private String endTime;

	private String remark;
	
	private Status status;
	
	private TimeBracketDTO timeBracketDTO;

	// public SheetAccordianViewDTO(MonitorSheet monitorSheet) {
	// this.monitorId = monitorSheet.getMonitorId();
	// this.operatorName = monitorSheet.getCreatedBy().getFullName();
	// this.createdDate = monitorSheet.getCreatedDate();
	// this.endDate = monitorSheet.getModifiedDate();
	// this.remark = monitorSheet.getRemark();
	// }

	public SheetAccordianViewDTO(Long monitorId, String operatorName, Long operatorId, DateTime startTime, DateTime endTime,
			String remark, Status status, TimeBracketDTO timeBracketDTO) {
		this.monitorId = monitorId;
		this.operatorName = operatorName;
		this.operatorId = operatorId;
		this.startTime = startTime.toString("hh:mm:ss a z");
		this.endTime = endTime.toString("hh:mm:ss a z");
		this.remark = remark;
		this.status = status;
		this.timeBracketDTO = timeBracketDTO;
	}
	
	public Long getMonitorId() {
		return monitorId;
	}

	public void setMonitorId(Long monitorId) {
		this.monitorId = monitorId;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	public Long getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	/**
	 * @return the timeBracketDTO
	 */
	public TimeBracketDTO getTimeBracketDTO() {
		return timeBracketDTO;
	}

	/**
	 * @param timeBracketDTO the timeBracketDTO to set
	 */
	public void setTimeBracketDTO(TimeBracketDTO timeBracketDTO) {
		this.timeBracketDTO = timeBracketDTO;
	}


}