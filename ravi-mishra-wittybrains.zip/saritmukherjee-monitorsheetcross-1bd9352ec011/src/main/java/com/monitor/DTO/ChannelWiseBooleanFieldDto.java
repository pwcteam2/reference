package com.monitor.DTO;

/**
 * It will store each field(Boolean) data corresponds to a channel.
 * 
 * @author Wittybrains
 *
 */
public class ChannelWiseBooleanFieldDto {

	private Long channelId;

	private String channelName;
	
	private Boolean booleanFieldId;
	
	private Boolean booleanFieldValue;
	
	public ChannelWiseBooleanFieldDto() {
	}

	public ChannelWiseBooleanFieldDto(Long channelId, String channelName, Boolean booleanFieldId,
			Boolean booleanFieldValue) {
		this.channelId = channelId;
		this.channelName = channelName;
		this.booleanFieldId = booleanFieldId;
		this.booleanFieldValue = booleanFieldValue;
	}

	public Long getChannelId() {
		return channelId;
	}

	public void setChannelId(Long channelId) {
		this.channelId = channelId;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public Boolean getBooleanFieldId() {
		return booleanFieldId;
	}

	public void setBooleanFieldId(Boolean booleanFieldId) {
		this.booleanFieldId = booleanFieldId;
	}

	public Boolean getBooleanFieldValue() {
		return booleanFieldValue;
	}

	public void setBooleanFieldValue(Boolean booleanFieldValue) {
		this.booleanFieldValue = booleanFieldValue;
	}

	@Override
	public String toString() {
		return "ChannelWiseBooleanField [channelId=" + channelId + ", channelName=" + channelName + ", booleanFieldId="
				+ booleanFieldId + ", booleanFieldValue=" + booleanFieldValue + "]";
	}
}
