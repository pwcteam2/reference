package com.monitor.DTO;


public class CategoryDTO {
	private Long categoryId;
	private String categoryName;
	private Long podId;
	private boolean disabled;

	public CategoryDTO(){
		
	}
	
	public CategoryDTO(Long categoryId,String categoryName,boolean disabled,Long podId){
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.disabled =  disabled;
		this.podId = podId;
	}
	
	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}


	public boolean isDisabled() {
		return disabled;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	public Long getPodId() {
		return podId;
	}

	public void setPodId(Long podId) {
		this.podId = podId;
	}

}
