package com.monitor.DTO;

import java.util.List;

import org.joda.time.DateTime;

public class PodDTO {
	private Long podId;
	private String podName;
	private DateTime deletedDate;
	private DateTime createdDate;
	private DateTime modifiedDate;
	private LocationDTO location;
	private Long timeBracketDurationId;
	private List<ChannelDTO> channelList;
	private boolean disabled;
	public Long getPodId() {
		return podId;
	}
	public void setPodId(Long podId) {
		this.podId = podId;
	}
	public String getPodName() {
		return podName;
	}
	public void setPodName(String podName) {
		this.podName = podName;
	}
	public DateTime getDeletedDate() {
		return deletedDate;
	}
	public void setDeletedDate(DateTime deletedDate) {
		this.deletedDate = deletedDate;
	}
	public DateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}
	public DateTime getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public LocationDTO getLocation() {
		return location;
	}
	public void setLocation(LocationDTO location) {
		this.location = location;
	}
	public Long getTimeBracketDurationId() {
		return timeBracketDurationId;
	}
	public void setTimeBracketDurationId(Long timeBracketDurationId) {
		this.timeBracketDurationId = timeBracketDurationId;
	}
	public List<ChannelDTO> getChannelList() {
		return channelList;
	}
	public void setChannelList(List<ChannelDTO> channelList) {
		this.channelList = channelList;
	}
	public boolean isDisabled() {
		return disabled;
	}
	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

}
