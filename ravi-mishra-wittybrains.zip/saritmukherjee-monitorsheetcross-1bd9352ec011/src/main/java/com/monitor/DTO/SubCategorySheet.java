package com.monitor.DTO;

import java.util.List;

/**
 * Used only for generating monitor sheet frontend view and as a data exchange
 * format.
 * 
 * @author Sarit Mukherjee
 *
 */
public class SubCategorySheet {

	private Long subCategoryId;

	private String subCategoryName;

	private List<ChannelWiseTextFieldDto> channelWiseTextFieldList;
	
	public SubCategorySheet() {
	}

	public SubCategorySheet(Long subCategoryId, String subCategoryName,
			List<ChannelWiseTextFieldDto> channelWiseTextFieldList) {
		this.subCategoryId = subCategoryId;
		this.subCategoryName = subCategoryName;
		this.channelWiseTextFieldList = channelWiseTextFieldList;
	}

	public Long getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(Long subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public List<ChannelWiseTextFieldDto> getChannelWiseTextFieldList() {
		return channelWiseTextFieldList;
	}

	public void setChannelWiseTextFieldList(List<ChannelWiseTextFieldDto> channelWiseTextFieldList) {
		this.channelWiseTextFieldList = channelWiseTextFieldList;
	}

	@Override
	public String toString() {
		return "SubCategorySheet [subCategoryId=" + subCategoryId + ", subCategoryName=" + subCategoryName
				+ ", channelWiseTextFieldList=" + channelWiseTextFieldList + "]";
	}

}
