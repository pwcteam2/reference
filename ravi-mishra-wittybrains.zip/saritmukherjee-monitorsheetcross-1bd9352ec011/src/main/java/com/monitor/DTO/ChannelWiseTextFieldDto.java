package com.monitor.DTO;

/**
 * It will store each field(String) data corresponds to a channel.
 * 
 * @author Wittybrains
 *
 */
public class ChannelWiseTextFieldDto {

	private Long channelId;

	private String channelName;

	private Long textFieldId;

	private String textFieldValue;

	private Boolean selection;

	public ChannelWiseTextFieldDto() {
	}

	public ChannelWiseTextFieldDto(Long channelId, String channelName, Long textFieldId, String textFieldValue) {
		this.channelId = channelId;
		this.channelName = channelName;
		this.textFieldId = textFieldId;
		this.textFieldValue = textFieldValue;
	}

	public ChannelWiseTextFieldDto(Long channelId, String channelName, Long textFieldId, String textFieldValue,
			Boolean selection) {
		this.channelId = channelId;
		this.channelName = channelName;
		this.textFieldId = textFieldId;
		this.textFieldValue = textFieldValue;
		this.selection = selection;
	}

	/**
	 * @return the channelId
	 */
	public Long getChannelId() {
		return channelId;
	}

	/**
	 * @param channelId
	 *            the channelId to set
	 */
	public void setChannelId(Long channelId) {
		this.channelId = channelId;
	}

	/**
	 * @return the channelName
	 */
	public String getChannelName() {
		return channelName;
	}

	/**
	 * @param channelName
	 *            the channelName to set
	 */
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	/**
	 * @return the textFieldId
	 */
	public Long getTextFieldId() {
		return textFieldId;
	}

	/**
	 * @param textFieldId
	 *            the textFieldId to set
	 */
	public void setTextFieldId(Long textFieldId) {
		this.textFieldId = textFieldId;
	}

	/**
	 * @return the textFieldValue
	 */
	public String getTextFieldValue() {
		return textFieldValue;
	}

	/**
	 * @param textFieldValue
	 *            the textFieldValue to set
	 */
	public void setTextFieldValue(String textFieldValue) {
		this.textFieldValue = textFieldValue;
	}

	/**
	 * @return the selection
	 */
	public Boolean getSelection() {
		return selection;
	}

	/**
	 * @param selection
	 *            the selection to set
	 */
	public void setSelection(Boolean selection) {
		this.selection = selection;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ChannelWiseTextFieldDto [channelId=" + channelId + ", channelName=" + channelName + ", textFieldId="
				+ textFieldId + ", textFieldValue=" + textFieldValue + ", selection=" + selection + "]";
	}
}
