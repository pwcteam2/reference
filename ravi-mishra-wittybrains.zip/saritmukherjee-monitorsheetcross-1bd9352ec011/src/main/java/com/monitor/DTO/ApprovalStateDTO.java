package com.monitor.DTO;


public class ApprovalStateDTO {

	private Boolean logsApproved = false;
	private Boolean summaryApproved = false;
	
	
	public Boolean getLogsApproved() {
		return logsApproved;
	}
	
	public void setLogsApproved(Boolean logsApproved) {
		this.logsApproved = logsApproved;
	}
	
	public Boolean getSummaryApproved() {
		return summaryApproved;
	}
	
	public void setSummaryApproved(Boolean summaryApproved) {
		this.summaryApproved = summaryApproved;
	}
	
	
}
