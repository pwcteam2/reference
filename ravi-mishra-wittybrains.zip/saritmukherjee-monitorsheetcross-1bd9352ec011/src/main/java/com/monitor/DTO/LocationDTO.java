package com.monitor.DTO;

import java.util.List;

import org.joda.time.DateTime;

public class LocationDTO {
	
	private Long locationId;
	private String locationName;
	private DateTime deletedDate;
	private DateTime createdDate;
	private DateTime modifiedDate;
	
	private List<PodDTO> podList;

	public Long getLocationId() {
		return locationId;
	}

	public void setLocationId(Long locationId) {
		this.locationId = locationId;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public DateTime getDeletedDate() {
		return deletedDate;
	}

	public void setDeletedDate(DateTime deletedDate) {
		this.deletedDate = deletedDate;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	public DateTime getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public List<PodDTO> getPodList() {
		return podList;
	}

	public void setPodList(List<PodDTO> podList) {
		this.podList = podList;
	}

	
	

}
