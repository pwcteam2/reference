package com.monitor.DTO;

import java.sql.Time;

import org.joda.time.DateTime;

public class ShiftDTO {
	private Long shiftId;
	private String Name;
	private Time startTime;
	private Time endTime;
	private boolean currentShift;
	private DateTime shiftStartDate;
	private DateTime ShiftEndDate;
	
	public Long getShiftId() {
		return shiftId;
	}
	
	public void setShiftId(Long shiftId) {
		this.shiftId = shiftId;
	}
	
	public String getName() {
		return Name;
	}
	
	public void setName(String name) {
		Name = name;
	}
	
	public Time getStartTime() {
		return startTime;
	}
	
	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}
	
	public Time getEndTime() {
		return endTime;
	}
	
	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}

	public boolean isCurrentShift() {
		return currentShift;
	}

	public void setCurrentShift(boolean currentShift) {
		this.currentShift = currentShift;
	}

	public DateTime getShiftStartDate() {
		return shiftStartDate;
	}

	public void setShiftStartDate(DateTime shiftStartDate) {
		this.shiftStartDate = shiftStartDate;
	}

	public DateTime getShiftEndDate() {
		return ShiftEndDate;
	}

	public void setShiftEndDate(DateTime shiftEndDate) {
		ShiftEndDate = shiftEndDate;
	}
	
	
	

}
