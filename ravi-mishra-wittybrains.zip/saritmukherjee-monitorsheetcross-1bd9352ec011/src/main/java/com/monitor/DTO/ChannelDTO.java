package com.monitor.DTO;

import org.joda.time.DateTime;

public class ChannelDTO {
	private Long channelId;
	private String channelName;
	private DateTime deletedDate;
	private DateTime createdDate;
	private boolean deleted;
	private PodDTO pod;
	private String nocNumber;
	private boolean disabled;

	public ChannelDTO() {
	}

	public ChannelDTO(Long channelId, String channelName, String nocNumber) {
		this.channelId = channelId;
		this.channelName = channelName;
		this.nocNumber = nocNumber;
	}
	
	public ChannelDTO(Long channelId, String channelName, String nocNumber, DateTime createdDate) {
		this.channelId = channelId;
		this.channelName = channelName;
		this.nocNumber = nocNumber;
		this.createdDate = createdDate;
	}

	public Long getChannelId() {
		return channelId;
	}

	public void setChannelId(Long channelId) {
		this.channelId = channelId;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public DateTime getDeletedDate() {
		return deletedDate;
	}

	public void setDeletedDate(DateTime deletedDate) {
		this.deletedDate = deletedDate;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public PodDTO getPod() {
		return pod;
	}

	public void setPod(PodDTO pod) {
		this.pod = pod;
	}

	public String getNocNumber() {
		return nocNumber;
	}

	public void setNocNumber(String nocNumber) {
		this.nocNumber = nocNumber;
	}

	public boolean isDisabled() {
		return disabled;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

}
