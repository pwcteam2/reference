package com.monitor.DTO;

import java.util.List;

/**
 * Used only for generating monitor sheet frontend view and as a data exchange
 * format.
 * 
 * @author Sarit Mukherjee
 *
 */
public class CategorySheetDto {

	private Long categoryId;

	private String categoryName;

	List<SubCategorySheet> subCategorySheetList;
	
	List<ChannelWiseBooleanFieldDto> channelWiseBooleanFieldList;

	public CategorySheetDto() {
	}

	public CategorySheetDto(Long categoryId, String categoryName) {
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<SubCategorySheet> getSubCategorySheetList() {
		return subCategorySheetList;
	}

	public void setSubCategorySheetList(List<SubCategorySheet> subCategorySheetList) {
		this.subCategorySheetList = subCategorySheetList;
	}

	public List<ChannelWiseBooleanFieldDto> getChannelWiseBooleanFieldList() {
		return channelWiseBooleanFieldList;
	}

	public void setChannelWiseBooleanFieldList(List<ChannelWiseBooleanFieldDto> channelWiseBooleanFieldList) {
		this.channelWiseBooleanFieldList = channelWiseBooleanFieldList;
	}

	@Override
	public String toString() {
		return "CategorySheet [categoryId=" + categoryId + ", categoryName=" + categoryName + ", subCategorySheetList="
				+ subCategorySheetList + ", channelWiseBooleanFieldList=" + channelWiseBooleanFieldList + "]";
	}

}
