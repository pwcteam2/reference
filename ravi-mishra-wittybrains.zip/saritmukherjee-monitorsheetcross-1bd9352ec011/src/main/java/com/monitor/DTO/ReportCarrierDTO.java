package com.monitor.DTO;

/**
 * ReportCarrierDTO will carry pdf report for the filter and its errors pdf in
 * Base64 String format.
 * 
 * @author Wittybrains
 *
 */
public class ReportCarrierDTO {

	private String base64PdfReport;
	
	private String base64ErrorReport;

	public ReportCarrierDTO(String base64PdfReport, String base64ErrorReport) {
		this.base64PdfReport = base64PdfReport;
		this.base64ErrorReport = base64ErrorReport;
	}

	public String getBase64PdfReport() {
		return base64PdfReport;
	}

	public void setBase64PdfReport(String base64PdfReport) {
		this.base64PdfReport = base64PdfReport;
	}

	public String getBase64ErrorReport() {
		return base64ErrorReport;
	}

	public void setBase64ErrorReport(String base64ErrorReport) {
		this.base64ErrorReport = base64ErrorReport;
	}
}
