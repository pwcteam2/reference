package com.monitor.DTO;

import java.util.List;

public class HtmlReportDTO {

	private Long monitorId;
	
	private String podName;
	
	private String shiftName;
	
	private String locationName;
	
	private String shiftDate;
	
	private TimeBracketDTO timeBracketDTO;
	
	private String endTime;
	
	private String errorMessage;
	
	private String shiftWiseTimeBracketMessage;
	
	private List<String> shiftWiseTimeDurations;

	public Long getMonitorId() {
		return monitorId;
	}

	public void setMonitorId(Long monitorId) {
		this.monitorId = monitorId;
	}

	public String getPodName() {
		return podName;
	}

	public void setPodName(String podName) {
		this.podName = podName;
	}

	public String getShiftName() {
		return shiftName;
	}

	public void setShiftName(String shiftName) {
		this.shiftName = shiftName;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getShiftDate() {
		return shiftDate;
	}

	public void setShiftDate(String shiftDate) {
		this.shiftDate = shiftDate;
	}

	public TimeBracketDTO getTimeBracketDTO() {
		return timeBracketDTO;
	}

	public void setTimeBracketDTO(TimeBracketDTO timeBracketDTO) {
		this.timeBracketDTO = timeBracketDTO;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getShiftWiseTimeBracketMessage() {
		return shiftWiseTimeBracketMessage;
	}

	public void setShiftWiseTimeBracketMessage(String shiftWiseTimeBracketMessage) {
		this.shiftWiseTimeBracketMessage = shiftWiseTimeBracketMessage;
	}

	public List<String> getShiftWiseTimeDurations() {
		return shiftWiseTimeDurations;
	}

	public void setShiftWiseTimeDurations(List<String> shiftWiseTimeDurations) {
		this.shiftWiseTimeDurations = shiftWiseTimeDurations;
	}

	@Override
	public String toString() {
		return "HtmlReportDTO [monitorId=" + monitorId + ", podName=" + podName + ", shiftName=" + shiftName
				+ ", locationName=" + locationName + ", shiftDate=" + shiftDate + ", timeBracketDTO=" + timeBracketDTO
				+ ", endTime=" + endTime + ", errorMessage=" + errorMessage + ", shiftWiseTimeBracketMessage="
				+ shiftWiseTimeBracketMessage + ", shiftWiseTimeDurations=" + shiftWiseTimeDurations + "]";
	}
}
