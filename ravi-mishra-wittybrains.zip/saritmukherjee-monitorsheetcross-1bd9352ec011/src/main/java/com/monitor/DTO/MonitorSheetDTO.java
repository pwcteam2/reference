package com.monitor.DTO;

import java.util.List;

import org.joda.time.DateTime;

import com.monitor.enums.Status;

public class MonitorSheetDTO {

	private Long monitorId;

	private Long podId;

	private Long shiftId;

	private DateTime shiftDate;

	private Long operatorId;
	
	private String operatorName;

	private String operatorRemarks;

	private String approverRemarks;

	private String approverName;

	private String startTime;

	private String endTime;

	private Status status;

	private Long configurationVersion;
	
	private Long configurationSheetId;

	private TimeBracketDTO timeBracketDTO;
	
	private String shiftWiseTimeBracketMessage;
	
	private List<String> shiftWiseTimeDurations;
	
	List<CategorySheetDto> categorySheetList;

	public Long getMonitorId() {
		return monitorId;
	}

	public void setMonitorId(Long monitorId) {
		this.monitorId = monitorId;
	}

	public Long getPodId() {
		return podId;
	}

	public void setPodId(Long podId) {
		this.podId = podId;
	}

	public Long getShiftId() {
		return shiftId;
	}

	public void setShiftId(Long shiftId) {
		this.shiftId = shiftId;
	}

	public DateTime getShiftDate() {
		return shiftDate;
	}

	public void setShiftDate(DateTime shiftDate) {
		this.shiftDate = shiftDate;
	}

	public Long getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	public String getOperatorRemarks() {
		return operatorRemarks;
	}

	public void setOperatorRemarks(String operatorRemarks) {
		this.operatorRemarks = operatorRemarks;
	}

	public String getApproverRemarks() {
		return approverRemarks;
	}

	public void setApproverRemarks(String approverRemarks) {
		this.approverRemarks = approverRemarks;
	}

	public String getApproverName() {
		return approverName;
	}

	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Long getConfigurationVersion() {
		return configurationVersion;
	}

	public void setConfigurationVersion(Long configurationVersion) {
		this.configurationVersion = configurationVersion;
	}

	public Long getConfigurationSheetId() {
		return configurationSheetId;
	}

	public void setConfigurationSheetId(Long configurationSheetId) {
		this.configurationSheetId = configurationSheetId;
	}

	public List<CategorySheetDto> getCategorySheetList() {
		return categorySheetList;
	}

	public void setCategorySheetList(List<CategorySheetDto> categorySheetList) {
		this.categorySheetList = categorySheetList;
	}

	/**
	 * @return the timeBracketDTO
	 */
	public TimeBracketDTO getTimeBracketDTO() {
		return timeBracketDTO;
	}

	/**
	 * @param timeBracketDTO the timeBracketDTO to set
	 */
	public void setTimeBracketDTO(TimeBracketDTO timeBracketDTO) {
		this.timeBracketDTO = timeBracketDTO;
	}

	public String getShiftWiseTimeBracketMessage() {
		return shiftWiseTimeBracketMessage;
	}

	public void setShiftWiseTimeBracketMessage(String shiftWiseTimeBracketMessage) {
		this.shiftWiseTimeBracketMessage = shiftWiseTimeBracketMessage;
	}

	public List<String> getShiftWiseTimeDurations() {
		return shiftWiseTimeDurations;
	}

	public void setShiftWiseTimeDurations(List<String> shiftWiseTimeDurations) {
		this.shiftWiseTimeDurations = shiftWiseTimeDurations;
	}

	@Override
	public String toString() {
		return "MonitorSheetDTO [monitorId=" + monitorId + ", podId=" + podId + ", shiftId=" + shiftId + ", shiftDate="
				+ shiftDate + ", operatorId=" + operatorId + ", operatorName=" + operatorName + ", operatorRemarks="
				+ operatorRemarks + ", approverRemarks=" + approverRemarks + ", approverName=" + approverName
				+ ", startTime=" + startTime + ", endTime=" + endTime + ", status=" + status + ", configurationVersion="
				+ configurationVersion + ", configurationSheetId=" + configurationSheetId + ", timeBracketDTO="
				+ timeBracketDTO + ", shiftWiseTimeBracketMessage=" + shiftWiseTimeBracketMessage
				+ ", shiftWiseTimeDurations=" + shiftWiseTimeDurations + ", categorySheetList=" + categorySheetList
				+ "]";
	}
}