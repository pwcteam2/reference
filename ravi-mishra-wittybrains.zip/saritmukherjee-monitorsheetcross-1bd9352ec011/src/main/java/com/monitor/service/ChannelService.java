package com.monitor.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.monitor.DTO.ChannelDTO;
import com.monitor.DTO.PodDTO;
import com.monitor.DTO.ShiftDTO;
import com.monitor.domain.Category;
import com.monitor.domain.Channel;
import com.monitor.domain.Location;
import com.monitor.domain.Pod;
import com.monitor.domain.Shift;
import com.monitor.domain.SubCategory;
import com.monitor.domain.TimeBracketDuration;
import com.monitor.domain.User;
import com.monitor.enums.PodAction;
import com.monitor.exception.ServiceException;
import com.monitor.repository.CategoryRepository;
import com.monitor.repository.ChannelRepository;
import com.monitor.repository.LocationRepository;
import com.monitor.repository.SubCategoryRepository;
import com.monitor.repository.TimeBracketDurationRepository;
import com.monitor.servicefinder.utils.Constants;
import com.monitor.utils.DateUtil;
import com.monitor.utils.ErrorConstants;
import com.monitor.utils.Utility;

@Service
public class ChannelService {

	private ChannelRepository channelRepository;
	private AuthenticationService authenticationService;
	private MonitorSheetService monitorSheetService;
	private ShiftService shiftService;
	private UserService userService;
	private PodService podService;
	private LocationRepository locationRepository;
	private CategoryService categoryService;
	private CategoryRepository categoryRepository;
	private SubCategoryRepository subCategoryRepository;
	private TimeBracketDurationRepository timeBracketDurationRepository;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	public ChannelService(ChannelRepository channelRepository, AuthenticationService authenticationService,
			@Lazy MonitorSheetService monitorSheetService, @Lazy ShiftService shiftService, UserService userService,
			PodService podService, LocationRepository locationRepository, CategoryService categoryService,
			CategoryRepository categoryRepository, SubCategoryRepository subCategoryRepository,
			TimeBracketDurationRepository timeBracketDurationRepository) {
		this.channelRepository = channelRepository;
		this.authenticationService = authenticationService;
		this.monitorSheetService = monitorSheetService;
		this.shiftService = shiftService;
		this.userService = userService;
		this.podService = podService;
		this.locationRepository = locationRepository;
		this.categoryService = categoryService;
		this.categoryRepository = categoryRepository;
		this.subCategoryRepository = subCategoryRepository;
		this.timeBracketDurationRepository = timeBracketDurationRepository;
	}

	public List<ChannelDTO> getAllChannels(String selectedDate, Long selectedShift, Long podId)
			throws ServiceException {
		logger.info("Getting all channels for podId: " + podId);
		User user = authenticationService.getAuthenticatedUser();

		// Getting all enabled channels.
		Set<Channel> channels = findByPodPodIdOrderByCreatedDateAsc(podId);

		return getChannelListForSupervisor(selectedDate, selectedShift, channels);
	}

	public List<PodDTO> getAllPods(Long locationId, Boolean alphabeticalOrder) throws ServiceException {
		logger.info("Getting all pods for locationId: " + locationId);
		authenticationService.getAuthenticatedUser();
		logger.info("Successully got all pods for locationId: " + locationId);
		List<PodDTO> allPods = podService.getAllPods(locationId);

		// Conditional sorting if required. Used in dropdown.
		if (alphabeticalOrder != null && alphabeticalOrder) {
			allPods = allPods.stream().sorted((o1, o2) -> o1.getPodName().compareToIgnoreCase(o2.getPodName()))
					.collect(Collectors.toList());
		}
		return allPods;
	}

	public Long[] getAllIds() {
		return channelRepository.getAllIds();
	}

	private List<ChannelDTO> getChannelListForSupervisor(String selectedDate, Long selectedShift,
			Set<Channel> channels) {

		DateTime startDate = selectedDate == null || selectedDate == "" ? DateUtil.resetTime(new DateTime())
				: DateUtil.resetTime(DateUtil.getFormattedDateTime(selectedDate, "dd-MM-YYYY"));
		DateTime endDate = new DateTime(startDate).plusDays(1).minusSeconds(1);
		Shift shift = selectedShift == null || selectedShift == 0 ? shiftService.getCurrentShift()
				: shiftService.findById(selectedShift);
		List<ChannelDTO> channelDtos = new ArrayList<ChannelDTO>();

		for (Channel channel : channels) {
			ChannelDTO channelDto = new ChannelDTO();
			channelDto.setChannelId(channel.getChannelId());
			channelDto.setChannelName(channel.getChannelName());
			channelDto.setDisabled(channel.isDisabled());
			channelDto.setCreatedDate(channel.getCreatedDate());
			channelDto.setNocNumber(channel.getNocNumber());
			channelDtos.add(channelDto);
		}

		logger.info("Successully got all channels");
		return channelDtos;
	}

	public ChannelDTO addChannel(ChannelDTO channelDTO) throws ServiceException {
		logger.info("Adding Channel: " + channelDTO.getChannelName() + " for pod: " + channelDTO.getPod().getPodName());
		User loggedInUser = authenticationService.getAuthenticatedUser();
		Channel newlyAdded;

		if (userService.isManager(loggedInUser)) {
			logger.debug("channel added by " + loggedInUser.getFullName());

			if (Utility.isStringEmpty(channelDTO.getChannelName())) {
				throw new ServiceException(ErrorConstants.NAME_CANNOT_BE_EMPTY.replace("&E", "Channel"));
			}

			// Will validate channel name length
			Utility.validateStringLength(channelDTO.getChannelName(), "Channel", Constants.CHANNEL_LENGTH);
			Utility.validateStringLength(channelDTO.getNocNumber(), "Noc number", Constants.NOC_LENGTH);

			Channel existingChannel = channelRepository.findByChannelNameInAndPodPodIdIn(channelDTO.getChannelName(),
					channelDTO.getPod().getPodId());

			Pod pod = podService.findById(channelDTO.getPod().getPodId());
			if (pod == null) {
				throw new ServiceException(ErrorConstants.DOES_NOT_EXIST.replace("&E", "Pod"));
			}

			// Can't alter if parent pod is disabled.
			if (pod.isDisabled())
				throw new ServiceException(ErrorConstants.CANNOT_ADD_POD_DISABLED.replace("&E", "Channel"));

			// All sheet approval needed for all pods before config
			monitorSheetService.configEligibility(pod.getPodId(), false);

			if (existingChannel != null) {
				throw new ServiceException(ErrorConstants.NAME_ALREADY_EXISTS.replace("&E", "Channel").replace("&V",
						channelDTO.getChannelName()));
			}

			// if (channelDTO.getNocNumber() == null ||
			// channelDTO.getNocNumber() == 0) {
			// throw new ServiceException("Noc number cannot be empty");
			// }

			// Channel channelByNoc =
			// findByNocNumberAndPodPodId(channelDTO.getNocNumber(),
			// channelDTO.getPod().getPodId());
			//
			// if (channelByNoc != null) {
			// throw new ServiceException("Channel with Noc number " +
			// channelDTO.getNocNumber() + " already exist");
			// }

			Channel channel = new Channel();
			channel.setChannelName(channelDTO.getChannelName());
			channel.setCreatedDate(DateTime.now());
			channel.setModifiedDate(DateTime.now());
			channel.setNocNumber(channelDTO.getNocNumber());
			channel.setAddedBy(loggedInUser);
			channel.setPod(pod);


			/* podService.save(pod); */

			// Incrementing the config version of the pod for detecting change
			// in monitor sheet in case operator trying to save old config
			// sheet.
			monitorSheetService.storePodHistory(pod, PodAction.CHANNELADDED);
			
			pod.getChannelList().add(channel);
			pod.setConfigurationVersion(pod.getConfigurationVersion() + 1l);

			channel = channelRepository.save(channel);

			newlyAdded = pod.getChannelList().get(pod.getChannelList().size() - 1);// channelRepository.save(channel);

			logger.info("Successfully added Channel: " + channel.getChannelName() + " for pod: "
					+ channel.getPod().getPodName());

		} else {
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&V", "add").replace("&E", "Channels"));
		}

		return getChannelDto(newlyAdded);
	}

	public void editChannel(ChannelDTO channelDTO) throws ServiceException {
		logger.info("Editing ChannelId: " + channelDTO.getChannelId());
		User loggedInUser = authenticationService.getAuthenticatedUser();

		if (userService.isManager(loggedInUser)) {
			logger.debug("channel added by " + loggedInUser.getFullName());

			if (Utility.isStringEmpty(channelDTO.getChannelName())) {
				throw new ServiceException(ErrorConstants.NAME_CANNOT_BE_EMPTY.replace("&E", "Channel"));
			}

			// Will validate channel name length
			Utility.validateStringLength(channelDTO.getChannelName(), "Channel", Constants.CHANNEL_LENGTH);
			Utility.validateStringLength(channelDTO.getNocNumber(), "Noc number", Constants.NOC_LENGTH);

			if (channelDTO.getPod() == null || channelDTO.getPod().getPodId() == null) {
				throw new ServiceException(ErrorConstants.CANNOT_BE_EMPTY.replace("&E", "Pod"));
			}

			// if (channelDTO.getNocNumber() == null ||
			// channelDTO.getNocNumber() < 1) {
			// throw new ServiceException("Noc Number cannot be empty");
			// }

			Channel channel = channelRepository.findByChannelNameInAndPodPodIdIn(channelDTO.getChannelName(),
					channelDTO.getPod().getPodId());

			if (channel != null && !channel.getChannelId().equals(channelDTO.getChannelId())) {
				throw new ServiceException(ErrorConstants.NAME_ALREADY_EXISTS.replace("&E", "Channel").replace("&V",
						channelDTO.getChannelName()));
			}

			// channel =
			// channelRepository.findByNocNumberAndPodPodId(channelDTO.getNocNumber(),
			// channelDTO.getPod().getPodId());
			//
			// if (channel != null &&
			// !channel.getChannelId().equals(channelDTO.getChannelId())) {
			// throw new ServiceException("channel with noc number " +
			// channelDTO.getNocNumber() + " already exist");
			// }

			Channel channelToEdit = channelRepository.findByChannelId(channelDTO.getChannelId());

			// Can't alter if parent pod is disabled.
			if (channelToEdit.getPod().isDisabled())
				throw new ServiceException(ErrorConstants.CANNOT_ALTER_POD_DISABLED.replace("&E", "Channel"));

			// All sheet approval needed for all pods before config
			monitorSheetService.configEligibility(channelToEdit.getPod().getPodId(), false);

			// Used in monitor sheet so cant edit
			if (monitorSheetService.checkIfChannelExists(channelToEdit.getChannelId()))
				throw new ServiceException(ErrorConstants.CANNOT_PERFORM_USED_IN_MONITOR_SHEET.replace("&V", "edit")
						.replace("&E", "Channel"));

			// Incrementing the config version of the pod for detecting change
			// in monitor sheet in case operator trying to save old config
			// sheet.
			if (!StringUtils.equalsIgnoreCase(channelToEdit.getChannelName(), channelDTO.getChannelName())
					|| !StringUtils.equalsIgnoreCase(channelToEdit.getNocNumber(), channelDTO.getNocNumber())) {
				monitorSheetService.storePodHistory(channelToEdit.getPod(), PodAction.CHANNELEDITED);
				channelToEdit.getPod().setConfigurationVersion(channelToEdit.getPod().getConfigurationVersion() + 1l);
			}

			channelToEdit.setChannelName(channelDTO.getChannelName());
			channelToEdit.setNocNumber(channelDTO.getNocNumber());
			channelToEdit.setModifiedDate(DateTime.now());

			channelRepository.save(channelToEdit);
			logger.info("Successfully edited Channel: " + channelDTO.getChannelName() + " to "
					+ channelToEdit.getChannelName() + " for pod: " + channelToEdit.getPod().getPodName());

		} else {
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&V", "edit").replace("&E", "Channels"));
		}

	}

	public void editPod(PodDTO podDTO) throws ServiceException {
		logger.info("Editing podId: " + podDTO.getPodId());
		User loggedInUser = authenticationService.getAuthenticatedUser();

		if (userService.isManager(loggedInUser)) {
			logger.debug("podDTO edited by " + loggedInUser.getFullName());

			if (Utility.isStringEmpty(podDTO.getPodName())) {
				throw new ServiceException(ErrorConstants.NAME_CANNOT_BE_EMPTY.replace("&E", "Pod"));
			}

			// Will validate pod name length
			Utility.validateStringLength(podDTO.getPodName(), "Pod", Constants.POD_LENGTH);

			Pod pod = podService.findByPodNameInAndLocationLocationIdIn(podDTO.getPodName(),
					podDTO.getLocation().getLocationId());
			if (pod != null && !pod.getPodId().equals(podDTO.getPodId())) {
				throw new ServiceException(
						ErrorConstants.NAME_ALREADY_EXISTS.replace("&E", "Pod").replace("&V", podDTO.getPodName()));
			}

			Pod podToEdit = podService.findById(podDTO.getPodId());

			// Validate
			if (podToEdit == null)
				throw new ServiceException(
						ErrorConstants.ID_INVALID.replace("&E", "Pod").replace("&V", podDTO.getPodId().toString()));

			// Can't alter if parent location is disabled.
			if (podToEdit.getLocation().isDisabled())
				throw new ServiceException(ErrorConstants.CANNOT_ALTER_LOCATION_DISABLED.replace("&E", "Pod"));

			// All sheet approval needed for all pods before config
			monitorSheetService.configEligibility(podToEdit.getPodId(), false);

			Long timeBracketDurationId = podDTO.getTimeBracketDurationId();
			if (timeBracketDurationId == null)
				throw new ServiceException(
						ErrorConstants.MANDATORY_FIELD_ID_SHOULD_BE_GIVEN.replace("&E", "Time bracket duration"));

			TimeBracketDuration timeBracketDuration = timeBracketDurationRepository.findOne(timeBracketDurationId);
			if (timeBracketDuration == null)
				throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Time bracket duration")
						.replace("&V", timeBracketDurationId.toString()));

			Integer timeBracketInMinutes = timeBracketDuration.getDuration();

			List<ShiftDTO> allShift = shiftService.getAllShift();
			// The given time bracket in minutes for a pod should divide a shift
			// into a whole number of time brackets. Like for a 12 hours shift,
			// 30
			// mins of time bracket means total 24 time brackets. Here 24 is a
			// whole
			// number. It should not be like 15.6 or 24.5 etc.
			if ((24 * 60 / allShift.size()) % timeBracketInMinutes != 0)
				throw new ServiceException(ErrorConstants.IS_INVALID_TRY_DIFF.replace("&E", "Time Bracket")
						.replace("&V", timeBracketInMinutes.toString()));

			// Cant be edited if used in monitor sheet
			if (monitorSheetService.checkIfPodExists(podToEdit.getPodId()))
				if (!podToEdit.getPodName().equalsIgnoreCase(podDTO.getPodName()))
					throw new ServiceException(ErrorConstants.CANNOT_PERFORM_USED_IN_MONITOR_SHEET.replace("&V", "edit")
							.replace("&E", "Pod"));
				else if (podToEdit.getTimeBracketInMinutes().intValue() != timeBracketInMinutes.intValue())
					throw new ServiceException(
							ErrorConstants.CANNOT_CHANGE_TIMEBRACKET_DURATION_OF_POD_USED_IN_MONITOR_SHEET);

			// Incrementing the config version of the pod for detecting change
			// in monitor sheet in case operator trying to save old config
			// sheet.
			if (!StringUtils.equalsIgnoreCase(podToEdit.getPodName(), podDTO.getPodName())) {
				monitorSheetService.storePodHistory(podToEdit, PodAction.PODEDITED);
				podToEdit.setConfigurationVersion(podToEdit.getConfigurationVersion() + 1l);
			}

			podToEdit.setPodName(podDTO.getPodName());
			podToEdit.setModifiedDate(DateTime.now());
			podToEdit.setTimeBracketInMinutes(timeBracketInMinutes);

			podService.save(podToEdit);
			logger.info("Successfully edited pod: " + podDTO.getPodName() + " to " + podToEdit.getPodName()
					+ " for location: " + podToEdit.getLocation().getLocationName());

		} else {
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Pods").replace("&V", "edit"));
		}

	}

	public PodDTO addPod(PodDTO podDTO) throws ServiceException {
		logger.info("Adding pod: " + podDTO.getPodName() + " for location: " + podDTO.getLocation().getLocationName());
		User loggedInUser = authenticationService.getAuthenticatedUser();
		if (userService.isManager(loggedInUser)) {
			logger.debug("Pod added by " + loggedInUser.getFullName());

			if (Utility.isStringEmpty(podDTO.getPodName())) {
				throw new ServiceException(ErrorConstants.NAME_CANNOT_BE_EMPTY.replace("&E", "Pod"));
			}

			// Will validate pod name length
			Utility.validateStringLength(podDTO.getPodName(), "Pod", Constants.POD_LENGTH);

			Pod existingPod = podService.findByPodNameInAndLocationLocationIdIn(podDTO.getPodName(),
					podDTO.getLocation().getLocationId());
			Location location = locationRepository.findByLocationId(podDTO.getLocation().getLocationId());

			if (location == null) {
				throw new ServiceException(ErrorConstants.DOES_NOT_EXIST.replace("&E", "Location"));
			}

			// Can't alter if parent location is disabled.
			if (location.isDisabled())
				throw new ServiceException(ErrorConstants.CANNOT_ADD_LOCATION_DISABLED.replace("&E", "Pod"));

			if (existingPod != null) {
				throw new ServiceException(
						ErrorConstants.NAME_ALREADY_EXISTS.replace("&E", "Pod").replace("&V", podDTO.getPodName()));
			}

			Long timeBracketDurationId = podDTO.getTimeBracketDurationId();
			if (timeBracketDurationId == null)
				throw new ServiceException(
						ErrorConstants.MANDATORY_FIELD_ID_SHOULD_BE_GIVEN.replace("&E", "Time bracket duration"));

			TimeBracketDuration timeBracketDuration = timeBracketDurationRepository.findOne(timeBracketDurationId);
			if (timeBracketDuration == null)
				throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Time bracket duration")
						.replace("&V", timeBracketDurationId.toString()));

			Integer timeBracketInMinutes = timeBracketDuration.getDuration();
			List<ShiftDTO> allShift = shiftService.getAllShift();
			// The given time bracket in minutes for a pod should divide a shift
			// into a whole number of time brackets. Like for a 12 hours shift,
			// 30
			// mins of time bracket means total 24 time brackets. Here 24 is a
			// whole
			// number. It should not be like 15.6 or 24.5 etc.
			if ((24 * 60 / allShift.size()) % timeBracketInMinutes != 0)
				throw new ServiceException(ErrorConstants.IS_INVALID_TRY_DIFF.replace("&E", "Time Bracket")
						.replace("&V", timeBracketInMinutes.toString()));

			Pod newPod = new Pod();
			newPod.setPodName(podDTO.getPodName());
			newPod.setCreatedDate(DateTime.now());
			newPod.setModifiedDate(DateTime.now());
			newPod.setAddedBy(loggedInUser);
			newPod.setTimeBracketInMinutes(timeBracketInMinutes);
			location.getPodList().add(newPod);
			newPod.setLocation(location);

			logger.info("Successfully added pod: " + newPod.getPodName() + " for location: "
					+ newPod.getLocation().getLocationName());
			return podService.getPodDto(podService.save(newPod));
		} else {
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Pods").replace("&V", "add"));
		}

	}

	public void deleteChannel(Long channelId) throws ServiceException {
		logger.info("Deleting ChannelId: " + channelId);
		User loggedInUser = authenticationService.getAuthenticatedUser();

		if (userService.isManager(loggedInUser)) {
			if (channelId == null || channelId == 0) {
				logger.error("Channel cannot be empty");
				throw new ServiceException(ErrorConstants.CANNOT_BE_EMPTY.replace("&E", "Channel"));
			}

			Channel channel = channelRepository.findByChannelId(channelId);

			if (channel == null) {
				logger.error("Channel with id " + channelId + " not found");
				throw new ServiceException(
						ErrorConstants.ID_INVALID.replace("&E", "Channel").replace("&V", channelId.toString()));
			}

			// Can't alter if parent pod is disabled.
			if (channel.getPod().isDisabled())
				throw new ServiceException(ErrorConstants.CANNOT_ALTER_POD_DISABLED.replace("&E", "Channel"));

			// All sheet approval needed for all pods before config
			monitorSheetService.configEligibility(channel.getPod().getPodId(), false);

			logger.debug(channel.getChannelName() + " deleted by " + loggedInUser.getFirstName() + " "
					+ loggedInUser.getLastName());

			// Used in monitor sheet so cat delete
			if (monitorSheetService.checkIfChannelExists(channelId))
				throw new ServiceException(ErrorConstants.CANNOT_PERFORM_USED_IN_MONITOR_SHEET.replace("&V", "delete")
						.replace("&E", "Channel"));

			// Incrementing the config version of the pod for detecting change
			// in monitor sheet in case operator trying to save old config
			// sheet.
			monitorSheetService.storePodHistory(channel.getPod(), PodAction.CHANNELDELETED);
			channel.getPod().setConfigurationVersion(channel.getPod().getConfigurationVersion() + 1l);

			channelRepository.delete(channel);
			logger.info("Successfully deleted Channel: " + channel.getChannelName() + " for pod: "
					+ channel.getPod().getPodName());
		} else {
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&V", "delete").replace("&E", "Channels"));
		}
	}

	public void deletePod(Long podId) throws ServiceException {
		logger.info("Deleting podId: " + podId);
		User loggedInUser = authenticationService.getAuthenticatedUser();

		if (userService.isManager(loggedInUser)) {
			if (podId == null || podId == 0) {
				logger.error("pod cannot be empty");
				throw new ServiceException(ErrorConstants.CANNOT_BE_EMPTY.replace("&E", "Pod"));
			}

			Pod pod = podService.findById(podId);
			long count = getChannelCount(pod);

			// Validate
			if (pod == null)
				throw new ServiceException(
						ErrorConstants.ID_INVALID.replace("&E", "Pod").replace("&V", podId.toString()));

			// Can't alter if parent location is disabled.
			if (pod.getLocation().isDisabled())
				throw new ServiceException(ErrorConstants.CANNOT_ALTER_LOCATION_DISABLED.replace("&E", "Pod"));

			// All sheet approval needed for all pods before config
			monitorSheetService.configEligibility(pod.getPodId(), false);

			if (count > 0) {
				logger.error("Pod cannot be deleted because it has associated channels");
				throw new ServiceException(ErrorConstants.CANNOT_DELETE_ASSOCIATED_WITH_ENTITIES.replace("&E", "Pod")
						.replace("&&**", pod.getPodName()).replace("$$**", String.valueOf(count))
						.replace("$$$$", "Channels").replace("&V", "deleted"));
			}

			long categoryCount = categoryService.countByPodPodId(podId);
			if (categoryCount > 0)
				throw new ServiceException(ErrorConstants.CANNOT_DELETE_ASSOCIATED_WITH_ENTITIES.replace("&E", "Pod")
						.replace("&&**", pod.getPodName()).replace("$$**", String.valueOf(categoryCount))
						.replace("$$$$", "Categories").replace("&V", "deleted"));

			logger.debug(
					pod.getPodName() + " deleted by " + loggedInUser.getFirstName() + " " + loggedInUser.getLastName());

			// Incrementing the config version of the pod for detecting change
			// in monitor sheet in case operator trying to save old config
			// sheet.
			monitorSheetService.storePodHistory(pod, PodAction.PODDELETED);
			pod.setConfigurationVersion(pod.getConfigurationVersion() + 1l);

			podService.deletePod(pod);
			logger.info("Successfully deleted pod: " + pod.getPodName() + " for location "
					+ pod.getLocation().getLocationName());
		} else {
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&V", "delete").replace("&E", "Pods"));
		}
	}

	private Set<Channel> findByPodPodIdOrderByCreatedDateAsc(Long podId) {
		// getting all enable channels
		return channelRepository.findByPodPodIdOrderByCreatedDateAsc(podId);
	}

	public Channel findById(Long channelId) {
		return channelRepository.findByChannelId(channelId);
	}

	public Set<Channel> findByChannelIn(List<Long> ids) {
		return channelRepository.findByChannelIdInOrderByChannelName(ids);
	}

	public long getChannelCount(Pod pod) {
		return channelRepository.countByPod(pod);
	}

	public Channel findByNocNumberAndPodPodId(String nocNumber, Long podId) {
		return channelRepository.findByNocNumberAndPodPodId(nocNumber, podId);
	}

	private ChannelDTO getChannelDto(Channel channel) {
		ChannelDTO dto = new ChannelDTO();
		dto.setChannelId(channel.getChannelId());
		dto.setChannelName(channel.getChannelName());
		dto.setCreatedDate(channel.getCreatedDate());
		return dto;
	}

	public Long countByPodPodId(Long podId) {
		return channelRepository.countByPodPodId(podId);
	}

	public Long countByPodPodIdAndDisabled(Long podId, Boolean disabled) {
		return channelRepository.countByPodPodIdAndDisabled(podId, disabled);
	}

	public void disablePod(Long podId, Boolean disable) throws ServiceException {
		User user = authenticationService.getAuthenticatedUser();
		if (!userService.isManager(user)) {
			logger.error("Pod can only disabled by a manager");
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&V", "disable").replace("&E", "Pods"));
		}

		Pod pod = podService.findById(podId);
		if (pod == null)
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Pod").replace("&V", podId.toString()));

		if (pod.getLocation().isDisabled())
			throw new ServiceException(ErrorConstants.CANNOT_ALTER_LOCATION_DISABLED.replace("&E", "Pod"));

		// All sheet approval needed for all pods before config
		monitorSheetService.configEligibility(pod.getPodId(), false);

		for (Category category : pod.getCategoryList()) {
			for (SubCategory subCategory : category.getSubCategoryList()) {
				subCategory.setDisabled(disable);
				subCategoryRepository.saveAndFlush(subCategory);
			}
			category.setDisabled(disable);
			categoryRepository.saveAndFlush(category);
		}

		for (Channel channel : pod.getChannelList()) {
			channel.setDisabled(disable);
			saveAndFlush(channel);
		}

		// Incrementing the config version of the pod for detecting change
		// in monitor sheet in case operator trying to save old config
		// sheet.
		monitorSheetService.storePodHistory(pod, PodAction.PODDISABLED);
		pod.setConfigurationVersion(pod.getConfigurationVersion() + 1l);

		pod.setDisabled(disable);
		podService.saveAndFlush(pod);
	}

	public void disableChannel(Long channelId, Boolean disable) throws ServiceException {
		User user = authenticationService.getAuthenticatedUser();
		if (!userService.isManager(user)) {
			logger.error("Channel can only disabled by a manager");
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Channels").replace("&V", "disable"));
		}

		Channel channel = findById(channelId);
		if (channel == null)
			throw new ServiceException(
					ErrorConstants.ID_INVALID.replace("&E", "Channel").replace("&V", channelId.toString()));

		// Can't alter if parent pod is disabled.
		if (channel.getPod().isDisabled())
			throw new ServiceException(ErrorConstants.CANNOT_ALTER_POD_DISABLED.replace("&E", "Channel"));

		// All sheet approval needed for all pods before config
		monitorSheetService.configEligibility(channel.getPod().getPodId(), false);

		// Incrementing the config version of the pod for detecting change
		// in monitor sheet in case operator trying to save old config
		// sheet.
		monitorSheetService.storePodHistory(channel.getPod(), PodAction.CHANNELDISABLED);
		channel.getPod().setConfigurationVersion(channel.getPod().getConfigurationVersion() + 1l);

		channel.setDisabled(disable);
		channelRepository.saveAndFlush(channel);
	}

	public Channel saveAndFlush(Channel channel) {
		return channelRepository.saveAndFlush(channel);
	}

	public List<ChannelDTO> findByPodPodIdAndDisabledOrderByCreatedDateAsc(Long podId, Boolean disabled) {
		List<ChannelDTO> channelDTOList = new ArrayList<>();
		for (Channel channel : channelRepository.findByPodPodIdAndDisabledOrderByCreatedDateAsc(podId, disabled)) {
			channelDTOList
					.add(new ChannelDTO(channel.getChannelId(), channel.getChannelName(), channel.getNocNumber()));
		}
		return channelDTOList;
	}
}
