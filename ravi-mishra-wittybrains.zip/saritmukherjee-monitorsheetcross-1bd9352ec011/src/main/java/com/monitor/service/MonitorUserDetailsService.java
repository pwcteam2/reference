package com.monitor.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.monitor.domain.User;
import com.monitor.security.MonitorUserDetails;
import com.monitor.utils.ErrorConstants;

/**
 * Handles user's authentication.
 * 
 */
@Component
public class MonitorUserDetailsService implements UserDetailsService {

	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

	@Autowired
	protected UserService userService;

	@Autowired
	protected MessageSource messageSource;


	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private AuthenticationManager authManager;

	/**
	 * Checks user's credentials (email and password), if he belongs to the firm, 
	 *
	 * @param username the username
	 * @return the user details
	 * @throws UsernameNotFoundException the username not found exception
	 */
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		LOGGER.debug("User authenticated");
		
		User user = userService.findByEmail(email);

		if (user == null) {
			throw new UsernameNotFoundException(ErrorConstants.EMAIL_OR_PASSWORD_INCORRECT);
		} else if (user.isDeleted()) {
//			String message = getMessage("Deleted Account, Please contact Manager");
			throw new LockedException(ErrorConstants.DELETED_ACCOUNT_CONTACT_MANAGER);
		}else if(!user.isActive()){
			throw new DisabledException(ErrorConstants.INACTIVE_ACCOUNT_CONTACT_MANAGER);
		}

		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

		authorities.add(new SimpleGrantedAuthority("ROLE_CLIENT"));

		UserDetails userDetails = new MonitorUserDetails(user.getUserId(), email, user.getPassword(), authorities);
		return userDetails;


	}
	
	private String getMessage(String messageKey) {
	
		String m = messageSource.getMessage(messageKey, null, null);
		return m;
			
	}

	@Bean
	public AuthenticationProvider daoAuthenticationProvider() {
	    DaoAuthenticationProvider impl = new DaoAuthenticationProvider();
	    impl.setUserDetailsService(this);
	    impl.setHideUserNotFoundExceptions(false) ;
	    return impl ;
	}
	
	
}