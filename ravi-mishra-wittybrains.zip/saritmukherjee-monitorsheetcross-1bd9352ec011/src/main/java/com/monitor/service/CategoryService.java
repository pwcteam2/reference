package com.monitor.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.monitor.ApplicationInitializer;
import com.monitor.DTO.CategoryDTO;
import com.monitor.domain.Category;
import com.monitor.domain.Pod;
import com.monitor.domain.SubCategory;
import com.monitor.domain.User;
import com.monitor.enums.PodAction;
import com.monitor.exception.ServiceException;
import com.monitor.repository.CategoryRepository;
import com.monitor.servicefinder.utils.Constants;
import com.monitor.utils.ErrorConstants;
import com.monitor.utils.Utility;

@Service
public class CategoryService {

	private CategoryRepository categoryRepository;
	private AuthenticationService authenticationService;
	private UserService userSerice;
	private PodService podService;
	private SubCategoryService subCategoryService;
	private MonitorSheetService monitorSheetService;
	private static final Logger logger = LoggerFactory.getLogger(ApplicationInitializer.class);

	@Autowired
	public CategoryService(CategoryRepository categoryRepository, AuthenticationService authenticationService,
			UserService userService, PodService podService, @Lazy SubCategoryService subCategoryService,
			@Lazy MonitorSheetService monitorSheetService) {
		this.categoryRepository = categoryRepository;
		this.authenticationService = authenticationService;
		this.userSerice = userService;
		this.podService = podService;
		this.subCategoryService = subCategoryService;
		this.monitorSheetService = monitorSheetService;
	}

	public Category findCategoryByName(String CategoryName) {
		return categoryRepository.findByCategoryName(CategoryName);
	}

	public Category findByCategoryNameAndPodId(String categoryName, Long podId) {
		return categoryRepository.findByCategoryNameAndPodPodId(categoryName, podId);
	}

	public Category findCategoryById(Long CategoryId) {
		return categoryRepository.findByCategoryId(CategoryId);
	}

	public Set<Category> findAllCategoryByPod(Long podId) {
		return categoryRepository.findByPodPodIdOrderByCreatedDateAsc(podId);
	}

	/**
	 * Will get all categories with disabled state asked in param.
	 * 
	 * @param podId
	 * @param disabled
	 * @return
	 */
	public Set<Category> findAllCategoryByPodAndDisabled(Long podId, boolean disabled) {
		return categoryRepository.findByPodPodIdAndDisabledOrderByCreatedDateAsc(podId, disabled);
	}

	/**
	 * If alphabeticalOrder is true then ordering will be alphabetically.
	 * 
	 * @param podId
	 * @param alphabeticalOrder
	 * @return
	 * @throws ServiceException
	 */
	public List<CategoryDTO> getAllCategoriesByPod(Long podId, Boolean alphabeticalOrder) throws ServiceException {
		logger.info("Getting all Categories for podId: " + podId);
		authenticationService.getAuthenticatedUser();
		Set<Category> categories = findAllCategoryByPod(podId);
		List<CategoryDTO> categoryDtoList = new ArrayList<CategoryDTO>();

		for (Category categorie : categories) {
			CategoryDTO categoryDto = new CategoryDTO(categorie.getCategoryId(), categorie.getCategoryName(),
					categorie.isDisabled(), categorie.getPod().getPodId());

			categoryDtoList.add(categoryDto);
		}

		// Conditional sorting if required. Used in dropdown.
		if (alphabeticalOrder != null && alphabeticalOrder) {
			categoryDtoList = categoryDtoList.stream()
					.sorted((o1, o2) -> o1.getCategoryName().compareToIgnoreCase(o2.getCategoryName()))
					.collect(Collectors.toList());
		}
		logger.info("Successfully got all Categories for podId: " + podId);
		return categoryDtoList;
	}

	public CategoryDTO addCategory(CategoryDTO categoryDto) throws ServiceException {
		logger.info("Adding Category: " + categoryDto.getCategoryName() + " for podId: " + categoryDto.getPodId());
		User loggedinUser = authenticationService.getAuthenticatedUser();

		if (!userSerice.isManager(loggedinUser)) {
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Categories").replace("&V", "add"));
		}

		if (Utility.isIdEmpty(categoryDto.getPodId())) {
			throw new ServiceException(ErrorConstants.ID_CANNOT_BE_EMPTY.replace("&E", "Pod"));
		}

		Pod pod = podService.findById(categoryDto.getPodId());

		if (Utility.isStringEmpty(categoryDto.getCategoryName())) {
			throw new ServiceException(ErrorConstants.NAME_CANNOT_BE_EMPTY.replace("&E", "Category"));
		}
		// Will validate category name length
		Utility.validateStringLength(categoryDto.getCategoryName(), "Category", Constants.CATEGORY_LENGTH);

		Category existingCategory = findByCategoryNameAndPodId(categoryDto.getCategoryName(), categoryDto.getPodId());

		if (existingCategory != null) {
			throw new ServiceException(ErrorConstants.NAME_ALREADY_EXISTS.replace("&E", "Category").replace("&V",
					categoryDto.getCategoryName()));
		}

		// Can't alter if it's pod is disabled
		if (pod.isDisabled())
			throw new ServiceException(ErrorConstants.CANNOT_ADD_POD_DISABLED.replace("&E", "Category"));

		// All sheet approval needed for all pods before config
		monitorSheetService.configEligibility(pod.getPodId(), false);

		Category category = new Category();
		category.setCategoryName(categoryDto.getCategoryName());
		category.setDisabled(false);
		category.setCreatedDate(DateTime.now());
		category.setModifiedDate(DateTime.now());
		category.setPod(pod);

		if (pod.getCategoryList() == null) {
			pod.setCategoryList(new ArrayList<Category>());
		}

		// Incrementing the config version of the pod for detecting change
		// in monitor sheet in case operator trying to save old config
		// sheet.
		monitorSheetService.storePodHistory(pod, PodAction.CATEGORYADDED);
		pod.setConfigurationVersion(pod.getConfigurationVersion() + 1l);

		pod.getCategoryList().add(category);
		category = categoryRepository.save(category);
		logger.info("Successfully added Category: " + category.getCategoryName() + " for pod: "
				+ category.getPod().getPodName());
		return new CategoryDTO(category.getCategoryId(), category.getCategoryName(), category.isDisabled(),
				category.getPod().getPodId());
	}

	public CategoryDTO editCategory(CategoryDTO categoryDto) throws ServiceException {
		logger.info("Editing CategoryId: " + categoryDto.getCategoryId());
		User loggedinUser = authenticationService.getAuthenticatedUser();

		if (!userSerice.isManager(loggedinUser)) {
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Categories").replace("&V", "edit"));
		}

		if (categoryDto.getCategoryName() == null || categoryDto.getCategoryName().isEmpty()) {
			throw new ServiceException(ErrorConstants.NAME_CANNOT_BE_EMPTY.replace("&E", "Category"));
		}

		// Will validate category name length
		Utility.validateStringLength(categoryDto.getCategoryName(), "Category", Constants.CATEGORY_LENGTH);

		Category existingCategory = findCategoryById(categoryDto.getCategoryId());

		if (existingCategory == null) {
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Category").replace("&V",
					categoryDto.getCategoryId().toString()));
		}

		// Can't alter if it's pod is disabled
		if (existingCategory.getPod().isDisabled())
			throw new ServiceException(ErrorConstants.CANNOT_ALTER_POD_DISABLED.replace("&E", "Category"));

		// All sheet approval needed for all pods before config
		monitorSheetService.configEligibility(existingCategory.getPod().getPodId(), false);

		Category categoryWithExistingName = findByCategoryNameAndPodId(categoryDto.getCategoryName(),
				categoryDto.getPodId());

		if (categoryWithExistingName != null
				&& !categoryWithExistingName.getCategoryId().equals(categoryDto.getCategoryId())) {
			throw new ServiceException(ErrorConstants.NAME_ALREADY_EXISTS.replace("&E", "Category").replace("&V",
					categoryDto.getCategoryName()));
		}

		// Can't edit if used in sheet
		if (monitorSheetService.checkIfCategoryExists(existingCategory.getCategoryId()))
			throw new ServiceException(ErrorConstants.CANNOT_PERFORM_USED_IN_MONITOR_SHEET.replace("&E", "Category")
					.replace("&V", "edit"));

		// Incrementing the config version of the pod for detecting change
		// in monitor sheet in case operator trying to save old config
		// sheet.
		if (!StringUtils.equalsIgnoreCase(existingCategory.getCategoryName(), categoryDto.getCategoryName())) {
			monitorSheetService.storePodHistory(existingCategory.getPod(), PodAction.CATEGORYEDITED);
			existingCategory.getPod().setConfigurationVersion(existingCategory.getPod().getConfigurationVersion() + 1l);
		}

		existingCategory.setCategoryName(categoryDto.getCategoryName());
		existingCategory.setModifiedDate(DateTime.now());
		existingCategory = categoryRepository.save(existingCategory);
		logger.info("Successfully edited Category: " + categoryDto.getCategoryName() + " to "
				+ existingCategory.getCategoryName() + " for pod: " + existingCategory.getPod().getPodName());
		return new CategoryDTO(existingCategory.getCategoryId(), existingCategory.getCategoryName(),
				existingCategory.isDisabled(), existingCategory.getPod().getPodId());
	}

	public void deleteCategory(Long categoryId) throws ServiceException {
		logger.info("Deleting Category Id: " + categoryId);
		User loggedinUser = authenticationService.getAuthenticatedUser();

		if (!userSerice.isManager(loggedinUser)) {
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Categories").replace("&V", "delete"));
		}

		if (categoryId == null || categoryId < 0) {
			throw new ServiceException(ErrorConstants.ID_CANNOT_BE_EMPTY.replace("&E", "Category"));
		}

		Category existingCategory = findCategoryById(categoryId);
		if (existingCategory == null) {
			throw new ServiceException(
					ErrorConstants.ID_INVALID.replace("&E", "Category").replace("&V", categoryId.toString()));
		}

		// Can't alter if it's pod is disabled
		if (existingCategory.getPod().isDisabled())
			throw new ServiceException(ErrorConstants.CANNOT_ALTER_POD_DISABLED.replace("&E", "Category"));

		// All sheet approval needed for all pods before config
		monitorSheetService.configEligibility(existingCategory.getPod().getPodId(), false);

		Long count = subCategoryService.countByCategory(existingCategory);

		if (count > 0) {
			throw new ServiceException(ErrorConstants.CANNOT_DELETE_ASSOCIATED_WITH_ENTITIES.replace("&E", "Category")
					.replace("&&**", existingCategory.getCategoryName()).replace("$$**", count.toString())
					.replace("$$$$", "Subcategories").replace("&V", "deleted"));
		}

		// Incrementing the config version of the pod for detecting change
		// in monitor sheet in case operator trying to save old config
		// sheet.
		monitorSheetService.storePodHistory(existingCategory.getPod(), PodAction.CATEGORYDELETED);
		existingCategory.getPod().setConfigurationVersion(existingCategory.getPod().getConfigurationVersion() + 1l);

		categoryRepository.delete(existingCategory);
		logger.info("Successfully deleted Category: " + existingCategory.getCategoryName() + " for pod: "
				+ existingCategory.getPod().getPodName());
	}

	public void disableCategory(CategoryDTO categoryDTO) throws ServiceException {
		logger.info("Disabling CategoryId: " + categoryDTO.getCategoryId());
		User loggedinUser = authenticationService.getAuthenticatedUser();
		if (!userSerice.isManager(loggedinUser)) {
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Categories").replace("&V", "disable"));
		}

		if (Utility.isIdEmpty(categoryDTO.getCategoryId())) {
			throw new ServiceException(ErrorConstants.ID_CANNOT_BE_EMPTY.replace("&E", "Category"));
		}

		Category category = findCategoryById(categoryDTO.getCategoryId());

		if (category == null) {
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Category").replace("&V",
					categoryDTO.getCategoryId().toString()));
		}

		// Can't alter if it's pod is disabled
		if (category.getPod().isDisabled())
			throw new ServiceException(ErrorConstants.CANNOT_ALTER_POD_DISABLED.replace("&E", "Category"));

		// All sheet approval needed for all pods before config
		monitorSheetService.configEligibility(category.getPod().getPodId(), false);

		// Incrementing the config version of the pod for detecting change
		// in monitor sheet in case operator trying to save old config
		// sheet.
		monitorSheetService.storePodHistory(category.getPod(), PodAction.CATEGORYDISABLED);
		category.getPod().setConfigurationVersion(category.getPod().getConfigurationVersion() + 1l);

		category.setDisabled(categoryDTO.isDisabled());
		category.setModifiedDate(DateTime.now());
		categoryRepository.saveAndFlush(category);

		// Cascading the disable status to all sub categories belonging to the
		// given category .
		for (SubCategory subCategory : category.getSubCategoryList()) {
			// Whatever status is set in category whether enable or disble, will
			// reflect for sub category too.
			subCategory.setDisabled(categoryDTO.isDisabled());
			subCategory.setModifiedDate(DateTime.now());
			subCategoryService.saveSubCategory(subCategory);
		}
		logger.info("Successfully disabled Category: " + category.getCategoryName() + " for pod: "
				+ category.getPod().getPodName() + " and it's childs.");
	}

	public Long countByPodPodIdAndDisabled(Long podId, Boolean disabled) {
		return categoryRepository.countByPodPodIdAndDisabled(podId, disabled);
	}

	public Long countByPodPodId(Long podId) {
		return categoryRepository.countByPodPodId(podId);
	}

}
