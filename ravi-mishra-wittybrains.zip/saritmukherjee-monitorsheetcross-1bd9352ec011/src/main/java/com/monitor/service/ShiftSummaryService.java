package com.monitor.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.hibernate.dialect.lock.OptimisticEntityLockException;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itextpdf.text.DocumentException;
import com.monitor.ApplicationInitializer;
import com.monitor.DTO.ApprovalStateDTO;
import com.monitor.DTO.ReportCarrierDTO;
import com.monitor.DTO.ShiftSummaryDTO;
import com.monitor.domain.Shift;
import com.monitor.domain.ShiftSummary;
import com.monitor.domain.User;
import com.monitor.enums.ChannelStatusEnum;
import com.monitor.exception.ServiceException;
import com.monitor.repository.LocationRepository;
import com.monitor.repository.ShiftSummaryRepository;
import com.monitor.utils.DateUtil;
import com.monitor.utils.ErrorConstants;
import com.monitor.utils.StringUtils;

@Service
public class ShiftSummaryService {

	private AuthenticationService authenticationService;
	private ShiftSummaryRepository shiftSummaryRepository;
	private MonitorSheetService monitorSheetService;
	private ShiftService shiftService;
	private UserService userService;
	private EmailService emailService;
	private PodService podService;
	private LocationRepository locationRepository;
	private ReportService reportService;
	private static final Logger logger = LoggerFactory.getLogger(ApplicationInitializer.class);

	@Autowired
	public ShiftSummaryService(AuthenticationService authenticationService,
			ShiftSummaryRepository shiftSummaryRepository, ShiftService shiftService, UserService userService,
			@Lazy MonitorSheetService monitorSheetService, EmailService emailService, PodService podService,
			LocationRepository locationRepository, ReportService reportService) {
		this.authenticationService = authenticationService;
		this.shiftSummaryRepository = shiftSummaryRepository;
		this.shiftService = shiftService;
		this.userService = userService;
		this.monitorSheetService = monitorSheetService;
		this.emailService = emailService;
		this.podService = podService;
		this.locationRepository = locationRepository;
		this.reportService = reportService;
	}

	public void approve(ShiftSummaryDTO shiftSummaryDTO) throws ServiceException, DocumentException {
		logger.info("Approving summaryId: " + shiftSummaryDTO.getShiftSummaryId());
		User loggedInUser = authenticationService.getAuthenticatedUser();

		// Supervisor and manager only can approve a summary.
		if (userService.isOperator(loggedInUser)) {
			throw new ServiceException(ErrorConstants.OPERATOR_CANT_APPROVE_SUMMARY);
		}

		Shift shft = shiftService.findById(shiftSummaryDTO.getShiftId());
		DateTime shiftDate = shiftSummaryDTO.getShiftDate().withHourOfDay(shft.getStartTime().getHours() + 2);
		shiftDate = shiftDate.withMinuteOfHour(shft.getStartTime().getMinutes());

		if (!shiftService.isAfterCurrentShift(shiftDate)) {
			throw new ServiceException(ErrorConstants.SUMMARY_APPROVAL_AFTER_SHIFT_ENDS);
		}

		ShiftSummary shiftSummary = null;
		if (shiftSummaryDTO.getShiftSummaryId() == null) {
			shiftSummary = new ShiftSummary();
			shiftSummary.setCreatedDate(DateTime.now());
			shiftSummary.setMailSent(false);
			shiftSummary.setShiftDate(shiftSummaryDTO.getShiftDate());
			shiftSummary.setShift(shiftService.findById(shiftSummaryDTO.getShiftId()));
		} else {
			shiftSummary = findById(shiftSummaryDTO.getShiftSummaryId());
			if (shiftSummary.getApproved() && userService.isSupervisor(loggedInUser)) {
				throw new ServiceException(ErrorConstants.SUMMARY_ALREADY_APPROVED);
			}
		}

		shiftSummary.setSummary(shiftSummaryDTO.getSummary());
		shiftSummary.setApprovedDate(DateTime.now());
		shiftSummary.setModifiedDate(DateTime.now());
		shiftSummary.setApprovedBy(loggedInUser);
		shiftSummary.setApproved(true);
		try {
			save(shiftSummary);
		} catch (Exception ex) {
			throw new ServiceException(ErrorConstants.CANT_PERFORM_ACTION_TRY_LATER);
		}

		try {
			sendMail(shiftSummary.getShift(), shiftSummary.getShiftDate());
		} catch (OptimisticEntityLockException opexception) {
			throw new ServiceException(ErrorConstants.CANT_PERFORM_ACTION_TRY_LATER);
		} catch (ObjectOptimisticLockingFailureException opexception) {
			throw new ServiceException(ErrorConstants.CANT_PERFORM_ACTION_TRY_LATER);
		} catch (Exception ex) {
			throw new RuntimeException(ErrorConstants.SUMMARY_APPROVED_REPORT_EMAIL_SEND_FAILED);
		}
		logger.info("Successfully approved summaryId: " + shiftSummary.getShiftSummaryId() + ", and also email sent");
	}

	public ShiftSummaryDTO submit(ShiftSummaryDTO shiftSummaryDTO) throws ServiceException {
		logger.info("Submitting summaryId: " + shiftSummaryDTO.getShiftSummaryId());
		User user = authenticationService.getAuthenticatedUser();

		// Operator can't submit an approved summary.
		if (!userService.isManager(user) && findById(shiftSummaryDTO.getShiftSummaryId()).getApproved())
			throw new ServiceException(ErrorConstants.CANT_SUBMIT_APPROVED_SUMMARY);

		// Operator can't submit after shift ends.
		if (userService.isOperator(user) && !(shiftSummaryDTO.getShiftDate().withTimeAtStartOfDay()
				.isEqual(DateTime.now().withTimeAtStartOfDay())
				&& shiftService.getCurrentShift().getShiftId().longValue() == shiftSummaryDTO.getShiftId().longValue()))
			throw new ServiceException(ErrorConstants.CANT_SUBMIT_SHIFT_OVER);

		ShiftSummary shiftSummary;
		if (shiftSummaryDTO.getShiftSummaryId() != null) {
			shiftSummary = findById(shiftSummaryDTO.getShiftSummaryId());
			if (shiftSummary == null) {
				throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Shift summary").replace("&V",
						shiftSummaryDTO.getShiftSummaryId().toString()));
			}
		} else {

			Shift shift = shiftService.findById(shiftSummaryDTO.getShiftId());
			ShiftSummary summary = findByShiftAndShiftDate(shift, shiftSummaryDTO.getShiftDate());

			if (summary != null) {
				throw new ServiceException("Summary already exist for shift - " + shift.getName() + " and shift date "
						+ shiftSummaryDTO.getShiftDate());
			}

			shiftSummary = new ShiftSummary();
			shiftSummary.setCreatedDate(DateTime.now());
			shiftSummary.setApproved(false);
			shiftSummary.setMailSent(false);
			shiftSummary.setShiftDate(shiftSummaryDTO.getShiftDate());
			shiftSummary.setShift(shift);
		}

		shiftSummary.setModifiedDate(DateTime.now());
		shiftSummary.setSummary(shiftSummaryDTO.getSummary());

		return new ShiftSummaryDTO(save(shiftSummary), ChannelStatusEnum.PENDING.getStatus());
	}

	public LinkedHashMap<String, TreeMap<String, ShiftSummaryDTO>> getShiftSummary(String startDate, String endDate,
			Long[] shiftIdList) throws ServiceException {
		logger.info("Generating shift summary for StartDate: " + startDate + ", EndDate: " + endDate + ", Shifts: "
				+ StringUtils.toStringForList(shiftIdList));
		LinkedHashMap<String, TreeMap<String, ShiftSummaryDTO>> summaryMap = new LinkedHashMap<String, TreeMap<String, ShiftSummaryDTO>>();

		DateTime startDt = DateUtil.resetTime(DateUtil.getFormattedDateTime(startDate, "dd-MM-YYYY"));
		DateTime endDt = DateUtil.resetTime(DateUtil.getFormattedDateTime(endDate, "dd-MM-YYYY"));

		List<ShiftSummary> summaryList = findByShiftShiftIdInAndShiftDateBetweenOrderByShiftDate(startDt, endDt,
				shiftIdList);

		List<ShiftSummaryDTO> shiftSummaryDTOList = new ArrayList<ShiftSummaryDTO>();

		// putting already created summary into List
		for (ShiftSummary ss : summaryList) {
			if (shiftService.afterCurrentShift(shiftService.addShiftTime(ss.getShiftDate(), ss.getShift()))) {
				continue;
			}
			ShiftSummaryDTO ssd = new ShiftSummaryDTO(ss,
					monitorSheetService.getLogState(ss.getShift(), ss.getShiftDate()).getStatus());
			shiftSummaryDTOList.add(ssd);
		}

		// grouping by date
		Map<DateTime, List<ShiftSummaryDTO>> shiftSummaryDtoMap = shiftSummaryDTOList.stream()
				.collect(Collectors.groupingBy(ShiftSummaryDTO::getShiftDate));

		LinkedHashMap<DateTime, List<ShiftSummaryDTO>> sortedDate = shiftSummaryDtoMap.entrySet().stream()
				.sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
						(oldValue, newValue) -> oldValue, LinkedHashMap::new));

		List<Shift> shiftList = shiftService.findByShiftIdIn(shiftIdList);

		while (!startDt.isAfter(endDt)) {
			List<ShiftSummaryDTO> shiftSummaryList = sortedDate.get(startDt);
			TreeMap<String, ShiftSummaryDTO> shiftMap = new TreeMap<String, ShiftSummaryDTO>();

			if (shiftSummaryList != null) {
				for (ShiftSummaryDTO shft : shiftSummaryList) {
					addToMap(shiftService.findById(shft.getShiftId()), startDt, shiftMap, false);
				}
			}

			for (Shift shift : shiftList) {
				if (!shiftMap.containsKey(shift.getName())) {
					addToMap(shift, startDt, shiftMap, true);
				}
			}

			summaryMap.put(DateUtil.removeTime(startDt), shiftMap);
			startDt = startDt.plusDays(1);
		}
		logger.info("Successfully generated shift summary");
		return summaryMap;
	}

	private void addToMap(Shift shift, DateTime startDt, TreeMap<String, ShiftSummaryDTO> shiftMap,
			boolean createObject) throws ServiceException {
		if (shiftService.afterCurrentShift(shiftService.addShiftTime(startDt, shift))) {
			return;
		}

		if (createObject) {
			createShiftSummary(shift, startDt);
		}

		ShiftSummary shiftSummary = findByShiftAndShiftDate(shift, startDt);
		shiftMap.put(shift.getName(),
				new ShiftSummaryDTO(shiftSummary, monitorSheetService.getLogState(shift, startDt).getStatus()));
	}

	public ApprovalStateDTO getShiftSummaryState(Long shiftId, String createdDt) throws ServiceException {
		ApprovalStateDTO approvalStateDTO = new ApprovalStateDTO();
		Shift shift = shiftService.findById(shiftId);
		DateTime date = DateUtil.resetTime(DateUtil.getFormattedDateTime(createdDt, "dd-MM-YYYY"));

		ShiftSummary summary = findByShiftAndShiftDate(shift, date);
		if (summary != null && summary.getApproved()) {
			approvalStateDTO.setSummaryApproved(true);
		} else {
			approvalStateDTO.setSummaryApproved(false);
		}
		return approvalStateDTO;
	}

	public ChannelStatusEnum getLogState(Shift shift, DateTime shiftDate) {
		Long notApprovedCount = getUnapprovedCountByShiftAndCreatedDateAndApproved(shift.getShiftId(), shiftDate,
				false);
		Long count = checkIfEntriesExist(shift.getShiftId(), shiftDate);

		if (notApprovedCount == 0 && count > 0) {
			return ChannelStatusEnum.APPROVED;
		}

		if (notApprovedCount > 0) {
			return ChannelStatusEnum.PENDING;
		}

		return ChannelStatusEnum.NO_ENTRIES;
	}

	public void sendMail(Shift shift, DateTime shiftDate) throws ServiceException, DocumentException {
		ChannelStatusEnum logState = monitorSheetService.getLogState(shift, shiftDate);
		ChannelStatusEnum summaryState = getLogState(shift, shiftDate);
		if ((logState.equals(ChannelStatusEnum.APPROVED) || logState.equals(ChannelStatusEnum.NO_ENTRIES))
				&& summaryState.equals(ChannelStatusEnum.APPROVED)) {
			ShiftSummary summary = shiftSummaryRepository.findByShiftAndShiftDate(shift, shiftDate);

			if (!summary.getMailSent()) {
				emailService.sendSummaryReport(summary, getPdf(shiftDate, shift.getShiftId()));
				// emailService.sendSummaryReport(summary, new
				// ByteArrayOutputStream());
				summary.setMailSent(true);
				shiftSummaryRepository.save(summary);
			}
		}
	}

	public ReportCarrierDTO getPdf(DateTime shiftDate, Long shiftId) throws DocumentException {
		ByteArrayOutputStream baos = null;
		ReportCarrierDTO reportCarrierDTO = null;
		// Document document = new Document(PageSize.A4, 36, 36, 54, 36);
		// PdfWriter.getInstance(document, baos);
		// Map<String, Object> model = new HashMap<String, Object>();
		Long[] podIds = podService.getAllIds();
		// Long[] channelIds = channelService.getAllIds();
		//
		Long[] locationIds = locationRepository.getAllIds();
		//
		Long[] shiftArr = new Long[1];

		shiftArr[0] = shiftId;
		try {
			// baos =
			// reportService.generateReport(DateUtil.removeTime(shiftDate,
			// "dd-MM-yyyy"),
			// DateUtil.removeTime(shiftDate, "dd-MM-yyyy"), podIds, shiftArr,
			// locationIds, null, null, null, true);

			reportCarrierDTO = reportService.generateReport(DateUtil.removeTime(shiftDate, "dd-MM-yyyy"),
					DateUtil.removeTime(shiftDate, "dd-MM-yyyy"), shiftArr, podIds, locationIds, null, null, null,
					true);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			logger.info(ErrorConstants.NO_DATA_FOR_SELECTED_FILTERS);
		} catch (com.lowagie.text.DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return reportCarrierDTO;
	}

	public ShiftSummary save(ShiftSummary summary) throws ServiceException {
		try {
			return shiftSummaryRepository.save(summary);
		} catch (Exception ex) {
			throw new ServiceException(ErrorConstants.CANT_PERFORM_ACTION_TRY_LATER);
		}
	}

	public List<ShiftSummary> findByShiftShiftIdInAndShiftDateBetweenOrderByShiftDate(DateTime startDate,
			DateTime endDate, Long[] shift) {
		return shiftSummaryRepository.findByShiftShiftIdInAndShiftDateBetweenOrderByShiftDate(Arrays.asList(shift),
				startDate, endDate);
	}

	public ShiftSummary findByShiftAndShiftDate(Shift shift, DateTime createdDate) {
		return shiftSummaryRepository.findByShiftAndShiftDate(shift, createdDate);
	}

	public ShiftSummary findById(Long shiftSummaryId) {
		return shiftSummaryRepository.findByShiftSummaryId(shiftSummaryId);
	}

	public Long getUnapprovedCountByShiftAndCreatedDateAndApproved(Long shiftId, DateTime shiftDate, boolean approved) {
		return shiftSummaryRepository.getUnapprovedCountByShiftAndCreatedDateAndApproved(shiftId, shiftDate, approved);
	}

	public Long checkIfEntriesExist(Long shiftId, DateTime shiftDate) {
		return shiftSummaryRepository.checkIfEntriesExist(shiftId, shiftDate);
	}

	@Transactional
	private void createShiftSummary(Shift shift, DateTime startDt) throws ServiceException {
		logger.info("Creating summary for shift: " + shift.getName() + ", date: " + startDt);
		ShiftSummary shiftSummary = new ShiftSummary();

		shiftSummary.setApproved(false);
		shiftSummary.setApprovedBy(null);
		shiftSummary.setApprovedDate(null);
		shiftSummary.setCreatedDate(DateTime.now());
		shiftSummary.setMailSent(false);
		shiftSummary.setModifiedDate(DateTime.now());
		shiftSummary.setShift(shift);
		shiftSummary.setShiftDate(startDt);
		shiftSummary.setSummary("");

		try {
			shiftSummary = shiftSummaryRepository.save(shiftSummary);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		logger.info("Successfully created shift summaryId: " + shiftSummary.getShiftSummaryId());
	}

	public void resendMail(Long shiftSummaryId) throws ServiceException {
		logger.info("Resending email for summaryId: " + shiftSummaryId);
		if (!userService.isManager(authenticationService.getAuthenticatedUser()))
			throw new ServiceException(ErrorConstants.ONLY_MANAGER_CAN_RESEND);
		ShiftSummary shiftSummary = shiftSummaryRepository.findByShiftSummaryId(shiftSummaryId);
		if (shiftSummary == null)
			throw new ServiceException(
					ErrorConstants.ID_INVALID.replace("&E", "Shift Summary").replace("&V", shiftSummaryId.toString()));

		Shift shift = shiftSummary.getShift();
		DateTime shiftDate = shiftSummary.getShiftDate();
		ChannelStatusEnum logState = monitorSheetService.getLogState(shift, shiftDate);
		ChannelStatusEnum summaryState = getLogState(shift, shiftDate);
		if ((logState.equals(ChannelStatusEnum.APPROVED) || logState.equals(ChannelStatusEnum.NO_ENTRIES))
				&& summaryState.equals(ChannelStatusEnum.APPROVED)) {

			try {
				emailService.sendSummaryReport(shiftSummary, getPdf(shiftDate, shift.getShiftId()));
			} catch (Exception e) {
				throw new ServiceException(ErrorConstants.SUMMARY_REPORT_EMAIL_SEND_FAILED);
			}
		} else {
			throw new ServiceException(ErrorConstants.EITHER_MONITOR_SHEET_OR_SUMMARY_NOT_APPROVED);
		}
		logger.info("Successfully sent the email");

	}
}
