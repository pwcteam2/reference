package com.monitor.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.joda.time.DateTime;
import org.joda.time.LocalTime;
import org.joda.time.format.DateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.lowagie.text.DocumentException;
import com.monitor.ApplicationInitializer;
import com.monitor.DTO.CategorySheetDto;
import com.monitor.DTO.ChannelDTO;
import com.monitor.DTO.ChannelWiseTextFieldDto;
import com.monitor.DTO.HtmlReportDTO;
import com.monitor.DTO.LocationReturnDTO;
import com.monitor.DTO.MonitorSheetDTO;
import com.monitor.DTO.PodDTO;
import com.monitor.DTO.ReportCarrierDTO;
import com.monitor.DTO.SubCategorySheet;
import com.monitor.DTO.TimeBracketDTO;
import com.monitor.configuration.PropConfig;
import com.monitor.domain.Location;
import com.monitor.domain.MonitorSheet;
import com.monitor.domain.Pod;
import com.monitor.domain.PodHistory;
import com.monitor.domain.Shift;
import com.monitor.domain.User;
import com.monitor.enums.PodAction;
import com.monitor.enums.Status;
import com.monitor.excelhelper.CExcelTable;
import com.monitor.excelhelper.CExcelTableCell;
import com.monitor.exception.ServiceException;
import com.monitor.repository.LocationRepository;
import com.monitor.repository.PodHistoryRepository;
import com.monitor.utils.ErrorConstants;
import com.monitor.utils.StringUtils;

@Service
public class ReportService {

	private AuthenticationService authenticationService;
	private MonitorSheetService monitorSheetService;
	private UserService userService;
	private PropConfig propConfig;
	private PodService podService;
	private LocationRepository locationRepository;
	private ChannelService channelService;
	private ShiftService shiftService;
	private TemplateEngine templateEngine;
	private LocationService locationService;
	private PodHistoryRepository podHistoryRepository;
	private static final Logger logger = LoggerFactory.getLogger(ApplicationInitializer.class);

	@Autowired
	public ReportService(AuthenticationService authenticationService, MonitorSheetService monitorSheetService,
			UserService userService, PropConfig propConfig, PodService podService,
			LocationRepository locationRepository, ChannelService channelService, ShiftService shiftService,
			TemplateEngine templateEngine, LocationService locationService, PodHistoryRepository podHistoryRepository) {
		this.authenticationService = authenticationService;
		this.monitorSheetService = monitorSheetService;
		this.userService = userService;
		this.propConfig = propConfig;
		this.podService = podService;
		this.locationRepository = locationRepository;
		this.channelService = channelService;
		this.shiftService = shiftService;
		this.templateEngine = templateEngine;
		this.locationService = locationService;
		this.podHistoryRepository = podHistoryRepository;
	}

	/**
	 * Used only for creating pdf reports.Used also in shiftsummary report
	 * mailing. Boolean shiftSummary: True for mailing reports for shiftsummary.
	 * False for normal report generation.
	 * 
	 * @param startDate
	 * @param endDate
	 * @param shift
	 * @param pods
	 * @param locations
	 * @param timeBracketIds
	 * @param request
	 * @param response
	 * @param shiftSummary
	 * @return
	 * @throws ServiceException
	 * @throws DocumentException
	 * @throws IOException
	 * @throws com.itextpdf.text.DocumentException
	 */
	public ReportCarrierDTO generateReport(String startDate, String endDate, Long[] shift, Long[] pods,
			Long[] locations, Long[] timeBracketIds, HttpServletRequest request, HttpServletResponse response,
			Boolean shiftSummary)
			throws ServiceException, DocumentException, IOException, com.itextpdf.text.DocumentException {
		logger.info("Generating PDF Report for StartDate: " + startDate + ", EndDate: " + endDate + ", Pods: "
				+ StringUtils.toStringForList(pods) + ", Shifts: " + StringUtils.toStringForList(shift)
				+ ", Locations: " + StringUtils.toStringForList(locations) + ", TimeBrackets: "
				+ StringUtils.toStringForList(timeBracketIds));
		User user = authenticationService.getAuthenticatedUser();
		if (userService.isOperator(user))
			throw new ServiceException(ErrorConstants.OPERATOR_CANT_CREATE_REPORTS);

		// Getting all monitor sheet list.
		Map<Location, Map<MonitorSheetDTO, List<ChannelDTO>>> mainData = generateBaseReportDataMonitor(startDate,
				endDate, pods, shift, locations, timeBracketIds);
		// Getting error data
		Map<String, Map<String, List<String>>> errorData = htmlErrorReport(startDate, endDate, shift, pods, locations,
				timeBracketIds, request, response);

		String base64PdfReport = createPdf(mainData, true);

		String base64ErrorReport = "";
		if (errorData.size() != 0)
			base64ErrorReport = createPdf(errorData, false);

		ReportCarrierDTO reportCarrierDTO = new ReportCarrierDTO(base64PdfReport, base64ErrorReport);

		logger.info("Successfully got pdf reports.");
		return reportCarrierDTO;
	}

	/**
	 * Generate pdf by the template.
	 * pdfReport : True for monitor report. False for error report.
	 * @param <T>
	 * 
	 * @param map1
	 * @param pdfReport
	 * @return
	 * @throws IOException
	 * @throws DocumentException
	 */
	@SuppressWarnings("unchecked")
	public <T> String createPdf(T map1, boolean pdfReport) throws IOException, DocumentException {
		Context context = new Context();

		if (pdfReport)
			context.setVariable("msl", map1);
		else
			context.setVariable("esl", map1);
		context.setVariable("podList", getPodList());
		context.setVariable("shiftList", getShiftList());
		String html = null;
		if (pdfReport)
			html = templateEngine.process("report", context);
		else
			html = templateEngine.process("reportError", context);
		byte[] readAllBytes0 = Files
				.readAllBytes(new ClassPathResource("/icon/tick - Copy (2).png").getFile().toPath());
		byte[] readAllBytes1 = Files
				.readAllBytes(new ClassPathResource("/icon/cross - Copy (2).png").getFile().toPath());

		// Inserting tick and cross pics.
		html = html.replace("myimg0", Base64.getEncoder().encodeToString(readAllBytes0));
		html = html.replace("myimg1", Base64.getEncoder().encodeToString(readAllBytes1));

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		ITextRenderer renderer = new ITextRenderer();
		renderer.setDocumentFromString(html);
		renderer.layout();
		renderer.createPDF(byteArrayOutputStream);
		byteArrayOutputStream.close();
		return Base64.getEncoder().encodeToString(byteArrayOutputStream.toByteArray());
	}

	/**
	 * This is used in for pdf report generation.
	 * 
	 * @return
	 */
	private Map<Long, String> getPodList() {
		Map<Long, String> podList = new HashMap<>();
		List<Pod> all = podService.findAll();
		for (Pod pod : all) {
			podList.put(pod.getPodId(), pod.getPodName());
		}
		return podList;
	}

	/**
	 * This is used in for pdf report generation.
	 * 
	 * @return
	 */
	private Map<Long, String> getShiftList() {
		Map<Long, String> shiftList = new HashMap<>();
		List<Shift> all = shiftService.findAll();
		for (Shift shift : all) {
			shiftList.put(shift.getShiftId(), shift.getName());
		}
		return shiftList;
	}

	/**
	 * Used in pdf and xls generation to get the necessary data of monitor
	 * sheets creation.
	 * 
	 * @param startDate
	 * @param endDate
	 * @param pods
	 * @param shift
	 * @param locations
	 * @param timeBracketIds
	 * @return
	 * @throws ServiceException
	 */
	private Map<Location, Map<MonitorSheetDTO, List<ChannelDTO>>> generateBaseReportDataMonitor(String startDate,
			String endDate, Long[] pods, Long[] shift, Long[] locations, Long[] timeBracketIds)
			throws ServiceException {

		// Using this map to contain the location wise sheets
		Map<Location, Map<MonitorSheetDTO, List<ChannelDTO>>> map = new LinkedHashMap<>();

		int sheetCount = 0;

		// Getting all the locations
		Set<Location> locationList = locationRepository
				.findByLocationIdInOrderByCreatedDateAsc(Arrays.asList(locations));

		// StartDate time will be the starting time of that day
		DateTime stDate = DateTimeFormat.forPattern("dd-MM-yyyy").parseDateTime(startDate);
		// EndDate time will be the last second of that day.
		DateTime edDate = DateTimeFormat.forPattern("dd-MM-yyyy").parseDateTime(endDate).plusDays(1).minusSeconds(1);

		if (shiftService.isAfterShiftDate(edDate))
			throw new ServiceException(
					ErrorConstants.IS_AFTER_CURRENT_SHIFT_DATE.replace("&V", edDate.toString("dd-MM-yyyy")));

		// Ordering them by id as id sorting can also do creation date sorting.
		List<Long> podList = new ArrayList<>(getSetOfPods(pods)).stream().sorted().collect(Collectors.toList());

		for (Location location : locationList) {
			List<MonitorSheetDTO> monitorSheetDTOList = new ArrayList<>();
			// Incase multiple location selection
			if (locationList.size() > 1) {
				// Getting all pod with configuration measured on enddate.
				podList = reportPodList(startDate, endDate, location.getLocationId(), false).stream()
						.map(l -> l.getPodId()).collect(Collectors.toList());
			}

			// Pod iteration
			for (Long podId : podList) {
				// Date iteration(FromDate to ToDate)
				for (DateTime tempDate = stDate; tempDate.isBefore(edDate)
						|| tempDate.isEqual(edDate); tempDate = tempDate.plusDays(1)) {
					// ShiftWise iteration for selected shifts.
					for (Long shiftId : shift) {
						Long[] tId = { shiftId };
						String shiftWiseTimeBracketMessage = "";
						List<Long> shiftWiseEmptyBracketIds = new ArrayList<>();
						// Getting all timeBrackets for a particular shift.
						List<TimeBracketDTO> timeBracketAllList = monitorSheetService.getTimeBracketList(podId, tId,
								null);
						List<TimeBracketDTO> timeBracketList = new ArrayList<>();

						// Getting time brackets according to the filter given
						// or upto current day and current time bracket.
						timeBracketList = getReportTimeBracketList(podId, shiftId, timeBracketIds, tempDate);

						// Getting monitor Sheets for timeBrackets one by one.
						for (TimeBracketDTO timeBracketDTO : timeBracketList) {
							MonitorSheetDTO monitorSheetDTO = monitorSheetService
									.findByPodPodIdAndShiftShiftIdAndTimeBracketIdAndCreatedDateBetweenOrderByPodCreatedDateAscModifiedDateAscCreatedDateAsc(
											podId, shiftId, timeBracketDTO.getTimeBracketId(), tempDate);
							if (monitorSheetDTO != null) {
								// In case sheet submitted for the timeBracket.
								monitorSheetDTOList.add(monitorSheetDTO);
								sheetCount++;
							} else {

								// Last config sheet for this pod before the
								// timeBracket Start. This if-else is because of
								// cross date calculation.
								MonitorSheet tempSheet = new MonitorSheet();
								if (timeBracketDTO.getTimeBracketId().longValue() < monitorSheetService
										.getNextDayFirstTimeBracketId(podId)) {
									tempSheet = monitorSheetService
											.findTop1ByStatusAndPodPodIdAndCreatedDateLessThanOrderByCreatedDateDesc(
													Status.CONFIGURATION, podId,
													timeBracketDTO.getTimeBracketStartTime()
															.withDate(tempDate.toLocalDate()));
								} else {
									tempSheet = monitorSheetService
											.findTop1ByStatusAndPodPodIdAndCreatedDateLessThanOrderByCreatedDateDesc(
													Status.CONFIGURATION, podId,
													timeBracketDTO.getTimeBracketStartTime()
															.withDate(tempDate.plusDays(1).toLocalDate()));
								}
								LocalTime timeBracketStartTime = timeBracketDTO.getTimeBracketStartTime().toLocalTime();

								if (tempSheet != null) {
									PodHistory lastPodHistory = null;
									DateTime searchDate = null;

									// Calculating pod config history.
									if (timeBracketDTO.getTimeBracketId().longValue() < monitorSheetService
											.getNextDayFirstTimeBracketId(podId)) {
										searchDate = tempDate.withTime(timeBracketStartTime);
										lastPodHistory = podHistoryRepository
												.findTop1ByPodPodIdAndCreatedDateLessThanEqualOrderByCreatedDateDesc(
														podId, searchDate);
									} else {
										searchDate = tempDate.withTime(timeBracketStartTime).plusDays(1);
										lastPodHistory = podHistoryRepository
												.findTop1ByPodPodIdAndCreatedDateLessThanEqualOrderByCreatedDateDesc(
														podId, searchDate);
									}

									// Skipping time brackets if config is in
									// progress.
									if (lastPodHistory != null && lastPodHistory.getPodAction().getStatus()
											.equalsIgnoreCase(PodAction.SHEETCONFIGURED.getStatus())) {
										// Skipping if config between the time
										// bracket.
										if (podHistoryRepository.countByPodPodIdAndCreatedDateBetweenAndPodActionNot(
												podId, searchDate,
												searchDate.plusMinutes(timeBracketDTO.getTimeBracketInMinutes()),
												PodAction.SHEETCONFIGURED) == 0)
											// Should not show current time
											// bracket error message
											if (!(tempDate.withTimeAtStartOfDay()
													.equals(shiftService.getShiftDate(DateTime.now()))
													&& timeBracketDTO.getTimeBracketId()
															.longValue() == monitorSheetService
																	.getCurrentTimeBracket(podId).getTimeBracketId()
																	.longValue()))
												shiftWiseEmptyBracketIds.add(timeBracketDTO.getTimeBracketId());
									}
									// else skipping
								}
							}
						}

						// Counting blank timebrackets where no sheet submitted
						// or approved for a shift. This is the calculation for
						// putting time brackets in durations.
						if (shiftWiseEmptyBracketIds.size() != 0) {
							MonitorSheetDTO monitorSheetDTO = new MonitorSheetDTO();
							monitorSheetDTO.setPodId(podId);
							monitorSheetDTO.setShiftId(shiftId);
							monitorSheetDTO.setShiftDate(tempDate);
							// Getting compressed durations.
							List<String> durationList = getTimeBracketDuration(shiftWiseEmptyBracketIds,
									shiftWiseTimeBracketMessage, timeBracketList);
							shiftWiseTimeBracketMessage = "Operator has not submitted the monitor sheet or the monitor sheet is not approved for the following time duration(s) - ";
							monitorSheetDTO.setShiftWiseTimeBracketMessage(shiftWiseTimeBracketMessage);
							monitorSheetDTO.setShiftWiseTimeDurations(durationList);

							// Adding the time bracket info sheet for the whole
							// shift.
							monitorSheetDTOList.add(monitorSheetDTO);
						}
					}
				}
			}

			// Putting channel list for the sheets.
			if (monitorSheetDTOList.size() > 0) {
				Map<MonitorSheetDTO, List<ChannelDTO>> mapTemp = new LinkedHashMap<>();
				for (MonitorSheetDTO monitorSheetDTO : monitorSheetDTOList) {
					if (monitorSheetDTO.getMonitorId() != null) {
						// In case a valid monitor id, getting it's channels.
						mapTemp.put(monitorSheetDTO, monitorSheetService
								.monitorsheetchannellist(monitorSheetDTO.getMonitorId(), monitorSheetDTO.getPodId()));
					} else {
						mapTemp.put(monitorSheetDTO, null);
					}
				}

				map.put(location, mapTemp);
			}

		}

		// Exception in case 0 result found.
		if (sheetCount == 0)
			throw new ServiceException(ErrorConstants.NO_DATA_FOR_SELECTED_FILTERS);

		return map;
	}

	public void excelReport(String startDate, String endDate, Long[] shift, Long[] pods, Long[] locations,
			Long[] timeBracketIds, HttpServletRequest request, HttpServletResponse response)
			throws ServiceException, IOException {
		logger.info("Generating Excel Report for StartDate: " + startDate + ", EndDate: " + endDate + ", Pods: "
				+ StringUtils.toStringForList(pods) + ", Shifts: " + StringUtils.toStringForList(shift)
				+ ", Locations: " + StringUtils.toStringForList(locations) + ", TimeBrackets: "
				+ StringUtils.toStringForList(timeBracketIds));
		Map<Location, Map<MonitorSheetDTO, List<ChannelDTO>>> locationMap = generateBaseReportDataMonitor(startDate,
				endDate, pods, shift, locations, timeBracketIds);

		User user = authenticationService.getAuthenticatedUser();
		if (userService.isOperator(user))
			throw new ServiceException(ErrorConstants.OPERATOR_CANT_CREATE_REPORTS);

		XSSFWorkbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("Monitor Sheet");
		int currentSheetRowOffset = 0;
		CExcelTable table = null;

		// Location iteration
		for (Map.Entry<Location, Map<MonitorSheetDTO, List<ChannelDTO>>> locationMapEntry : locationMap.entrySet()) {
			// Sheet iteration
			for (Map.Entry<MonitorSheetDTO, List<ChannelDTO>> monitorSheetDTOEntry : locationMapEntry.getValue()
					.entrySet()) {

				// If statement used if there is a sheet for the time bracket.
				if (monitorSheetDTOEntry.getValue() != null && monitorSheetDTOEntry.getValue().size() != 0) {
					int columns = monitorSheetDTOEntry.getValue().size() + 1;
					int[] columnWidths = new int[columns];
					for (int i = 0; i < columns; i++)
						columnWidths[i] = 1;

					// Used min column for location,pod,shift,time,date, etx. To
					// retain the view in case very less number of channels.
					int minColumnsForHeader = columns > 10 ? columns : 10;

					if (table == null)
						table = new CExcelTable(workbook, sheet, monitorSheetDTOEntry.getValue().size() + 1,
								columnWidths);
					else
						table.reset(monitorSheetDTOEntry.getValue().size() + 1, columnWidths, currentSheetRowOffset);

					// Location
					table.AddCell(new CExcelTableCell("Location: " + locationMapEntry.getKey().getLocationName(),
							Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, minColumnsForHeader,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR));

					// Pod
					table.AddCell(
							new CExcelTableCell("Pod: " + getPodList().get(monitorSheetDTOEntry.getKey().getPodId()),
									Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, minColumnsForHeader / 5,
									XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR));

					// Date
					table.AddCell(new CExcelTableCell(
							"Date: " + monitorSheetDTOEntry.getKey().getShiftDate().toString("dd MMM yyyy"),
							Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, minColumnsForHeader / 5,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_NONE, true));
					int timeBracketCellWidth = minColumnsForHeader / 5;
					//
					// // In case channel number is not divisable by 5.
					// if (minColumnsForHeader % 5 != 0)
					timeBracketCellWidth = minColumnsForHeader - timeBracketCellWidth * 4;

					// Time Bracket
					table.AddCell(new CExcelTableCell(
							"Time Bracket: " + monitorSheetDTOEntry.getKey().getTimeBracketDTO().getTimeBracketValue(),
							Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, timeBracketCellWidth,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_NONE, true));

					// Time
					table.AddCell(new CExcelTableCell("Submitted Time: " + monitorSheetDTOEntry.getKey().getEndTime(),
							Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, minColumnsForHeader / 5,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_NONE, true));

					// Shift
					table.AddCell(new CExcelTableCell(
							"Shift: " + getShiftList().get(monitorSheetDTOEntry.getKey().getShiftId()),
							Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, minColumnsForHeader / 5,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR, true));

					// Channel
					table.AddCell(new CExcelTableCell("Channel", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR));

					for (ChannelDTO channelDTO : monitorSheetDTOEntry.getValue()) {
						table.AddCell(new CExcelTableCell(channelDTO.getChannelName(), Font.BOLDWEIGHT_BOLD,
								HSSFColor.WHITE.index, 1, XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
								XSSFCellStyle.BORDER_HAIR));
					}

					// Noc
					table.AddCell(new CExcelTableCell("Noc", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR));

					for (ChannelDTO channelDTO : monitorSheetDTOEntry.getValue()) {
						table.AddCell(new CExcelTableCell(channelDTO.getNocNumber(), Font.BOLDWEIGHT_BOLD,
								HSSFColor.WHITE.index, 1, XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
								XSSFCellStyle.BORDER_HAIR));
					}

					for (CategorySheetDto categorySheetDto : monitorSheetDTOEntry.getKey().getCategorySheetList()) {
						table.AddCell(new CExcelTableCell(categorySheetDto.getCategoryName(), Font.BOLDWEIGHT_BOLD,
								HSSFColor.WHITE.index, columns, XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
								XSSFCellStyle.BORDER_HAIR));

						for (SubCategorySheet subCategorySheet : categorySheetDto.getSubCategorySheetList()) {
							// SubCategory
							table.AddCell(new CExcelTableCell(subCategorySheet.getSubCategoryName(),
									Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 1, XSSFCellStyle.ALIGN_CENTER,
									XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR));
							for (ChannelWiseTextFieldDto channelWiseTextFieldDto : subCategorySheet
									.getChannelWiseTextFieldList()) {

								if (channelWiseTextFieldDto.getTextFieldValue() != null) {
									if (channelWiseTextFieldDto.getSelection() == null) {
										table.AddCell(new CExcelTableCell(channelWiseTextFieldDto.getTextFieldValue(),
												Font.BOLDWEIGHT_NORMAL, HSSFColor.WHITE.index, 1,
												XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
												XSSFCellStyle.BORDER_HAIR, IndexedColors.BLACK.index));
									} else {
										// Switching tick/cross color.
										if (channelWiseTextFieldDto.getSelection()) {
											table.AddCell(
													new CExcelTableCell(channelWiseTextFieldDto.getTextFieldValue(),
															Font.BOLDWEIGHT_NORMAL, HSSFColor.GREEN.index, 1,
															XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
															XSSFCellStyle.BORDER_HAIR, IndexedColors.BLACK.index));
										} else {
											table.AddCell(
													new CExcelTableCell(channelWiseTextFieldDto.getTextFieldValue(),
															Font.BOLDWEIGHT_NORMAL, HSSFColor.RED.index, 1,
															XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
															XSSFCellStyle.BORDER_HAIR, IndexedColors.BLACK.index));
										}
									}
								} else {
									table.AddCell(new CExcelTableCell(channelWiseTextFieldDto.getTextFieldValue(),
											Font.BOLDWEIGHT_NORMAL, HSSFColor.GREY_40_PERCENT.index, 1,
											XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
											XSSFCellStyle.BORDER_HAIR, IndexedColors.BLACK.index));
								}
							}
						}
					}

					table.AddCell(new CExcelTableCell("Operator: " + monitorSheetDTOEntry.getKey().getOperatorName(),
							Font.BOLDWEIGHT_NORMAL, minColumnsForHeader / 2, XSSFCellStyle.ALIGN_CENTER,
							XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR, IndexedColors.BLACK.index, false));

					String operatorRemarks = monitorSheetDTOEntry.getKey().getOperatorRemarks();
					if (operatorRemarks == null || operatorRemarks.isEmpty()) {
						operatorRemarks = "Operator Remarks: ";
					} else {
						operatorRemarks = "Operator Remarks: " + operatorRemarks;
					}

					table.AddCell(new CExcelTableCell(operatorRemarks, Font.BOLDWEIGHT_NORMAL,
							minColumnsForHeader % 2 == 0 ? minColumnsForHeader / 2 : minColumnsForHeader / 2 + 1,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR,
							IndexedColors.BLACK.index, true));

					table.AddCell(new CExcelTableCell("Approver: " + monitorSheetDTOEntry.getKey().getApproverName(),
							Font.BOLDWEIGHT_NORMAL, minColumnsForHeader / 2, XSSFCellStyle.ALIGN_CENTER,
							XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR, IndexedColors.BLACK.index, false));

					String approverRemarks = monitorSheetDTOEntry.getKey().getApproverRemarks();
					if (approverRemarks == null || approverRemarks.isEmpty()) {
						approverRemarks = "Approver Remarks: ";
					} else {
						approverRemarks = "Approver Remarks: " + approverRemarks;
					}

					table.AddCell(new CExcelTableCell(approverRemarks, Font.BOLDWEIGHT_NORMAL,
							minColumnsForHeader % 2 == 0 ? minColumnsForHeader / 2 : minColumnsForHeader / 2 + 1,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR,
							IndexedColors.BLACK.index, true));

					// Creating 3 rows for isolations sheets.
					table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_NORMAL, HSSFColor.WHITE.index,
							minColumnsForHeader, XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
							XSSFCellStyle.BORDER_HAIR, IndexedColors.BLACK.index));
					table.AddCell(new CExcelTableCell("-------------------------------------------------------------",
							Font.BOLDWEIGHT_NORMAL, HSSFColor.WHITE.index, minColumnsForHeader,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR,
							IndexedColors.BLACK.index));
					table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_NORMAL, HSSFColor.WHITE.index,
							minColumnsForHeader, XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
							XSSFCellStyle.BORDER_HAIR, IndexedColors.BLACK.index));

					currentSheetRowOffset = table.CreateTable();

				} else {

					// This code will execute if there is for shift wise details
					// for the all time brackets.
					int columns = 10;
					int[] columnWidths = new int[columns];
					for (int i = 0; i < columns; i++)
						columnWidths[i] = 1;

					// Used min column for location,pod,shift,time,date, etx. To
					// retain the view in case very less number of channels.
					int minColumnsForHeader = columns > 10 ? columns : 10;

					if (table == null)
						table = new CExcelTable(workbook, sheet, columns, columnWidths);
					else
						table.reset(columns, columnWidths, currentSheetRowOffset);

					// Location
					table.AddCell(new CExcelTableCell("Location: " + locationMapEntry.getKey().getLocationName(),
							Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, minColumnsForHeader,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR));

					// Pod
					table.AddCell(
							new CExcelTableCell("Pod: " + getPodList().get(monitorSheetDTOEntry.getKey().getPodId()),
									Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, minColumnsForHeader / 5,
									XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR));

					// Date
					table.AddCell(new CExcelTableCell(
							"Date: " + monitorSheetDTOEntry.getKey().getShiftDate().toString("dd MMM yyyy"),
							Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, minColumnsForHeader / 5,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_NONE, true));
					int timeBracketCellWidth = minColumnsForHeader / 5;

					// In case channel number is not divisable by 5.
					timeBracketCellWidth = minColumnsForHeader - timeBracketCellWidth * 4;

					// Shift
					table.AddCell(new CExcelTableCell(
							"Shift: " + getShiftList().get(monitorSheetDTOEntry.getKey().getShiftId()),
							Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, minColumnsForHeader / 5,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR, true));

					// Escaping 2 cells.
					table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index,
							(minColumnsForHeader / 5) * 2, XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
							XSSFCellStyle.BORDER_HAIR, true));

					// Printing the message.
					table.AddCell(new CExcelTableCell(monitorSheetDTOEntry.getKey().getShiftWiseTimeBracketMessage(),
							Font.BOLDWEIGHT_NORMAL, HSSFColor.WHITE.index, minColumnsForHeader,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR,
							IndexedColors.BLACK.index));

					// Printing all the durations.
					for (String duration : monitorSheetDTOEntry.getKey().getShiftWiseTimeDurations()) {
						table.AddCell(new CExcelTableCell(duration, Font.BOLDWEIGHT_NORMAL, HSSFColor.WHITE.index,
								minColumnsForHeader, XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
								XSSFCellStyle.BORDER_HAIR, IndexedColors.BLACK.index));
					}

					// Creating 3 rows for isolations sheets.
					table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_NORMAL, HSSFColor.WHITE.index,
							minColumnsForHeader, XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
							XSSFCellStyle.BORDER_HAIR, IndexedColors.BLACK.index));
					table.AddCell(new CExcelTableCell("-------------------------------------------------------------",
							Font.BOLDWEIGHT_NORMAL, HSSFColor.WHITE.index, minColumnsForHeader,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR,
							IndexedColors.BLACK.index));
					table.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_NORMAL, HSSFColor.WHITE.index,
							minColumnsForHeader, XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
							XSSFCellStyle.BORDER_HAIR, IndexedColors.BLACK.index));

					currentSheetRowOffset = table.CreateTable();
				}
			}
		}

		// This portion of the code will create a new sheet for error message.
		Map<String, Map<String, List<String>>> htmlErrorReport = htmlErrorReport(startDate, endDate, shift, pods,
				locations, timeBracketIds, request, response);

		if (htmlErrorReport.size() != 0) {
			Sheet errorSheet = workbook.createSheet("Error Sheet");
			// int currentSheetRowOffset = 0;
			CExcelTable errorTable = null;
			currentSheetRowOffset = 0;

			int columns = 16;
			int[] columnWidths = new int[columns];
			for (int i = 0; i < columns; i++)
				columnWidths[i] = 1;

			errorTable = new CExcelTable(workbook, errorSheet, columns, columnWidths);

			// Pod
			errorTable
					.AddCell(new CExcelTableCell("Pod", Font.BOLDWEIGHT_BOLD, (short) 30, 4, XSSFCellStyle.ALIGN_CENTER,
							XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR, (int) HSSFColor.WHITE.index));

			// Message
			errorTable.AddCell(new CExcelTableCell("Message", Font.BOLDWEIGHT_BOLD, (short) 30, columns - 4,
					XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR,
					(int) HSSFColor.WHITE.index));

			currentSheetRowOffset = errorTable.CreateTable();

			for (Map.Entry<String, Map<String, List<String>>> locationEntry : htmlErrorReport.entrySet()) {
				if (errorTable == null)
					errorTable = new CExcelTable(workbook, errorSheet, columns, columnWidths);
				else
					errorTable.reset(columns, columnWidths, currentSheetRowOffset);

				// Location
				errorTable.AddCell(new CExcelTableCell("" + locationEntry.getKey(), Font.BOLDWEIGHT_BOLD,
						HSSFColor.GREY_50_PERCENT.index, columns, XSSFCellStyle.ALIGN_CENTER,
						XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR, (int) HSSFColor.WHITE.index));
				for (Map.Entry<String, List<String>> podMap : locationEntry.getValue().entrySet()) {

					String podName = podMap.getKey();
					List<String> podMessages = podMap.getValue();

					// Pod
					errorTable.AddCell(new CExcelTableCell("" + podName, Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 4,
							XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR));

					for (String podMessage : podMessages) {
						if (podMessages != null && !podMessages.get(0).equalsIgnoreCase(podMessage))
							errorTable.AddCell(new CExcelTableCell("", Font.BOLDWEIGHT_BOLD, HSSFColor.WHITE.index, 4,
									XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP, XSSFCellStyle.BORDER_HAIR));
						// Message
						errorTable.AddCell(new CExcelTableCell("" + podMessage, Font.BOLDWEIGHT_BOLD,
								HSSFColor.WHITE.index, 12, XSSFCellStyle.ALIGN_CENTER, XSSFCellStyle.VERTICAL_TOP,
								XSSFCellStyle.BORDER_HAIR));
					}

					currentSheetRowOffset = errorTable.CreateTable();

				}
			}
		}

		// This code is writing the xls data(byteArrayOutputStream) in
		// httpresponse.
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		workbook.write(byteArrayOutputStream);
		byteArrayOutputStream.close();
		response.setContentType("application/pdf");
		response.setHeader("content-disposition", "attachment; filename=\"my-pdf-file.xlsx\"");
		response.setContentLength(byteArrayOutputStream.toByteArray().length);
		ServletOutputStream outputStream = response.getOutputStream();
		outputStream.write(byteArrayOutputStream.toByteArray());
		outputStream.close();
		logger.info("Successfully generated excel report.");
	}

	/**
	 * Only used to generate html report
	 * 
	 * @param startDate
	 * @param endDate
	 * @param shift
	 * @param pods
	 * @param locations
	 * @param timeBracketIds
	 * @param request
	 * @param response
	 * @return
	 * @throws ServiceException
	 */
	public List<HtmlReportDTO> htmlReport(String startDate, String endDate, Long[] shift, Long[] pods, Long[] locations,
			Long[] timeBracketIds, HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		List<HtmlReportDTO> htmlReportDTOList = new ArrayList<>();

		// Total monitor sheets.
		int count = 0;

		logger.info("Generating Html Report for StartDate: " + startDate + ", EndDate: " + endDate + ", Pods: "
				+ StringUtils.toStringForList(pods) + ", Shifts: " + StringUtils.toStringForList(shift)
				+ ", Locations: " + StringUtils.toStringForList(locations) + ", TimeBrackets: "
				+ StringUtils.toStringForList(timeBracketIds));
		User user = authenticationService.getAuthenticatedUser();
		if (userService.isOperator(user))
			throw new ServiceException(ErrorConstants.OPERATOR_CANT_CREATE_REPORTS);

		// Getting all the locations
		Set<Location> locationList = locationRepository
				.findByLocationIdInOrderByCreatedDateAsc(Arrays.asList(locations));

		// stDate will be the starting shift date. Time should be 00:00:00.
		DateTime stDate = DateTimeFormat.forPattern("dd-MM-yyyy").parseDateTime(startDate);
		// edDate will be the starting shift date.
		DateTime edDate = DateTimeFormat.forPattern("dd-MM-yyyy").parseDateTime(endDate).plusDays(1).minusSeconds(1);

		// Wouldn't accept date after the current shift date.
		if (shiftService.isAfterShiftDate(edDate))
			throw new ServiceException(
					ErrorConstants.IS_AFTER_CURRENT_SHIFT_DATE.replace("&V", edDate.toString("dd-MM-yyyy")));

		// Ordering them by id as id sorting can also do creation date sorting.
		List<Long> podList = new ArrayList<>(getSetOfPods(pods)).stream().sorted().collect(Collectors.toList());

		for (Location location : locationList) {
			// Incase multiple location selection
			if (locationList.size() > 1) {
				// Getting all pod with configuration measured on enddate.
				podList = reportPodList(startDate, endDate, location.getLocationId(), false).stream()
						.map(l -> l.getPodId()).collect(Collectors.toList());
			}

			// Pod iteration
			for (Long podId : podList) {

				// Date iteration(fromdate to toDate)
				for (DateTime tempDate = stDate; tempDate.isBefore(edDate)
						|| tempDate.isEqual(edDate); tempDate = tempDate.plusDays(1)) {

					// Selected shifts iteration.
					for (Long shiftId : shift) {
						String shiftWiseTimeBracketMessage = "";
						List<Long> shiftWiseEmptyBracketIds = new ArrayList<>();
						Long[] tId = { shiftId };
						List<TimeBracketDTO> timeBracketAllList = monitorSheetService.getTimeBracketList(podId, tId,
								null);
						List<TimeBracketDTO> timeBracketList = new ArrayList<>();

						timeBracketList = getReportTimeBracketList(podId, shiftId, timeBracketIds, tempDate);
						// Iterating timebrackets one by one. And adding their
						// sheets if present otherwise creating shiftwise
						// message.
						for (TimeBracketDTO timeBracketDTO : timeBracketList) {
							// Getting monitor sheet for the
							// pod,shift,timebracket and shiftdate.
							MonitorSheet monitorSheet = monitorSheetService.getReportMonitorSheet(podId, shiftId,
									timeBracketDTO.getTimeBracketId(), tempDate);
							if (monitorSheet != null) {
								HtmlReportDTO htmlReportDTO = new HtmlReportDTO();
								htmlReportDTO.setMonitorId(monitorSheet.getMonitorId());
								htmlReportDTO.setPodName(monitorSheet.getPod().getPodName());
								htmlReportDTO.setShiftName(monitorSheet.getShift().getName());
								htmlReportDTO.setShiftDate(monitorSheet.getShiftDate().toString("dd MMM yyyy"));
								htmlReportDTO.setLocationName(monitorSheet.getPod().getLocation().getLocationName());
								htmlReportDTO.setTimeBracketDTO(timeBracketDTO);
								DateTime value = monitorSheet.getCompleteDate() == null ? monitorSheet.getModifiedDate()
										: monitorSheet.getCompleteDate();
								htmlReportDTO.setEndTime(value.toString("hh:mm:ss a z"));
								htmlReportDTOList.add(htmlReportDTO);
								// Counting the monitor sheets added.
								count++;
							} else {
								// Last config sheet for this pod before the
								// timeBracket Start.
								MonitorSheet tempSheet = new MonitorSheet();
								// Incase time bracket in same day as shift
								// date.Else next day.
								if (timeBracketDTO.getTimeBracketId().longValue() < monitorSheetService
										.getNextDayFirstTimeBracketId(podId)) {
									tempSheet = monitorSheetService
											.findTop1ByStatusAndPodPodIdAndCreatedDateLessThanOrderByCreatedDateDesc(
													Status.CONFIGURATION, podId,
													timeBracketDTO.getTimeBracketStartTime()
															.withDate(tempDate.toLocalDate()));
								} else {
									tempSheet = monitorSheetService
											.findTop1ByStatusAndPodPodIdAndCreatedDateLessThanOrderByCreatedDateDesc(
													Status.CONFIGURATION, podId,
													timeBracketDTO.getTimeBracketStartTime()
															.withDate(tempDate.plusDays(1).toLocalDate()));
								}

								LocalTime timeBracketStartTime = timeBracketDTO.getTimeBracketStartTime().toLocalTime();

								// Incase there is atleast one configuration
								// sheet for this pod.
								if (tempSheet != null) {
									PodHistory lastPodHistory = null;
									DateTime searchDate = null;
									// Incase time bracket in same day as shift
									// date.Else next day.
									if (timeBracketDTO.getTimeBracketId().longValue() < monitorSheetService
											.getNextDayFirstTimeBracketId(podId)) {
										searchDate = tempDate.withTime(timeBracketStartTime);
										lastPodHistory = podHistoryRepository
												.findTop1ByPodPodIdAndCreatedDateLessThanEqualOrderByCreatedDateDesc(
														podId, searchDate);
									} else {
										searchDate = tempDate.withTime(timeBracketStartTime).plusDays(1);
										lastPodHistory = podHistoryRepository
												.findTop1ByPodPodIdAndCreatedDateLessThanEqualOrderByCreatedDateDesc(
														podId, searchDate);
									}
									if (lastPodHistory != null && lastPodHistory.getPodAction().getStatus()
											.equalsIgnoreCase(PodAction.SHEETCONFIGURED.getStatus())) {
										// Ensuring no modification of config
										// within a timebracket.
										if (podHistoryRepository.countByPodPodIdAndCreatedDateBetweenAndPodActionNot(
												podId, searchDate,
												searchDate.plusMinutes(timeBracketDTO.getTimeBracketInMinutes()),
												PodAction.SHEETCONFIGURED) == 0)
											// Should not show current time
											// bracket error message
											if (!(tempDate.withTimeAtStartOfDay()
													.equals(shiftService.getShiftDate(DateTime.now()))
													&& timeBracketDTO.getTimeBracketId()
															.longValue() == monitorSheetService
																	.getCurrentTimeBracket(podId).getTimeBracketId()
																	.longValue()))
												shiftWiseEmptyBracketIds.add(timeBracketDTO.getTimeBracketId());
									}
									// else
									// System.out.println("Skipping");Incase
									// config was in progress.
								}

							}
						}
						// Counting blank timebrackets where no sheet submitted
						// or approved for a shift.Also when manager was
						// updating the config. This is the calculation for
						// putting time brackets in durations.
						if (shiftWiseEmptyBracketIds.size() != 0) {
							HtmlReportDTO htmlReportDTO = new HtmlReportDTO();
							Pod pod = podService.findById(podId);
							htmlReportDTO.setPodName(pod.getPodName());
							htmlReportDTO.setShiftName(shiftService.findById(shiftId).getName());
							htmlReportDTO.setShiftDate(tempDate.withTimeAtStartOfDay().toString("dd MMM yyyy"));
							htmlReportDTO.setLocationName(pod.getLocation().getLocationName());
							
							// Getting compressed time durations.
							List<String> durationList = getTimeBracketDuration(shiftWiseEmptyBracketIds,
									shiftWiseTimeBracketMessage, timeBracketList);
							shiftWiseTimeBracketMessage = "Operator has not submitted the monitor sheet or the monitor sheet is not approved for the following time duration(s) - ";
							htmlReportDTO.setShiftWiseTimeBracketMessage(shiftWiseTimeBracketMessage);
							htmlReportDTO.setShiftWiseTimeDurations(durationList);

							// The htmlReportDTO object contains the data about
							// the whole shift(Blank time brackets). It is not a
							// monitor sheet.
							htmlReportDTOList.add(htmlReportDTO);
						}
					}
				}
			}

		}

		// Exception in case 0 result found.
		if (count == 0)
			throw new ServiceException(ErrorConstants.NO_DATA_FOR_SELECTED_FILTERS);

		logger.info("Successfully generated html report.");
		return htmlReportDTOList;
	}

	/**
	 * This method is the only producer of data for error html,pdf,excel sheet.
	 * Every message generated will be in the time duration given as startDate,
	 * endDate.
	 * 
	 * @param startDate
	 * @param endDate
	 * @param shift
	 * @param pods
	 * @param locations
	 * @param timeBracketIds
	 * @param request
	 * @param response
	 * @return
	 * @throws ServiceException
	 */
	public Map<String, Map<String, List<String>>> htmlErrorReport(String startDate, String endDate, Long[] shift,
			Long[] pods, Long[] locations, Long[] timeBracketIds, HttpServletRequest request,
			HttpServletResponse response) throws ServiceException {
		Map<String, Map<String, List<String>>> finalMap = new LinkedHashMap<>();

		logger.info("Generating Html Error Report for StartDate: " + startDate + ", EndDate: " + endDate + ", Pods: "
				+ StringUtils.toStringForList(pods) + ", Shifts: " + StringUtils.toStringForList(shift)
				+ ", Locations: " + StringUtils.toStringForList(locations) + ", TimeBrackets: "
				+ StringUtils.toStringForList(timeBracketIds));

		User user = authenticationService.getAuthenticatedUser();
		if (userService.isOperator(user))
			throw new ServiceException(ErrorConstants.OPERATOR_CANT_CREATE_REPORTS);

		// Getting all the locations
		Set<Location> locationList = locationRepository
				.findByLocationIdInOrderByCreatedDateAsc(Arrays.asList(locations));

		// StartDate time will be the starting time of that shift day
		DateTime stDate = DateTimeFormat.forPattern("dd-MM-yyyy").parseDateTime(startDate)
				.withTime(new LocalTime(shiftService.findById(1).getStartTime()));
		// EndDate time will be the last second of that shift date.
		DateTime edDate = DateTimeFormat.forPattern("dd-MM-yyyy").parseDateTime(endDate).plusDays(1)
				.withTime(new LocalTime(shiftService.findById(2).getEndTime()));

		// Ordering them by id as id sorting can also do creation date sorting.
		List<Long> podList = new ArrayList<>(getSetOfPods(pods)).stream().sorted().collect(Collectors.toList());

		for (Location location : locationList) {
			// Incase multiple location selection
			if (locationList.size() > 1) {
				// Getting all pod with configuration measured on enddate.
				podList = reportPodList(startDate, endDate, location.getLocationId(), false).stream()
						.map(l -> l.getPodId()).collect(Collectors.toList());
			}
			Map<String, List<String>> podMap = new LinkedHashMap<>();

			// Pod iteration
			for (Long podId : podList) {
				String sheetCreationError = "";
				List<String> mainMsg = new ArrayList<>();
				Pod pod = podService.findById(podId);
				if (pod == null)
					throw new ServiceException(
							ErrorConstants.ID_INVALID.replace("&E", "Pod").replace("&V", podId.toString()));
				// Getting the first configuration sheet of the pod.
				MonitorSheet tempSheet = monitorSheetService
						.findTop1ByStatusAndPodPodIdOrderByCreatedDateAsc(Status.CONFIGURATION, podId);

				if (tempSheet != null) {

					// Message when there was no configuration sheet in the pod.
					if (stDate.isBefore(tempSheet.getCreatedDate())) {
						sheetCreationError = "The configuration was in progress from "
								+ pod.getCreatedDate().toString("dd MMM yyyy, hh:mm:ss a z") + " to "
								+ tempSheet.getCreatedDate().toString("dd MMM yyyy, hh:mm:ss a z");
					}

					DateTime tempDate = tempSheet.getCreatedDate().plusSeconds(1);
					if (tempSheet.getCreatedDate().isBefore(stDate))
						tempDate = stDate;
					// Getting the configuration updation messages after first
					// sheet creation.
					mainMsg = getConfigurationUpdationMessage(pod, shift, tempDate, edDate);
				} else {
					// If there is no config still edDate.
					if (pod.getCreatedDate().isBefore(edDate))
						sheetCreationError = "No sheet configured for this pod";
				}

				// This list will contain message for no config as will upation
				// history.
				List<String> temp = new ArrayList<>();
				// Adding first configuration sheet message in the temp list if
				// its non empty.
				if (sheetCreationError != null && !sheetCreationError.isEmpty()) {
					temp.add(sheetCreationError);
				}

				// Adding configuration updation history in the temp list one by
				// one if exist.
				if (mainMsg.size() > 0)
					mainMsg.stream().forEach(x -> temp.add(x));

				// If there is any message to be shown like No config, Config
				// updation history then adding them to their pod.
				if (temp.size() > 0)
					podMap.put(podService.findById(podId).getPodName(), temp);
			}

			// Adding all pods data to its pod if exist.
			if (podMap.size() != 0)
				finalMap.put(location.getLocationName(), podMap);
		}

		logger.info("Successfully generated html error report.");
		return finalMap;
	}

	/**
	 * Eliminating locations having all pods with no configuration in it.
	 * 
	 * @param startDate
	 * @param endDate
	 * @param
	 * @return
	 * @throws ServiceException
	 */
	public List<LocationReturnDTO> reportLocationList(String startDate, String endDate, boolean alphabeticalOrder)
			throws ServiceException {
		// StartDate time will be the starting time of that day
		DateTime stDate = DateTimeFormat.forPattern("dd-MM-yyyy").parseDateTime(startDate);
		// EndDate time will be the last second of that day.
		DateTime edDate = DateTimeFormat.forPattern("dd-MM-yyyy").parseDateTime(endDate).plusDays(1).minusSeconds(1);

		if (shiftService.isAfterShiftDate(edDate))
			throw new ServiceException(
					ErrorConstants.IS_AFTER_CURRENT_SHIFT_DATE.replace("&V", edDate.toString("dd-MM-yyyy")));

		Set<Location> locationSet = locationRepository.findAllByOrderByCreatedDateAsc();
		List<LocationReturnDTO> locationReturnDTOs = new ArrayList<>();
		for (Location location : locationSet) {
			Boolean flag = false;
			for (Pod pod : location.getPodList()) {
				MonitorSheet configSheet = monitorSheetService
						.findTop1ByStatusAndPodPodIdAndCreatedDateLessThanEqualOrderByCreatedDateAsc(
								Status.CONFIGURATION, pod.getPodId(), edDate);
				if (configSheet != null) {
					flag = true;
					break;
				}
			}

			if (flag)
				locationReturnDTOs.add(locationService.getLocationReturnDto(location));
		}

		// Alphabetically sorting.
		if (alphabeticalOrder)
			locationReturnDTOs = locationReturnDTOs.stream()
					.sorted((o1, o2) -> o1.getLocationName().compareToIgnoreCase(o2.getLocationName()))
					.collect(Collectors.toList());
		return locationReturnDTOs;
	}

	/**
	 * It will get the pod list for the specified location with having
	 * configuration in the duration given. If alphabeticalOrder is true, the
	 * list will be alphabetically sorted. Also used for getting pods for report
	 * generation.
	 * 
	 * @param startDate
	 * @param endDate
	 * @param locationId
	 * @param alphabeticalOrder
	 * @return
	 * @throws ServiceException
	 */
	public List<PodDTO> reportPodList(String startDate, String endDate, Long locationId, boolean alphabeticalOrder)
			throws ServiceException {
		// StartDate time will be the starting time of that day
		DateTime stDate = DateTimeFormat.forPattern("dd-MM-yyyy").parseDateTime(startDate);
		// EndDate time will be the last second of that day.
		DateTime edDate = DateTimeFormat.forPattern("dd-MM-yyyy").parseDateTime(endDate).plusDays(1).minusSeconds(1);

		if (shiftService.isAfterShiftDate(edDate))
			throw new ServiceException(
					ErrorConstants.IS_AFTER_CURRENT_SHIFT_DATE.replace("&V", edDate.toString("dd-MM-yyyy")));

		if (locationRepository.findByLocationId(locationId) == null)
			throw new ServiceException(
					ErrorConstants.ID_INVALID.replace("&E", "Location").replace("&V", locationId.toString()));

		Set<Pod> podSet = podService.findAllByLocationLocationIdInOrderByCreatedDateAsc(locationId);
		List<PodDTO> podDTOs = new ArrayList<>();
		for (Pod pod : podSet) {
			MonitorSheet configSheet = monitorSheetService
					.findTop1ByStatusAndPodPodIdAndCreatedDateLessThanEqualOrderByCreatedDateAsc(Status.CONFIGURATION,
							pod.getPodId(), edDate);
			if (configSheet != null)
				podDTOs.add(podService.getPodDto(pod));
		}

		// Sorting alphabetically.
		if (alphabeticalOrder)
			podDTOs = podDTOs.stream().sorted((o1, o2) -> o1.getPodName().compareToIgnoreCase(o2.getPodName()))
					.collect(Collectors.toList());
		return podDTOs;
	}

	/**
	 * Configuration updation message(s) for pods.
	 * 
	 * @param pods
	 * @return
	 */
	public List<String> getConfigurationUpdationMessage(Pod pod, Long[] shift, DateTime startDate, DateTime endDate) {
		List<PodHistory> podHistories = null;
		List<String> mainMsg = new ArrayList<>();
		// Getting pod configuration history for specified filter.
		podHistories = podHistoryRepository.findByPodPodIdAndCreatedDateBetweenOrderByCreatedDateAsc(pod.getPodId(),
				startDate, endDate);

		Boolean configChanged = false;
		List<String> list = new ArrayList<>();
		String msg = "";
		for (PodHistory podHistory : podHistories) {

			// Config changed.
			if (configChanged == false && (!podHistory.getPodAction().getStatus()
					.equalsIgnoreCase(PodAction.SHEETCONFIGURED.getStatus()))) {
				configChanged = true;
				msg = podHistory.getCreatedDate().toString("dd MMM yyyy, hh:mm:ss a z");
			}
			if (!configChanged)
				continue;
			// Config done again.
			if (podHistory.getPodAction().getStatus().equalsIgnoreCase(PodAction.SHEETCONFIGURED.getStatus())) {
				configChanged = false;
				msg = msg + "/" + podHistory.getCreatedDate().toString("dd MMM yyyy, hh:mm:ss a z");
				list.add(msg);
				msg = "";
			}
		}
		// Incase config changed but sheet not created.
		if (msg != null && !msg.isEmpty())
			list.add(msg);
		// Converting to readable message.
		for (String st : list) {
			// Getting from date and to date by spliting the string.
			List<String> l = Arrays.asList(st.split("/"));

			// Incase both fromDate and toDate present.
			if (l.size() == 2)
				mainMsg.add("The configuration was in progress from " + l.get(0) + " to " + l.get(1));
			else {
				// Incase only config chnaged but sheet not created.
				// Enddatetime of the report.
				DateTime shiftEndDateTime = null;
				// For single shift selection.
				if (Arrays.asList(shift).size() == 1) {
					shiftEndDateTime = DateTime.now()
							.withTime(new LocalTime(shiftService.findById(shift[0]).getEndTime()));
				} else {
					// For all shifts.
					shiftEndDateTime = endDate;
				}
				// If report enddatetime already over.
				if (shiftEndDateTime.isBeforeNow())
					mainMsg.add("The configuration was in progress from " + l.get(0) + " to "
							+ shiftEndDateTime.toString("dd MMM yyyy, hh:mm:ss a z"));
				else {
					mainMsg.add("The configuration was in progress from " + l.get(0));
				}
			}
		}
		return mainMsg;
	}

	/**
	 * Getting timeBrackets according to the filter given. But incase current
	 * date time bracket list will according to the current time.
	 * 
	 * @param podId
	 * @param shiftId
	 * @param timeBracketIds
	 * @param tempDate
	 * @return
	 * @throws ServiceException
	 */
	public List<TimeBracketDTO> getReportTimeBracketList(Long podId, Long shiftId, Long[] timeBracketIds,
			DateTime tempDate) throws ServiceException {
		Long[] tId = { shiftId };
		List<TimeBracketDTO> timeBracketAllList = monitorSheetService.getTimeBracketList(podId, tId, null);
		List<TimeBracketDTO> timeBracketList = new ArrayList<>();

		// Getting timebrackets according to the selection in
		// the frontend.
		if (timeBracketIds != null && timeBracketIds.length != 0) {
			timeBracketList = monitorSheetService.getTimeBracketList(timeBracketIds, timeBracketAllList);
		} else {
			timeBracketList = timeBracketAllList;
		}

		// Time bracket till the current timebracket. Rest will
		// be eliminated.
		if (tempDate.withTimeAtStartOfDay().equals(shiftService.getShiftDate(DateTime.now()))) {
			Long timeBracketId = monitorSheetService.getCurrentTimeBracket(podId).getTimeBracketId();
			List<TimeBracketDTO> tempTimeBracketList = new ArrayList<>();
			for (TimeBracketDTO timeBracketDTO : timeBracketList) {
				if (timeBracketDTO.getTimeBracketId().longValue() <= timeBracketId.longValue()) {
					tempTimeBracketList.add(timeBracketDTO);
				}
			}
			timeBracketList = tempTimeBracketList;
		}
		return timeBracketList;
	}

	/**
	 * Removing duplicate entries of pods.
	 * 
	 * @param pods
	 * @return
	 */
	public static Set<Long> getSetOfPods(Long[] pods) {
		return new LinkedHashSet<>(Arrays.asList(pods));
	}

	/**
	 * Will be used to get durations for a shift where there is no sheet
	 * approved or created.
	 * 
	 * @param pods
	 * @param podId
	 * @param shiftId
	 * @param tempDate
	 * @param shiftWiseEmptyBracketIds
	 * @param shiftWiseTimeBracketMessage
	 * @param timeBracketList
	 * @return
	 */
	public List<String> getTimeBracketDuration(List<Long> shiftWiseEmptyBracketIds, String shiftWiseTimeBracketMessage,
			List<TimeBracketDTO> timeBracketList) {

		Long stId = 1l;
		Long tempId = 0l;
		for (Long ids : shiftWiseEmptyBracketIds) {
			if (shiftWiseEmptyBracketIds.get(0).longValue() == ids.longValue()) {
				stId = ids;
				tempId = ids - 1;
				shiftWiseTimeBracketMessage = monitorSheetService.getTimeBracketList(stId, timeBracketList)
						.getTimeBracketStartTime().toString("hh:mm a z");
				if (shiftWiseEmptyBracketIds.get(shiftWiseEmptyBracketIds.size() - 1).longValue() != ids.longValue()) {
					shiftWiseTimeBracketMessage = shiftWiseTimeBracketMessage + " to ";
				}
				if (shiftWiseEmptyBracketIds.get(shiftWiseEmptyBracketIds.size() - 1).longValue() == ids.longValue()) {
					TimeBracketDTO temp = monitorSheetService.getTimeBracketList(stId, timeBracketList);
					shiftWiseTimeBracketMessage = shiftWiseTimeBracketMessage + " to " + temp.getTimeBracketStartTime()
							.plusMinutes(temp.getTimeBracketInMinutes()).toString("hh:mm a z");
				}
				tempId++;
				continue;
			}
			if ((tempId.longValue() + 1) != ids.longValue()) {
				TimeBracketDTO tempTimeBracket = monitorSheetService.getTimeBracketList(tempId, timeBracketList);
				shiftWiseTimeBracketMessage = shiftWiseTimeBracketMessage
						+ tempTimeBracket.getTimeBracketStartTime()
								.plusMinutes(tempTimeBracket.getTimeBracketInMinutes()).toString("hh:mm a z")
						+ ", " + monitorSheetService.getTimeBracketList(ids, timeBracketList).getTimeBracketStartTime()
								.toString("hh:mm a z");
				if (shiftWiseEmptyBracketIds.get(shiftWiseEmptyBracketIds.size() - 1).longValue() != ids.longValue()) {
					shiftWiseTimeBracketMessage = shiftWiseTimeBracketMessage + " to ";
				}
				if (shiftWiseEmptyBracketIds.get(shiftWiseEmptyBracketIds.size() - 1).longValue() == ids.longValue()) {
					TimeBracketDTO temp = monitorSheetService.getTimeBracketList(ids, timeBracketList);
					shiftWiseTimeBracketMessage = shiftWiseTimeBracketMessage + " to " + temp.getTimeBracketStartTime()
							.plusMinutes(temp.getTimeBracketInMinutes()).toString("hh:mm a z");
				}
				tempId = ids;
				continue;
			}
			if (shiftWiseEmptyBracketIds.get(shiftWiseEmptyBracketIds.size() - 1).longValue() == ids.longValue()) {
				TimeBracketDTO temp = monitorSheetService.getTimeBracketList(ids, timeBracketList);
				shiftWiseTimeBracketMessage = shiftWiseTimeBracketMessage + temp.getTimeBracketStartTime()
						.plusMinutes(temp.getTimeBracketInMinutes()).toString("hh:mm a z");
				tempId++;
				continue;
			}
			tempId++;
		}

		return Arrays.asList(shiftWiseTimeBracketMessage.split(","));
	}
}
