package com.monitor.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.monitor.DTO.LocationDTO;
import com.monitor.DTO.LocationReturnDTO;
import com.monitor.domain.Category;
import com.monitor.domain.Channel;
import com.monitor.domain.Location;
import com.monitor.domain.Pod;
import com.monitor.domain.SubCategory;
import com.monitor.domain.User;
import com.monitor.exception.ServiceException;
import com.monitor.repository.CategoryRepository;
import com.monitor.repository.LocationRepository;
import com.monitor.repository.PodRepository;
import com.monitor.repository.SubCategoryRepository;
import com.monitor.servicefinder.utils.Constants;
import com.monitor.utils.ErrorConstants;
import com.monitor.utils.Utility;

@Service
public class LocationService {

	private LocationRepository locationRepository;
	private AuthenticationService authenticationService;
	private UserService userService;
	private PodRepository podRepository;
	private ChannelService channelService;
	private CategoryRepository categoryRepository;
	private SubCategoryRepository subCategoryRepository;
	private MonitorSheetService monitorSheetService;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	public LocationService(LocationRepository locationRepository, AuthenticationService authenticationService,
			UserService userService, PodRepository podRepository, ChannelService channelService,
			CategoryRepository categoryRepository, SubCategoryRepository subCategoryRepository,
			MonitorSheetService monitorSheetService) {
		this.locationRepository = locationRepository;
		this.authenticationService = authenticationService;
		this.userService = userService;
		this.podRepository = podRepository;
		this.channelService = channelService;
		this.categoryRepository = categoryRepository;
		this.subCategoryRepository = subCategoryRepository;
		this.monitorSheetService = monitorSheetService;

	}

	public LocationDTO addLocation(LocationDTO locationDTO) throws ServiceException {
		logger.info("Adding Location: " + locationDTO.getLocationName());
		User loggedInUser = authenticationService.getAuthenticatedUser();
		if (userService.isManager(loggedInUser)) {
			logger.debug("locationDto addedBy " + loggedInUser.getFullName());

			if (Utility.isStringEmpty(locationDTO.getLocationName())) {
				throw new ServiceException(ErrorConstants.NAME_CANNOT_BE_EMPTY.replace("&E", "Location"));
			}

			// Will validate location name length
			Utility.validateStringLength(locationDTO.getLocationName(), "Location", Constants.LOCATION_LENGTH);

			Location location = locationRepository.findByLocationName(locationDTO.getLocationName());
			if (location != null) {
				throw new ServiceException(ErrorConstants.NAME_ALREADY_EXISTS.replace("&E", "Location").replace("&V",
						location.getLocationName()));
			}

			Location newLocation = new Location();
			newLocation.setLocationName(locationDTO.getLocationName());
			newLocation.setCreatedDate(DateTime.now());
			newLocation.setModifiedDate(DateTime.now());
			newLocation.setAddedBy(loggedInUser);
			logger.info("Successfully added location: " + newLocation.getLocationName());
			return getLocationDto(locationRepository.save(newLocation));

		} else {
			logger.error("Location can only added by a manager");
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Locations").replace("&V", "add"));
		}
	}

	public Location findByLocationName(String location) {
		return locationRepository.findByLocationName(location);
	}

	public Location save(Location location) {
		return locationRepository.save(location);
	}

	public LocationDTO getLocationDto(Location location) {
		LocationDTO locationDto = new LocationDTO();
		locationDto.setCreatedDate(location.getCreatedDate());
		locationDto.setDeletedDate(location.getDeletedDate());
		locationDto.setModifiedDate(location.getModifiedDate());
		locationDto.setLocationId(location.getLocationId());
		locationDto.setLocationName(location.getLocationName());
		return locationDto;
	}

	public void editLocation(LocationDTO locationDTO) throws ServiceException {
		logger.info("Editing locationId: " + locationDTO.getLocationId());
		User loggedInUser = authenticationService.getAuthenticatedUser();

		if (userService.isManager(loggedInUser)) {
			logger.debug("locationDto EditedBy " + loggedInUser.getFullName());

			if (Utility.isStringEmpty(locationDTO.getLocationName())) {
				throw new ServiceException(ErrorConstants.NAME_CANNOT_BE_EMPTY.replace("&E", "Location"));
			}

			// Will validate location name length
			Utility.validateStringLength(locationDTO.getLocationName(), "Location", Constants.LOCATION_LENGTH);

			Location location = locationRepository.findByLocationName(locationDTO.getLocationName());
			if (location != null && !location.getLocationId().equals(locationDTO.getLocationId())) {
				throw new ServiceException(ErrorConstants.NAME_ALREADY_EXISTS.replace("&E", "Location").replace("&V",
						location.getLocationName()));
			}

			Location newLocation = locationRepository.findByLocationId(locationDTO.getLocationId());

			// Validate
			if (newLocation == null)
				throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Location").replace("&V",
						locationDTO.getLocationId().toString()));

			// All sheet approval needed for all pods before config
			for (Pod pod : newLocation.getPodList()) {
				monitorSheetService.configEligibility(pod.getPodId(), true);
				// Can't edit as it is used in monitor sheets.
				if (monitorSheetService.checkIfPodExists(pod.getPodId()))
					throw new ServiceException(ErrorConstants.CANNOT_PERFORM_USED_IN_MONITOR_SHEET
							.replace("&E", "Location").replace("&V", "edit"));
			}

			newLocation.setLocationName(locationDTO.getLocationName());
			newLocation.setModifiedDate(DateTime.now());

			locationRepository.save(newLocation);
			logger.info("Successfully edited location: " + locationDTO.getLocationName() + " to "
					+ newLocation.getLocationName());

		} else {
			logger.error("Location can be Edited by Manager");
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Locations").replace("&V", "edit"));
		}

	}

	/**
	 * If alphabeticalOrder is true then ordering will be alphabetically.
	 * 
	 * @param alphabeticalOrder
	 * @return
	 */
	public List<LocationReturnDTO> findAllByOrderByCreatedDateAsc(Boolean alphabeticalOrder) {
		logger.info("Getting all locations");
		Set<Location> locationSet = locationRepository.findAllByOrderByCreatedDateAsc();
		logger.info("Successfully got all locations");
		List<LocationReturnDTO> locationReturnDTOList = getLocationReturnDTOList(new ArrayList<>(locationSet));
		
		// Conditional sorting if required. Used in dropdown.
		if (alphabeticalOrder != null && alphabeticalOrder) {
			locationReturnDTOList = locationReturnDTOList.stream()
					.sorted((o1, o2) -> o1.getLocationName().compareToIgnoreCase(o2.getLocationName()))
					.collect(Collectors.toList());
		}
		return locationReturnDTOList;
	}

	public List<LocationReturnDTO> getLocationReturnDTOList(List<Location> locationSet) {
		List<LocationReturnDTO> locationReturnDTOList = new ArrayList<>();

		for (Location location : locationSet) {
			locationReturnDTOList.add(getLocationReturnDto(location));
		}

		return locationReturnDTOList;
	}

	public LocationReturnDTO getLocationReturnDto(Location location) {
		LocationReturnDTO dto = new LocationReturnDTO();
		dto.setLocationId(location.getLocationId());
		dto.setLocationName(location.getLocationName());
		dto.setDisabled(location.isDisabled());
		return dto;
	}

	public void deleteLocation(Long locationId) throws ServiceException {
		logger.info("Deleting locationId: " + locationId);
		User loggedInUser = authenticationService.getAuthenticatedUser();

		if (userService.isManager(loggedInUser)) {
			if (locationId == null || locationId == 0) {
				logger.error("location cannot be empty");
				throw new ServiceException(ErrorConstants.CANNOT_BE_EMPTY.replace("&E", "Location"));

			}
			Location location = locationRepository.findByLocationId(locationId);
			// Validation
			if (location == null)
				throw new ServiceException(
						ErrorConstants.ID_INVALID.replace("&E", "Location").replace("&V", locationId.toString()));

			// All sheet approval needed for all pods before config, true
			// signifies pod and false means location.
			for (Pod pod : location.getPodList()) {
				monitorSheetService.configEligibility(pod.getPodId(), true);
			}

			long count = podRepository.countByLocation(location);

			if (count > 0) {
				logger.error("Location cannot be deleted because it has associated Pods");
				throw new ServiceException(ErrorConstants.CANNOT_DELETE_ASSOCIATED_WITH_ENTITIES
						.replace("&E", "Location").replace("&&**", location.getLocationName())
						.replace("$$**", String.valueOf(count)).replace("$$$$", "Pods").replace("&V", "deleted"));
			}

			logger.debug(location.getLocationName() + " deleted by " + loggedInUser.getFirstName() + " "
					+ loggedInUser.getLastName());

			locationRepository.delete(location);
			logger.info("Successfully deleted location: " + location.getLocationName());
		} else {
			logger.error("Location can only deleted by a manager");
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Locations").replace("&V", "delete"));
		}
	}

	public void disableLocation(Long locationId, Boolean disable) throws ServiceException {
		logger.info("Disabling locationId: " + locationId);
		User user = authenticationService.getAuthenticatedUser();
		if (!userService.isManager(user)) {
			logger.error("Location can only disabled by a manager");
			throw new ServiceException(
					ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Locations").replace("&V", "disable"));
		}

		Location location = locationRepository.findByLocationId(locationId);
		// Validate
		if (location == null)
			throw new ServiceException(
					ErrorConstants.ID_INVALID.replace("&E", "Location").replace("&V", locationId.toString()));

		// All sheet approval needed for all pods before config
		for (Pod pod : location.getPodList()) {
			monitorSheetService.configEligibility(pod.getPodId(), true);
		}

		for (Pod pod : location.getPodList()) {

			for (Category category : pod.getCategoryList()) {
				for (SubCategory subCategory : category.getSubCategoryList()) {
					subCategory.setDisabled(disable);
					subCategoryRepository.saveAndFlush(subCategory);
				}
				category.setDisabled(disable);
				categoryRepository.saveAndFlush(category);
			}

			for (Channel channel : pod.getChannelList()) {
				channel.setDisabled(disable);
				channelService.saveAndFlush(channel);
			}

			pod.setDisabled(disable);
			podRepository.saveAndFlush(pod);
		}

		location.setDisabled(disable);
		locationRepository.saveAndFlush(location);
		logger.info("Successfully disabled location: " + location.getLocationName());

	}
}
