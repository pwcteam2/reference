package com.monitor.service;

import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.List;
import java.util.Locale;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.joda.time.DateTime;
import org.joda.time.DateTimeFieldType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.monitor.ApplicationInitializer;
import com.monitor.DTO.ReportCarrierDTO;
import com.monitor.configuration.PropConfig;
import com.monitor.domain.Shift;
import com.monitor.domain.ShiftSummary;
import com.monitor.domain.User;
import com.monitor.exception.ServiceException;
import com.monitor.utils.DateUtil;
import com.monitor.utils.ErrorConstants;

/**
 * Service to send emails.
 * A service provides logic to operate on the data sent to and from the Repository layer and the Controller.
 * 
 * @author Rajiv Singh Gahunia
 */
@Service
public class EmailService {
	
	@Autowired
	private AuthenticationService authenticationService;
	
	@Autowired
	private PropConfig propConfig;
	
	@Autowired
	private TemplateEngine templateEngine;
	

	@Autowired
	private JavaMailSender mailSender;
	
	@Autowired
	private ShiftService shiftService;

	private static final Logger logger = LoggerFactory.getLogger(ApplicationInitializer.class);
	
	

	/**
	 * Send password recovery.
	 *
	 * @param ShiftSummary
	 */
	public void sendSummaryReport(ShiftSummary summary,ReportCarrierDTO reportCarrierDTO) throws ServiceException {
		logger.info("Sending report email SummaryId: " + summary.getShiftSummaryId());
		Context ctx = new Context(new Locale("US"));
		String[] lines = HtmlUtils.htmlEscape(summary.getSummary()).split("\r\n|\r|\n");
		String summaryconcat = String.join("<br>",lines);
		
		ctx.setVariable("toName", propConfig.getToName());
		ctx.setVariable("summary", summaryconcat);
		ctx.setVariable("approvedBy", summary.getApprovedBy().getFirstName());
		
		String htmlContent = this.templateEngine.process("shift-summary-report.html", ctx);
		DateTime shiftDate = summary.getShiftDate();
		Shift shift =  summary.getShift();
		String date = shiftDate.get(DateTimeFieldType.dayOfMonth())+""+DateUtil.getDayOfMonthSuffix(shiftDate.get(DateTimeFieldType.dayOfMonth())) +" "+DateUtil.getMonthForInt(shiftDate.get(DateTimeFieldType.monthOfYear()))+" "+shiftDate.getYear();
		String shiftformat = getFormattedTime(shift.getStartTime().toString()) +" hrs to "+getFormattedTime(shift.getEndTime().toString())+ " hrs IST"; 
		String subject = "ZEUS monitoring shift report of "+ date+" "+shiftService.getShiftNameForEmail(shift.getName())+" Shift (" +shiftformat +")";

		sendMail2(summary.getApprovedBy().getEmail(),propConfig.getToMail(), propConfig.getToName(),subject, htmlContent, propConfig.isIncludeCcInSummaryMails() ? propConfig.getSummaryMailCcArrayList() : null,reportCarrierDTO,DateUtil.removeTime(shiftDate, "dd-MM-YYYY"));
		logger.info("Summary report sent for SummaryId: " + summary.getShiftSummaryId());
	}

	/**
	 * Send apply leave mail.
	 *
	 * @param user the user
	 * @param link the link
	 * @param firmName the firm name
	 * @param recoveryPassword the recovery password
	 * @throws ServiceException the service exception
	 */
	public void resetPasswordMail(User user,String resetPassword) throws ServiceException {
		logger.info("Sending email for resetting password");
		Context ctx = new Context(new Locale("US"));
		ctx.setVariable("userName", user.getFirstName());
		ctx.setVariable("resetPassword", resetPassword);
		String htmlContent = this.templateEngine.process("password-reset-mail.html", ctx); 
		
		try{
			sendMail2(user.getEmail(), user.getEmail(),user.getFullName(), "Monitor App password reset",htmlContent,null,null,"");
		}catch(Exception ex){
			throw new ServiceException(ErrorConstants.PASSWORD_RESET_EMAIL_SEND_FAILED);
		}
		logger.info("Email sent for resetting password");
	}
	
	private String getFormattedTime(String time){
		return time.split(":")[0]+":"+time.split(":")[1];
	}
	
	/** Send mail.
	 *
	 * @param from the from
	 * @param to the to
	 * @param subject the subject
	 * @param message the message
	 * @param file the file
	 */
	private void sendMail(final String fromMail,String toMail,String toName,
			final String subject, final String message, final List<String> ccList,ByteArrayOutputStream pdfoutputStream,String shiftDate) {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {
			public void prepare(MimeMessage mimeMessage) throws Exception {

				mimeMessage.setRecipient(javax.mail.Message.RecipientType.TO,
						new InternetAddress(toMail, toName));

				mimeMessage.setFrom(new InternetAddress(fromMail, "Monitor App Admin"));
				mimeMessage.setSubject(subject);
				InternetHeaders headers = new InternetHeaders();
				headers.addHeader("Content-type", "text/html; charset=UTF-8");
				
				if(ccList != null)
				{
					InternetAddress[] recipientAddresses = new InternetAddress[ccList.size()];
					for (int i = 0; i <= ccList.size() - 1; i++) 
						recipientAddresses[i] = new InternetAddress(ccList.get(i));
					
					mimeMessage.setRecipients(javax.mail.Message.RecipientType.CC, recipientAddresses);
				}
				
				 ByteArrayOutputStream outputStream = pdfoutputStream;
	            
				//construct the pdf body part
	           
	           
	          
	          
				MimeBodyPart body = new MimeBodyPart(headers, message.getBytes("UTF-8"));
				MimeMultipart multipart = new MimeMultipart();
				
				 if(outputStream !=null){
					 byte[] bytes = outputStream.toByteArray();
					 DataSource dataSource = new ByteArrayDataSource(bytes, "application/pdf");
					 MimeBodyPart pdfBodyPart = new MimeBodyPart();
					 pdfBodyPart.setDataHandler(new DataHandler(dataSource));
					 pdfBodyPart.setFileName("Monitor Report "+shiftDate+".pdf");
					 multipart.addBodyPart(pdfBodyPart);
				 }

				
				multipart.addBodyPart(body);
				
				mimeMessage.setContent(multipart);
			}
		};

		this.mailSender.send(preparator);
	}
	
	/** Send mail.
	 *
	 * @param from the from
	 * @param to the to
	 * @param subject the subject
	 * @param message the message
	 * @param file the file
	 */
	private void sendMail2(final String fromMail,String toMail,String toName,
			final String subject, final String message, final List<String> ccList,ReportCarrierDTO reportCarrierDTO,String shiftDate) {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {
			public void prepare(MimeMessage mimeMessage) throws Exception {

				mimeMessage.setRecipient(javax.mail.Message.RecipientType.TO,
						new InternetAddress(toMail, toName));

				mimeMessage.setFrom(new InternetAddress(fromMail, "Monitor App Admin"));
				mimeMessage.setSubject(subject);
				InternetHeaders headers = new InternetHeaders();
				headers.addHeader("Content-type", "text/html; charset=UTF-8");
				
				if(ccList != null)
				{
					InternetAddress[] recipientAddresses = new InternetAddress[ccList.size()];
					for (int i = 0; i <= ccList.size() - 1; i++) 
						recipientAddresses[i] = new InternetAddress(ccList.get(i));
					
					mimeMessage.setRecipients(javax.mail.Message.RecipientType.CC, recipientAddresses);
				}
				
				 ReportCarrierDTO tempCarrierDTO = reportCarrierDTO;
	            
				//construct the pdf body part
	           
	           
	          
	          
				MimeBodyPart body = new MimeBodyPart(headers, message.getBytes("UTF-8"));
				MimeMultipart multipart = new MimeMultipart();
				
				 if(tempCarrierDTO !=null){
					 String base64PdfReport = tempCarrierDTO.getBase64PdfReport();
					 byte[] pdfBytes = Base64.getMimeDecoder().decode(base64PdfReport);
					 DataSource pdfDataSource = new ByteArrayDataSource(pdfBytes, "application/pdf");
					 MimeBodyPart pdfBodyPart = new MimeBodyPart();
					 pdfBodyPart.setDataHandler(new DataHandler(pdfDataSource));
					 pdfBodyPart.setFileName("Monitor Report "+shiftDate+".pdf");
					 multipart.addBodyPart(pdfBodyPart);
					 
					 
					 String base64ErrorReport = tempCarrierDTO.getBase64ErrorReport();
					 if(base64ErrorReport != null && !base64ErrorReport.isEmpty()) {
						 byte[] errorBytes = Base64.getMimeDecoder().decode(base64ErrorReport);
						 DataSource errorDataSource = new ByteArrayDataSource(errorBytes, "application/pdf");
						 MimeBodyPart errorBodyPart = new MimeBodyPart();
						 errorBodyPart.setDataHandler(new DataHandler(errorDataSource));
						 errorBodyPart.setFileName("Error Report "+shiftDate+".pdf");
						 multipart.addBodyPart(errorBodyPart);
					 }
				 }

				
				multipart.addBodyPart(body);
				
				mimeMessage.setContent(multipart);
			}
		};

		this.mailSender.send(preparator);
	}
	
	
}
