package com.monitor.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.monitor.DTO.CategoryDTO;
import com.monitor.DTO.SubCategoryDTO;
import com.monitor.domain.Category;
import com.monitor.domain.SubCategory;
import com.monitor.domain.User;
import com.monitor.enums.PodAction;
import com.monitor.exception.ServiceException;
import com.monitor.repository.SubCategoryRepository;
import com.monitor.servicefinder.utils.Constants;
import com.monitor.utils.ErrorConstants;
import com.monitor.utils.Utility;

@Service
public class SubCategoryService {

	private SubCategoryRepository subCategoryRepository;
	private CategoryService categoryService;
	private AuthenticationService authenticationService;
	private UserService userSerice;
	private MonitorSheetService monitorSheetService;
	// private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	public SubCategoryService(SubCategoryRepository subCategoryRepository, AuthenticationService authenticationService,
			UserService userService, @Lazy CategoryService categoryService,
			@Lazy MonitorSheetService monitorSheetService) {
		this.subCategoryRepository = subCategoryRepository;
		this.authenticationService = authenticationService;
		this.categoryService = categoryService;
		this.userSerice = userService;
		this.monitorSheetService = monitorSheetService;
	}

	public SubCategoryDTO addSubcategorie(SubCategoryDTO subCategoryDTO) throws ServiceException {

		User loggedInUser = authenticationService.getAuthenticatedUser();

		if (!userSerice.isManager(loggedInUser)) {
			throw new ServiceException(ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Subcategories").replace("&V", "add"));
		}

		if (Utility.isIdEmpty(subCategoryDTO.getCategoryId())) {
			throw new ServiceException(ErrorConstants.ID_CANNOT_BE_EMPTY.replace("&E", "Category"));
		}

		Category category = categoryService.findCategoryById(subCategoryDTO.getCategoryId());

		if (category == null) {
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Category").replace("&V", subCategoryDTO.getCategoryId().toString()));
		}

		SubCategory subCategoruByName = findBySubCategoryNameAndCategoryId(subCategoryDTO.getSubCategoryName(),
				subCategoryDTO.getCategoryId());

		if (subCategoruByName != null) {
			throw new ServiceException(ErrorConstants.NAME_ALREADY_EXISTS.replace("&E", "Subcategory").replace("&V", subCategoryDTO.getSubCategoryName()));
		}

		// Will validate sub category name length
		Utility.validateStringLength(subCategoryDTO.getSubCategoryName(), "Sub Category",
				Constants.SUB_CATEGORY_LENGTH);

		// Can't alter if it's category is disabled
		if (category.isDisabled())
			throw new ServiceException(ErrorConstants.CANNOT_ADD_CATEGORY_DISABLED.replace("&E", "Subcategory"));

		// All sheet approval needed for all pods before config
		monitorSheetService.configEligibility(category.getPod().getPodId(), false);

		SubCategory subCategory = new SubCategory();
		subCategory.setCreatedDate(DateTime.now());
		subCategory.setDisabled(subCategoryDTO.isDisabled());
		subCategory.setSubCategoryName(subCategoryDTO.getSubCategoryName());
		subCategory.setCategory(category);

		if (category.getSubCategoryList() == null) {
			category.setSubCategoryList(new ArrayList<SubCategory>());
		}

		// Incrementing the config version of the pod for detecting change
		// in monitor sheet in case operator trying to save old config
		// sheet.
		monitorSheetService.storePodHistory(category.getPod(), PodAction.SUBCATEGORYADDED);
		category.getPod().setConfigurationVersion(category.getPod().getConfigurationVersion() + 1l);

		category.getSubCategoryList().add(subCategory);
		subCategory = subCategoryRepository.save(subCategory);

		return new SubCategoryDTO(subCategory.getSubCategoryId(), subCategory.getSubCategoryName(),
				subCategory.isDisabled(), category.getCategoryId());
	}

	public SubCategoryDTO editSubcategorie(SubCategoryDTO subCategoryDTO) throws ServiceException {

		User loggedInUser = authenticationService.getAuthenticatedUser();

		if (!userSerice.isManager(loggedInUser)) {
			throw new ServiceException(ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Subcategories").replace("&V", "add"));
		}

		if (Utility.isIdEmpty(subCategoryDTO.getSubCategoryId())) {
			throw new ServiceException(ErrorConstants.ID_CANNOT_BE_EMPTY.replace("&E", "Subcategory"));
		}

		SubCategory subCategory = subCategoryRepository.findBySubCategoryId(subCategoryDTO.getSubCategoryId());
		if (subCategory == null) {
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Subcategory").replace("&V", subCategoryDTO.getSubCategoryId().toString()));
		}

		// Can't alter if it's category is disabled
		if (subCategory.getCategory().isDisabled())
			throw new ServiceException(ErrorConstants.CANNOT_ALTER_CATEGORY_DISABLED.replace("&E", "Subcategory"));

		// All sheet approval needed for all pods before config
		monitorSheetService.configEligibility(subCategory.getCategory().getPod().getPodId(), false);

		// Will validate sub category name length
		Utility.validateStringLength(subCategoryDTO.getSubCategoryName(), "Sub Category",
				Constants.SUB_CATEGORY_LENGTH);
		SubCategory subCategoryByName = findBySubCategoryNameAndCategoryId(subCategoryDTO.getSubCategoryName(),
				subCategoryDTO.getCategoryId());
		if (subCategoryByName != null
				&& !subCategoryByName.getSubCategoryId().equals(subCategoryDTO.getSubCategoryId())) {
			throw new ServiceException(ErrorConstants.NAME_ALREADY_EXISTS.replace("&E", "Subcategory").replace("&V", subCategoryDTO.getSubCategoryName()));
		}

		// Can't edit if used in sheet
		if (monitorSheetService.checkIfSubCategoryExists(subCategory.getSubCategoryId()))
			throw new ServiceException(ErrorConstants.CANNOT_PERFORM_USED_IN_MONITOR_SHEET.replace("&E", "Subcategory").replace("&V", "edit"));

		// Incrementing the config version of the pod for detecting change
		// in monitor sheet in case operator trying to save old config
		// sheet.
		if (!StringUtils.equalsIgnoreCase(subCategory.getSubCategoryName(), subCategoryDTO.getSubCategoryName())) {
			monitorSheetService.storePodHistory(subCategory.getCategory().getPod(), PodAction.SUBCATEGORYEDITED);
			subCategory.getCategory().getPod()
					.setConfigurationVersion(subCategory.getCategory().getPod().getConfigurationVersion() + 1l);
		}

		subCategory.setDisabled(subCategoryDTO.isDisabled());
		subCategory.setSubCategoryName(subCategoryDTO.getSubCategoryName());

		subCategory = subCategoryRepository.save(subCategory);
		return new SubCategoryDTO(subCategory.getSubCategoryId(), subCategory.getSubCategoryName(),
				subCategory.isDisabled(), subCategory.getCategory().getCategoryId());
	}

	public List<SubCategoryDTO> getSubCategoriesByCategoryID(Long categoryId) throws ServiceException {

		authenticationService.getAuthenticatedUser();
		Category category = categoryService.findCategoryById(categoryId);

		if (category == null) {
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Category").replace("&V", categoryId.toString()));
		}

		List<SubCategory> subCategories = findByCategoryId(categoryId);

		List<SubCategoryDTO> subCategoryDtoList = new ArrayList<SubCategoryDTO>();

		for (SubCategory subCategorie : subCategories) {
			SubCategoryDTO subCategoryDto = new SubCategoryDTO(subCategorie.getSubCategoryId(),
					subCategorie.getSubCategoryName(), subCategorie.isDisabled(),
					subCategorie.getCategory().getCategoryId());
			subCategoryDtoList.add(subCategoryDto);
		}
		return subCategoryDtoList;
	}

	public List<SubCategory> findByCategoryId(Long categoryId) {
		return subCategoryRepository.findByCategoryCategoryId(categoryId);
	}

	public SubCategory findBySubCategoryId(Long subCategoryId) {
		return subCategoryRepository.findBySubCategoryId(subCategoryId);
	}

	public SubCategory findBySubCategoryNameAndCategoryId(String subCategoryName, Long categoryId) {
		return subCategoryRepository.findBySubCategoryNameAndCategoryCategoryId(subCategoryName, categoryId);
	}

	public void deleteSubCateory(Long subCategoryId) throws ServiceException {

		User loggedinUser = authenticationService.getAuthenticatedUser();

		if (!userSerice.isManager(loggedinUser)) {
			throw new ServiceException(ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Categories".replace("&V", "delete")));
		}

		if (subCategoryId == null || subCategoryId < 0) {
			throw new ServiceException(ErrorConstants.ID_CANNOT_BE_EMPTY.replace("&E", "Category"));
		}

		SubCategory existingSubCategory = findBySubCategoryId(subCategoryId);

		if (existingSubCategory == null) {
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Subcategory").replace("&V", subCategoryId.toString()));
		}

		// Can't alter if it's category is disabled
		if (existingSubCategory.getCategory().isDisabled())
			throw new ServiceException(ErrorConstants.CANNOT_ALTER_CATEGORY_DISABLED.replace("&E", "Subcategory"));

		// All sheet approval needed for all pods before config
		monitorSheetService.configEligibility(existingSubCategory.getCategory().getPod().getPodId(), false);

		// Can't delete if used in sheet
		if (monitorSheetService.checkIfSubCategoryExists(subCategoryId))
			throw new ServiceException(ErrorConstants.CANNOT_PERFORM_USED_IN_MONITOR_SHEET.replace("&E", "Subcategory").replace("&V", "delete"));

		// Incrementing the config version of the pod for detecting change
		// in monitor sheet in case operator trying to save old config
		// sheet.
		monitorSheetService.storePodHistory(existingSubCategory.getCategory().getPod(), PodAction.SUBCATEGORYDELETED);
		existingSubCategory.getCategory().getPod()
				.setConfigurationVersion(existingSubCategory.getCategory().getPod().getConfigurationVersion() + 1l);

		subCategoryRepository.delete(existingSubCategory);
	}

	public void disableSubCategory(SubCategoryDTO subCategoryDTO) throws ServiceException {

		User loggedinUser = authenticationService.getAuthenticatedUser();
		if (!userSerice.isManager(loggedinUser)) {
			throw new ServiceException(ErrorConstants.ONLY_MANAGER_CAN_DO_OPERATIONS.replace("&E", "Categories").replace("&V", "delete"));
		}

		if (Utility.isIdEmpty(subCategoryDTO.getSubCategoryId())) {
			throw new ServiceException(ErrorConstants.ID_CANNOT_BE_EMPTY.replace("&E", "Subcategory"));
		}

		SubCategory subCategory = findBySubCategoryId(subCategoryDTO.getSubCategoryId());

		if (subCategory == null) {
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Subcategory").replace("&V", subCategoryDTO.getCategoryId().toString()));
		}

		// Can't alter if it's category is disabled
		if (subCategory.getCategory().isDisabled())
			throw new ServiceException(ErrorConstants.CANNOT_ALTER_CATEGORY_DISABLED.replace("&E", "Subcategory"));

		// All sheet approval needed for all pods before config
		monitorSheetService.configEligibility(subCategory.getCategory().getPod().getPodId(), false);

		// Incrementing the config version of the pod for detecting change
		// in monitor sheet in case operator trying to save old config
		// sheet.
		monitorSheetService.storePodHistory(subCategory.getCategory().getPod(), PodAction.SUBCATEGORYDISABLED);
		subCategory.getCategory().getPod()
				.setConfigurationVersion(subCategory.getCategory().getPod().getConfigurationVersion() + 1l);

		subCategory.setDisabled(subCategoryDTO.isDisabled());
		subCategory.setModifiedDate(DateTime.now());
		subCategoryRepository.save(subCategory);
	}

	public Long countByCategory(Category category) {
		return subCategoryRepository.countByCategory(category);
	}

	public Set<SubCategory> findAllSubCategoryByPodAndDisabled(Long podId, boolean disabled) {
		return subCategoryRepository.findByCategoryPodPodIdAndDisabledOrderByCategoryNameAsc(podId, disabled);
	}

	public void saveSubCategory(SubCategory subCategory) {
		subCategoryRepository.save(subCategory);
	}

	public Long countByCategoryPodPodIdAndDisabled(Long podId, Boolean disabled) {
		return subCategoryRepository.countByCategoryPodPodIdAndDisabled(podId, disabled);
	}

}
