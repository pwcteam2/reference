package com.monitor.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.monitor.domain.User;
import com.monitor.exception.ServiceException;
import com.monitor.security.MonitorUserDetails;
import com.monitor.utils.ErrorConstants;

@Service
public class AuthenticationService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	@Lazy
	private UserService userService;

	/**
	 * Check user admin and authentication
	 * 
	 * @param user
	 *            current user
	 * @return boolean
	 * @throws ServiceException
	 */
	/*
	 * public boolean isAdmin() throws ServiceException { Employee employee =
	 * employeeService .findById(getEmployeeByAuthentication().getId()); if
	 * (employee == null) { throw new ServiceException("The user is null"); }
	 * 
	 * if (!employee.isActive()) { throw new
	 * ServiceException("The user is not active"); }
	 * 
	 * if (employee.hasRole(RoleName.ROLE_ADMIN)) return true;
	 * 
	 * return false; }
	 */

	/**
	 * Check user authentication
	 * 
	 * @return boolean
	 * @throws ServiceException
	 */
	public boolean isAuthenticated() throws ServiceException {
		try {
			return SecurityContextHolder.getContext().getAuthentication() == null ? false
					: SecurityContextHolder.getContext().getAuthentication().isAuthenticated();
		} catch (Exception e) {
			logger.error(ErrorConstants.AUTHENTICATION_ERROR, e);
			throw new ServiceException(ErrorConstants.AUTHENTICATION_ERROR, e);
		}
	}

	private MonitorUserDetails getUserByAuthentication() throws ServiceException {
		try {
			return (MonitorUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		} catch (NullPointerException e) {
			// e.printStackTrace();
			logger.error(ErrorConstants.AUTHENTICATION_NULL, e);
			throw new ServiceException(ErrorConstants.AUTHENTICATION_NULL, e);
		} catch (Exception e) {
			// e.printStackTrace();
			logger.error(ErrorConstants.AUTHENTICATION_ERROR, e);
			throw new ServiceException(ErrorConstants.AUTHENTICATION_ERROR, e);
		}
	}

	public User getAuthenticatedUser() throws ServiceException {
		User user = userService.findById(getUserByAuthentication().getId());

		if (user == null) {
			// Don't change this error message as it's binded with frontend.
			throw new ServiceException(ErrorConstants.ACCOUNT_DEACTIVATED);
		}

		if (user.isActive() != null && !user.isActive()) {
			throw new ServiceException(ErrorConstants.USER_INACTIVE);
		}

		return user;
	}

	/**
	 * Check if user is SuperAdmin and authentication
	 * 
	 * @param user
	 *            current user
	 * @return boolean
	 * @throws ServiceException
	 */
	/*
	 * public boolean isSuperAdmin() throws ServiceException { User user =
	 * userService .findById(getEmployeeByAuthentication().getId()); if (user ==
	 * null) { throw new ServiceException("The user is null"); }
	 * 
	 * if (!user.isActive()) { throw new
	 * ServiceException("The user is not active"); }
	 * 
	 * if (user.getFirm().isActive() == false) { throw new
	 * ServiceException("Firm is not active"); }
	 * 
	 * if (user.hasRole(RoleName.ROLE_SUPER_ADMIN)) return true;
	 * 
	 * return false; }
	 * 
	 * 
	 * private boolean isSuperAdmin(User user) { for (Role role :
	 * user.getRoles()) { if (role.getName().compareTo("ROLE_SUPER_ADMIN") == 0)
	 * return true; } return false; }
	 */
	//

}