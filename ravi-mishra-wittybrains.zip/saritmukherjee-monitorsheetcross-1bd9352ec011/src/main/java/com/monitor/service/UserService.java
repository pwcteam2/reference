package com.monitor.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.monitor.DTO.UserDTO;
import com.monitor.domain.Role;
import com.monitor.domain.User;
import com.monitor.enums.RoleEnum;
import com.monitor.exception.ServiceException;
import com.monitor.repository.UserRepositiry;
import com.monitor.utils.ErrorConstants;

@Service
public class UserService {

	private UserRepositiry userRepository;
	private AuthenticationService authenticationService;
	private RoleService roleService;
	private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	private EmailService emailService;

	@Autowired
	public UserService(UserRepositiry userRepository, AuthenticationService authenticationService,
			RoleService roleService, EmailService emailService) {
		this.userRepository = userRepository;
		this.authenticationService = authenticationService;
		this.roleService = roleService;
		this.emailService = emailService;
	}

	public User findById(long userId) {
		return userRepository.findByUserIdAndActiveAndDeleted(userId, true, false);
	}

	public List<User> findAll() {
		return userRepository.findAll();
	}

	public Role getUserRole() throws ServiceException {
		User loggedInUser = authenticationService.getAuthenticatedUser();
		return loggedInUser.getRole();
	}

	public List<Role> getAllRoles() throws ServiceException {
		return roleService.getRoles();
	}

	public User findByEmail(String email) {
		return userRepository.findByEmail(email);
	}

	public UserDTO getUserInfo() throws ServiceException {
		logger.info("Getting user info.");
		User user = authenticationService.getAuthenticatedUser();
		UserDTO userDto = new UserDTO();
		userDto.setEmail(user.getEmail());
		userDto.setEmployeeCode(user.getEmployeeCode());
		userDto.setFirstName(user.getFirstName());
		userDto.setLastName(user.getLastName());
		userDto.setMiddleName(user.getMiddleName());
		userDto.setRole(user.getRole().getRoleName());
		userDto.setRoleId(user.getRole().getRoleId());
		userDto.setSex(user.getSex());
		userDto.setUserId(user.getUserId());
		logger.info("Successfully got user info.");
		return userDto;
	}

	public void activeInactiveUser(UserDTO userDto) throws ServiceException {
		User loggedInUser = authenticationService.getAuthenticatedUser();

		if (!isManager(loggedInUser)) {
			logger.debug("This action can only be performed by a Manager");
			throw new ServiceException(ErrorConstants.ONLY_MANAGER_CAN_PERFORM_THIS_ACTION);
		}

		User existingUser = userRepository.findByUserId(userDto.getUserId());

		if (existingUser == null) {
			throw new ServiceException(ErrorConstants.USER_WITH_EMPLOYEE_CODE_DOES_NOT_EXIST.replace("&V", userDto.getEmployeeCode()));
		}

		existingUser.setActive(userDto.getIsActive());
		userRepository.save(existingUser);
	}

	public void editUser(UserDTO userDto) throws ServiceException {
		logger.info("User info editing for user: " + userDto.getEmail());
		User loggedInUser = authenticationService.getAuthenticatedUser();

		if (!isManager(loggedInUser)) {
			logger.debug("");
			throw new ServiceException(ErrorConstants.ONLY_MANAGER_CAN_PERFORM_THIS_ACTION);
		}

		User existingUser = userRepository.findByUserId(userDto.getUserId());

		if (existingUser == null) {
			throw new ServiceException(ErrorConstants.USER_WITH_ID_DOES_NOT_EXIST.replace("&V", userDto.getUserId().toString()));
		}

		User user = userRepository.findByEmployeeCode(userDto.getEmployeeCode());
		if (user != null && existingUser.getUserId() != user.getUserId()) {
			throw new ServiceException(ErrorConstants.USER_WITH_EMPLOYEE_CODE_ALREADY_EXISTS.replace("&V", userDto.getEmployeeCode()));
		}

		existingUser.setFirstName(userDto.getFirstName());
		existingUser.setMiddleName(userDto.getMiddleName());
		existingUser.setLastName(userDto.getLastName());
		existingUser.setModifiedBy(loggedInUser);
		// existingUser.setActive(userDto.getIsActive());
		existingUser.setSex(userDto.getSex());
		existingUser.setEmployeeCode(userDto.getEmployeeCode());

		Role newRole = roleService.findById(userDto.getRoleId());

		if (newRole == null) {
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Role").replace("&V", userDto.getRoleId().toString()));
		}

		existingUser.setRole(newRole);
		existingUser.setLastModifiedDate(DateTime.now());
		userRepository.save(existingUser);
		logger.info("Successfully edited info of user: " + existingUser.getEmail());
	}

	public void registerUser(UserDTO userDto) throws ServiceException {
		logger.info("Registering a new user: " + userDto.getEmail());
		User loggedInUser = authenticationService.getAuthenticatedUser();

		if (!isManager(loggedInUser)) {
			logger.debug("");
			throw new ServiceException(ErrorConstants.ONLY_MANAGER_CAN_PERFORM_THIS_ACTION);
		}

		User existingUser = userRepository.findByEmail(userDto.getEmail());

		if (existingUser != null) {
			throw new ServiceException(ErrorConstants.USER_WITH_EMAIL_ALREADY_EXISTS.replace("&V", existingUser.getEmail()));
		}

		existingUser = null;
		existingUser = userRepository.findByEmployeeCode(userDto.getEmployeeCode());
		if (existingUser != null) {
			throw new ServiceException(ErrorConstants.USER_WITH_EMPLOYEE_CODE_ALREADY_EXISTS.replace("&V", existingUser.getEmployeeCode()));
		}

		if (userDto.getPassword() == null || userDto.getPassword().equals("")) {
			throw new ServiceException(ErrorConstants.PASSWORD_CANNOT_BE_EMPTY);
		}

		Role role = roleService.findById(userDto.getRoleId());

		if (role == null) {
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Role").replace("&V", userDto.getRoleId().toString()));
		}

		try {
			User user = new User();
			user.setFirstName(userDto.getFirstName());
			user.setMiddleName(userDto.getMiddleName());
			user.setLastName(userDto.getLastName());
			user.setCreatedDate(DateTime.now());
			user.setLastModifiedDate(DateTime.now());
			user.setDeleted(false);
			user.setEmail(userDto.getEmail());
			user.setSex(userDto.getSex());
			user.setEmployeeCode(userDto.getEmployeeCode());
			user.setPassword(encoder.encode(userDto.getPassword()));
			user.setRole(role);
			user.setActive(true);
			userRepository.save(user);
		} catch (Exception ex) {
			logger.error(ex.toString());
			throw new ServiceException(
					"User registration for " + userDto.getFirstName() + " " + userDto.getLastName() + " failed");
		}
		logger.info("Successfully registered user: " + userDto.getEmail());
	}

	public boolean isManager(User user) {
		Role role = user.getRole();
		return role.getRoleName().equals(RoleEnum.MANAGER.name());
	}

	public boolean isSupervisor(User user) {
		Role role = user.getRole();
		return role.getRoleName().equals(RoleEnum.SUPERVISOR.name());
	}

	public boolean isOperator(User user) {
		Role role = user.getRole();
		return role.getRoleName().equals(RoleEnum.OPERATOR.name());
	}

	public List<UserDTO> getAllUsers() throws ServiceException {
		logger.info("Getting all user list");
		List<User> userList = userRepository.findAll();

		List<UserDTO> userDtoList = new ArrayList<UserDTO>();
		User loggedInUser = authenticationService.getAuthenticatedUser();

		if (!isManager(loggedInUser)) {
			logger.debug("");
			throw new ServiceException(ErrorConstants.ONLY_MANAGER_CAN_PERFORM_THIS_ACTION);
		}

		for (User user : userList) {
			UserDTO userDto = new UserDTO();
			userDto.setEmail(user.getEmail());
			userDto.setRoleId(user.getRole().getRoleId());
			userDto.setRole(user.getRole().getRoleName());
			userDto.setEmployeeCode(user.getEmployeeCode());
			userDto.setFirstName(user.getFirstName());
			userDto.setMiddleName(user.getMiddleName());
			userDto.setLastName(user.getLastName());
			userDto.setUserId(user.getUserId());
			userDto.setIsActive(user.isActive());
			userDto.setSex(user.getSex());
			userDtoList.add(userDto);
		}
		userDtoList.sort(
				(UserDTO u1, UserDTO u2) -> u1.getFirstName().toLowerCase().compareTo(u2.getFirstName().toLowerCase()));
		logger.info("Successfully got all users");
		return userDtoList;
	}

	/**
	 * Changes the password of an User.
	 *
	 * @param oldPassword
	 * @param newPassword
	 * @throws ServiceException
	 */
	public void changePassword(String oldPassword, String newPassword) throws ServiceException {
		logger.info("Changing password");
		User user = authenticationService.getAuthenticatedUser();

		if (StringUtils.isAnyEmpty(oldPassword)) {
			throw new ServiceException(ErrorConstants.OLD_PASSWORD_CANNOT_BE_BLANK);
		}

		if (StringUtils.isAnyEmpty(newPassword)) {
			throw new ServiceException(ErrorConstants.NEW_PASSWORD_DOES_NOT_MATCH);
		}

		if (encoder.matches(oldPassword, user.getPassword())) {
			user.setPassword(encoder.encode(newPassword));
			userRepository.save(user);
		} else {
			throw new ServiceException(ErrorConstants.OLD_PASSWORD_DOES_NOT_MATCH);
		}
		logger.info("Password changed");
	}

	public void resetPassword(UserDTO userDTO) throws ServiceException {
		logger.info("Resetting password");
		if (!isManager(authenticationService.getAuthenticatedUser())) {
			throw new ServiceException(ErrorConstants.OLD_PASSWORD_DOES_NOT_MATCH);
		}
		User user = userRepository.findByUserId(userDTO.getUserId());

		if (user == null) {
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "User").replace("&V", userDTO.getUserId().toString()));
		}

		String newPassword = RandomStringUtils.randomAlphanumeric(9);
		emailService.resetPasswordMail(user, newPassword);

		user.setPassword(encoder.encode(newPassword));
		userRepository.save(user);
		logger.info("Successfully reset the password");

	}

}
