package com.monitor.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;





import com.monitor.domain.Role;
import com.monitor.repository.RoleRepository;

@Service
@Transactional
public class RoleService {

	@Autowired
	private RoleRepository roleRepository;

	/**
	 * Find by id.
	 *
	 * @param id
	 *            
	 * @return the Role
	 */
	public Role findById(Integer RoleId) {
		return roleRepository.findByRoleId(RoleId);
	}
	
	/**
	 * Fetch all roles.
	 *
	 *            
	 * @return the Roles
	 */
	public List<Role> getRoles() {
		return roleRepository.findAll();
	}

}
