package com.monitor.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.joda.time.LocalTime;
import org.joda.time.format.DateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.monitor.DTO.CategorySheetDto;
import com.monitor.DTO.ChannelDTO;
import com.monitor.DTO.MonitorSheetDTO;
import com.monitor.DTO.SheetAccordianViewDTO;
import com.monitor.DTO.ShiftDTO;
import com.monitor.DTO.SubCategorySheet;
import com.monitor.DTO.TimeBracketDTO;
import com.monitor.domain.Category;
import com.monitor.domain.Channel;
import com.monitor.domain.MonitorSheet;
import com.monitor.domain.MonitorSheetDetail;
import com.monitor.domain.Pod;
import com.monitor.domain.PodHistory;
import com.monitor.domain.SheetApprovalDetail;
import com.monitor.domain.Shift;
import com.monitor.domain.ShiftSummary;
import com.monitor.domain.SubCategory;
import com.monitor.domain.TextField;
import com.monitor.domain.TimeBracketDuration;
import com.monitor.domain.User;
import com.monitor.enums.ChannelStatusEnum;
import com.monitor.enums.PodAction;
import com.monitor.enums.Status;
import com.monitor.exception.ServiceException;
import com.monitor.repository.MonitorSheetRepository;
import com.monitor.repository.PodHistoryRepository;
import com.monitor.repository.TextFieldRepository;
import com.monitor.repository.TimeBracketDurationRepository;
import com.monitor.utils.DateUtil;
import com.monitor.utils.ErrorConstants;
import com.monitor.utils.StringUtils;

@Service
public class MonitorSheetService {

	private ChannelService channelService;
	private AuthenticationService authenticationService;
	private ShiftService shiftService;
	private UserService userService;
	private ReportService reportService;
	private ShiftSummaryService shiftSummaryService;
	private MonitorSheetRepository monitorSheetRepository;
	private PodService podService;
	private MonitorSheetParserService monitorSheetParserService;
	private CategoryService categoryService;
	private SubCategoryService subCategoryService;
	private TextFieldRepository textFieldRepository;
	private EmailService emailService;
	private TimeBracketDurationRepository timeBracketDurationRepository;
	private PodHistoryRepository podHistoryRepository;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	public MonitorSheetService(ChannelService channelService, AuthenticationService authenticationService,
			ShiftService shiftService, UserService userService, @Lazy ReportService reportService,
			@Lazy ShiftSummaryService shiftSummaryService, MonitorSheetRepository monitorSheetRepository,
			PodService podService, MonitorSheetParserService monitorSheetParserService, CategoryService categoryService,
			SubCategoryService subCategoryService, TextFieldRepository textFieldRepository, EmailService emailService,
			TimeBracketDurationRepository timeBracketDurationRepository, PodHistoryRepository podHistoryRepository) {

		this.channelService = channelService;
		this.authenticationService = authenticationService;
		this.shiftService = shiftService;
		this.userService = userService;
		this.reportService = reportService;
		this.shiftSummaryService = shiftSummaryService;
		this.monitorSheetRepository = monitorSheetRepository;
		this.podService = podService;
		this.monitorSheetParserService = monitorSheetParserService;
		this.categoryService = categoryService;
		this.subCategoryService = subCategoryService;
		this.textFieldRepository = textFieldRepository;
		this.emailService = emailService;
		this.timeBracketDurationRepository = timeBracketDurationRepository;
		this.podHistoryRepository = podHistoryRepository;
	}

	/**
	 * Below codes are by Sarit Mukherjee It will get the accordian views by
	 * these three parameters.
	 *
	 * @param podId
	 * @param shiftDate
	 * @param shiftId
	 * @return
	 * @throws ServiceException
	 */
	public List<SheetAccordianViewDTO> getAccordianList(Long podId, String shiftDate, Long shiftId)
			throws ServiceException {
		logger.info(
				"Getting accordian view for podId: " + podId + ", shift date: " + shiftDate + ", shiftId: " + shiftId);
		List<SheetAccordianViewDTO> sheetAccordianViewDTOList = new ArrayList<>();
		List<MonitorSheet> monitorSheetList = new ArrayList<>();
		DateTime dateTime = DateTimeFormat.forPattern("dd-MM-yyyy").parseDateTime(shiftDate);
		monitorSheetList = monitorSheetRepository
				.findByPodPodIdAndShiftDateAndShiftShiftIdAndStatusNotOrderByCreatedDateDesc(podId,
						dateTime.withTimeAtStartOfDay(), shiftId, Status.CONFIGURATION);
		for (MonitorSheet monitorSheet : monitorSheetList) {
			DateTime endDate = null;
			if (monitorSheet.getCompleteDate() == null)
				endDate = monitorSheet.getModifiedDate();
			else
				endDate = monitorSheet.getCompleteDate();

			SheetAccordianViewDTO sheetAccordianViewDTO = new SheetAccordianViewDTO(monitorSheet.getMonitorId(),
					monitorSheet.getCreatedBy().getFullName(), monitorSheet.getCreatedBy().getUserId(),
					monitorSheet.getCreatedDate(), endDate, monitorSheet.getOperatorRemarks(), monitorSheet.getStatus(),
					getTimeBracket(monitorSheet.getMonitorId()));
			sheetAccordianViewDTOList.add(sheetAccordianViewDTO);
		}
		logger.info("Successfully got the accordian view list");
		return sheetAccordianViewDTOList;

	}

	// Getting all monitorSheetDTOs by the given monitor ids
	public MonitorSheetDTO getMonitorSheetList(Long monitorId, Long channelId) throws ServiceException {
		logger.info("Getting monitor sheetId: " + monitorId);
		// In case monitor id is not given
		MonitorSheetDTO monitorSheetDTO = new MonitorSheetDTO();
		MonitorSheet monitorSheet = new MonitorSheet();

		// Used in case switching channel before creating the sheet.
		if (monitorId == null) {
			// Validating channel id
			Channel channel = channelService.findById(channelId);
			if (channel == null)
				throw new ServiceException(
						ErrorConstants.ID_INVALID.replace("&E", "Channel").replace("&V", channelId.toString()));
			Pod pod = channel.getPod();
			monitorSheet.setPod(pod);

			if (pod.isDisabled())
				throw new ServiceException(ErrorConstants.IS_DISABLED.replace("&E", "Pod"));

			// Checking for valid shift id
			Shift shift = shiftService.getCurrentShift();
			monitorSheet.setShift(shift);

			// Setting current shift date
			monitorSheet.setShiftDate(shiftService.getShiftDate(DateTime.now()));
			monitorSheetDTO = monitorSheetParserService.convertToMonitorSheetStringDTO(monitorSheet, channelId, true,
					false);
			return monitorSheetDTO;
		}
		// In case channelId not given as it is optional initializing it to 0.
		channelId = channelId == null ? 0 : channelId;
		monitorSheet = monitorSheetRepository.findByMonitorId(monitorId);
		if (monitorSheet == null)
			throw new ServiceException(
					ErrorConstants.ID_INVALID.replace("&E", "Monitor").replace("&V", monitorId.toString()));

		monitorSheetDTO = monitorSheetParserService.convertToMonitorSheetStringDTO(monitorSheet, channelId, false,
				false);
		logger.info("Successfully got the sheetId: " + monitorId);
		return monitorSheetDTO;
	}

	/**
	 * This Method is used to save a MonitorSheet data. If channel id is given
	 * as it is non mandatory then particular channel will be saved otherwise
	 * all channel data will be saved. Action is used as this(saveMonitorSheet)
	 * api is used in complete, as well approve to save data so to generate
	 * custom error for specific event.
	 * 
	 * @param monitorSheetDTO
	 * @param channelId
	 * @param action
	 * @return
	 * @throws ServiceException
	 */
	public Long saveMonitorSheet(MonitorSheetDTO monitorSheetDTO, Long channelId, String action)
			throws ServiceException {
		logger.info("Performing " + action + " for monitorId: " + monitorSheetDTO.getMonitorId());
		MonitorSheet monitorSheet = null;
		Pod pod = null;

		// As action is non mandatory thus setting save for null
		if (action == null || action.isEmpty())
			action = "save";

		// Validating monitor id. And is required or mandatory.
		Long monitorId = monitorSheetDTO.getMonitorId();
		if (monitorId != null) {
			monitorSheet = monitorSheetRepository.findByMonitorId(monitorId);
			if (monitorSheet == null)
				throw new ServiceException(
						ErrorConstants.ID_INVALID.replace("&E", "Monitor sheet").replace("&V", monitorId.toString()));
		}

		if (monitorSheet != null) {
			// Storing history of previous instance.
			if (!monitorSheet.getStatus().getStatus().equalsIgnoreCase(Status.SAVED.getStatus()))
				monitorSheetParserService.storeHistory(monitorSheet, action,
						authenticationService.getAuthenticatedUser());

			// Validating pod
			if (monitorSheetDTO.getPodId() != monitorSheet.getPod().getPodId()) {
				throw new ServiceException(ErrorConstants.POD_ID_INVALID_SHEET_CREATED_FOR_DIFF_POD.replace("&V",
						monitorSheetDTO.getPodId().toString()));
			}

			// Validating Shift
			if (monitorSheetDTO.getShiftId() != monitorSheet.getShift().getShiftId()) {
				throw new ServiceException(ErrorConstants.SHIFT_ID_INVALID_SHEET_CREATED_FOR_DIFF_SHIFT.replace("&V",
						monitorSheetDTO.getShiftId().toString()));
			}

			// Validating Shift date
			LocalDateTime localDateTime = DateUtil.resetTime(monitorSheetDTO.getShiftDate()).toLocalDateTime();
			if (!localDateTime.isEqual(monitorSheet.getShiftDate().toLocalDateTime())) {
				throw new ServiceException(ErrorConstants.SHIFT_DATE_INVALID_SHEET_CREATED_ON_DIFF_DATE.replace("&V",
						monitorSheetDTO.getShiftDate().toString()));
			}

			// Only the operator created this sheet and supervisor and manager
			// will be able to save for submit it.
			User currentUser = authenticationService.getAuthenticatedUser();
			if (currentUser.getUserId() != monitorSheet.getCreatedBy().getUserId()
					&& userService.isOperator(currentUser)) {
				throw new ServiceException(ErrorConstants.YOU_CANNOT_MODIFY_THE_SHEET);
			}

			// Only a manager can alter an approved sheet.
			if (monitorSheet.getStatus().getStatus().equalsIgnoreCase(Status.APPROVED.getStatus())
					&& !userService.isManager(currentUser))
				throw new ServiceException(ErrorConstants.ONLY_MANAGER_CAN_ALTER_APPROVED_SHEET);

			// Manager should not be able to update the sheet by pressing the
			// approve button onscreen. Because Approval can be done once. But
			// using the update button manager can alter the sheet.
			if (monitorSheet.getStatus().getStatus().equalsIgnoreCase(Status.APPROVED.getStatus())
					&& userService.isManager(currentUser) && action.equalsIgnoreCase("Approve"))
				throw new ServiceException(ErrorConstants.SHEET_ALREADY_APPROVED);

			// // Manager and supervisor can not save the sheet before the
			// current
			// // shift ends for saved sheets.
			// if (!userService.isOperator(currentUser) &&
			// (monitorSheet.getShiftDate().withTimeAtStartOfDay().isEqual(
			// DateTime.now().withTimeAtStartOfDay()) &&
			// shiftService.isCurrentShift(monitorSheet.getShift())
			// &&
			// monitorSheet.getStatus().getStatus().equalsIgnoreCase(Status.SAVED.getStatus())))
			// throw new ServiceException(
			// ErrorConstants.SHEET_NOT_COMPLETED_BY_OPERATOR_CANNOT_TAKE_ACTION.replace("&V",
			// action));

			// Manager and supervisor can not save the sheet before the current
			// shift ends for saved sheets.
			if (!userService.isOperator(currentUser)
					&& (shiftService.isCurrentShift(monitorSheet.getShiftDate(), monitorSheet.getShift().getShiftId())
							&& monitorSheet.getStatus().getStatus().equalsIgnoreCase(Status.SAVED.getStatus())))
				throw new ServiceException(
						ErrorConstants.SHEET_NOT_COMPLETED_BY_OPERATOR_CANNOT_TAKE_ACTION.replace("&V", action));

			// // Operator can't save a sheet after ending of current shift.
			// if (userService.isOperator(currentUser) &&
			// !(monitorSheet.getShiftDate().withTimeAtStartOfDay().isEqual(
			// DateTime.now().withTimeAtStartOfDay()) &&
			// shiftService.isCurrentShift(monitorSheet.getShift())))
			// throw new
			// ServiceException(ErrorConstants.SHIFT_OVER_CANNOT_TAKE_ACTION.replace("&V",
			// action));

			// Operator can't save a sheet after ending of current shift.
			if (userService.isOperator(currentUser)
					&& !shiftService.isCurrentShift(monitorSheet.getShiftDate(), monitorSheet.getShift().getShiftId()))
				throw new ServiceException(ErrorConstants.SHIFT_OVER_CANNOT_TAKE_ACTION.replace("&V", action));

			// Setting approver remarks
			if (monitorSheetDTO.getApproverRemarks() != null && !monitorSheetDTO.getApproverRemarks().isEmpty()
					&& !userService.isOperator(currentUser)) {
				SheetApprovalDetail sheetApprovalDetail = monitorSheet.getSheetApprovalDetail();
				if (sheetApprovalDetail == null)
					sheetApprovalDetail = new SheetApprovalDetail();
				sheetApprovalDetail.setApproverRemarks(monitorSheetDTO.getApproverRemarks());
				monitorSheet.setSheetApprovalDetail(sheetApprovalDetail);
			}

			monitorSheet.setOperatorRemarks(monitorSheetDTO.getOperatorRemarks());

			// monitorSheet.setStatus(Status.SAVED);
			monitorSheet = monitorSheetParserService.convertToMonitorSheetString(monitorSheetDTO, monitorSheet,
					channelId, false);
		} else {
			logger.info("Creating a new sheet for podId: " + monitorSheetDTO.getPodId());
			// Creating new monitor sheet
			monitorSheet = new MonitorSheet();
			// Checking for valid pod id
			if (monitorSheetDTO.getPodId() != null) {
				pod = podService.findById(monitorSheetDTO.getPodId());
				if (pod == null)
					throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Pod").replace("&V",
							monitorSheetDTO.getPodId().toString()));
				monitorSheet.setPod(pod);
			} else {
				throw new ServiceException(ErrorConstants.MANDATORY_FIELD_ID_SHOULD_BE_GIVEN.replace("&E", "Pod"));
			}

			if (monitorSheetDTO.getConfigurationVersion().longValue() != pod.getConfigurationVersion().longValue())
				throw new ServiceException(ErrorConstants.POD_CONFIGURATION_CHANGED_TRY_AGAIN);

			// Latest config sheet for this pod
			MonitorSheet tempSheet = monitorSheetRepository
					.findTop1ByStatusAndPodPodIdOrderByCreatedDateDesc(Status.CONFIGURATION, pod.getPodId());

			if (monitorSheetDTO.getConfigurationSheetId().longValue() != tempSheet.getMonitorId().longValue())
				throw new ServiceException(ErrorConstants.POD_CONFIGURATION_CHANGED_TRY_AGAIN);

			// // Checking for valid shift id
			// Shift shift = shiftService.getCurrentShift();
			// if (shift != shiftService.findById(monitorSheetDTO.getShiftId()))
			// throw new
			// ServiceException(ErrorConstants.SHIFT_OVER_CANNOT_TAKE_ACTION.replace("&V",
			// action));
			// monitorSheet.setShift(shift);
			//
			// // Setting current shift date
			// if (monitorSheetDTO.getShiftDate().getMillis() !=
			// DateUtil.resetTime(new DateTime()).getMillis())
			// throw new
			// ServiceException(ErrorConstants.SHIFT_OVER_CANNOT_TAKE_ACTION.replace("&V",
			// action));
			// monitorSheet.setShiftDate(shiftService.getShiftDate(DateTime.now()));

			// Checking for valid shift id
			Shift shift = shiftService.getCurrentShift();

			// Setting current shift date
			if (!shiftService.isCurrentShift(monitorSheetDTO.getShiftDate(), monitorSheetDTO.getShiftId()))
				throw new ServiceException(ErrorConstants.SHIFT_OVER_CANNOT_TAKE_ACTION.replace("&V", action));
			monitorSheet.setShift(shift);
			monitorSheet.setShiftDate(shiftService.getShiftDate(DateTime.now()));

			// Preventing multiple sheet in a single time bracket
			TimeBracketDTO currentTimeBracket = getCurrentTimeBracket(pod.getPodId());

			if (monitorSheetRepository.findByPodAndShiftAndShiftDateAndTimeBracketIdAndStatusNot(pod, shift,
					monitorSheet.getShiftDate(), currentTimeBracket.getTimeBracketId(), Status.CONFIGURATION)
					.size() != 0)
				throw new ServiceException(ErrorConstants.CANNOT_CREATE_ANOTHER_SHEET_IN_SAME_TIME_BRACKET.replace("&E",
						currentTimeBracket.getTimeBracketValue()));

			List<MonitorSheet> monitorSheetList = monitorSheetRepository.findByPodAndShiftAndShiftDateAndStatus(pod,
					shift, monitorSheet.getShiftDate(), Status.SAVED);
			if (monitorSheetList.size() > 0)
				throw new ServiceException(ErrorConstants.SAVED_SHEET_PRESENT_SUBMIT_TO_CREATE_NEW);

			// Setting the operator who is creating this sheet.
			User operator = authenticationService.getAuthenticatedUser();
			monitorSheet.setCreatedBy(operator);

			// Setting operator remarks.
			monitorSheet.setOperatorRemarks(monitorSheetDTO.getOperatorRemarks());

			// Setting approver remarks
			if (monitorSheetDTO.getApproverRemarks() != null && !monitorSheetDTO.getApproverRemarks().isEmpty()
					&& !userService.isOperator(operator)) {
				SheetApprovalDetail sheetApprovalDetail = new SheetApprovalDetail();
				sheetApprovalDetail.setApproverRemarks(monitorSheetDTO.getApproverRemarks());
				monitorSheet.setSheetApprovalDetail(sheetApprovalDetail);
			}

			// Setting status as created for 1st time insert.
			monitorSheet.setStatus(Status.SAVED);

			// Storing config version for future use
			monitorSheet.setConfigurationVersion(monitorSheet.getPod().getConfigurationVersion());

			// Storing time bracket information.
			if (currentTimeBracket.getTimeBracketId().longValue() != monitorSheetDTO.getTimeBracketDTO()
					.getTimeBracketId().longValue())
				throw new ServiceException(ErrorConstants.TIME_BRACKET_CHANGED_REFRESH_THE_PAGE.replace("&E",
						currentTimeBracket.getTimeBracketValue()));
			monitorSheet.setTimeBracketId(monitorSheetDTO.getTimeBracketDTO().getTimeBracketId());
			monitorSheet.setTimeBracketInMinutes(monitorSheetDTO.getTimeBracketDTO().getTimeBracketInMinutes());

			// Creating an empty list
			monitorSheet.setMonitorSheetDetails(new ArrayList<>());
			monitorSheet = monitorSheetParserService.convertToMonitorSheetString(monitorSheetDTO, monitorSheet, null,
					false);
		}
		Long id = monitorSheetRepository.save(monitorSheet).getMonitorId();
		System.out.println(checkIfRedOrGreen(monitorSheet));
		logger.info("Successfully created/saved monitorId: " + id);
		return id;
	}

	/**
	 * Will create a monitor sheet.With given podid. But will not create a DB
	 * entry.
	 * 
	 * @param podId
	 * @return
	 * @throws ServiceException
	 */
	public MonitorSheetDTO createMonitorSheet(Long podId) throws ServiceException {
		logger.info("Creating blank sheet for podId: " + podId);
		MonitorSheetDTO monitorSheetDTO = new MonitorSheetDTO();
		MonitorSheet monitorSheet = new MonitorSheet();

		// Checking for valid pod id
		Pod pod = podService.findById(podId);
		if (pod == null)
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Pod").replace("&V", podId.toString()));
		monitorSheet.setPod(pod);

		if (pod.getLocation().isDisabled())
			throw new ServiceException(ErrorConstants.IS_DISABLED.replace("&E", "Location"));

		if (pod.isDisabled())
			throw new ServiceException(ErrorConstants.IS_DISABLED.replace("&E", "Pod"));

		// Checking for valid shift id
		Shift shift = shiftService.getCurrentShift();
		monitorSheet.setShift(shift);

		// Setting current shift date
		monitorSheet.setShiftDate(shiftService.getShiftDate(DateTime.now()));

		if (monitorSheetRepository
				.findByPodAndShiftAndShiftDateAndStatus(pod, shift, monitorSheet.getShiftDate(), Status.SAVED)
				.size() != 0)
			throw new ServiceException(ErrorConstants.ALL_SHEET_NEED_TO_BE_COMPLETED_TO_CREATE_NEW);

		// Preventing multiple sheet in a single time bracket
		TimeBracketDTO currentTimeBracket = getCurrentTimeBracket(podId);

		if (monitorSheetRepository.findByPodAndShiftAndShiftDateAndTimeBracketIdAndStatusNot(pod, shift,
				monitorSheet.getShiftDate(), currentTimeBracket.getTimeBracketId(), Status.CONFIGURATION).size() != 0)
			throw new ServiceException(ErrorConstants.CANNOT_CREATE_ANOTHER_SHEET_IN_SAME_TIME_BRACKET.replace("&E",
					currentTimeBracket.getTimeBracketValue()));

		if (channelService.countByPodPodIdAndDisabled(podId, false) == 0)
			throw new ServiceException(
					ErrorConstants.NO_ACTIVE_ENTITY_ASSOCIATED_WITH_THE_POD.replace("&E", "Channel"));

		if (categoryService.countByPodPodIdAndDisabled(podId, false) == 0)
			throw new ServiceException(
					ErrorConstants.NO_ACTIVE_ENTITY_ASSOCIATED_WITH_THE_POD.replace("&E", "Category"));

		if (subCategoryService.countByCategoryPodPodIdAndDisabled(podId, false) == 0)
			throw new ServiceException(
					ErrorConstants.NO_ACTIVE_ENTITY_ASSOCIATED_WITH_THE_POD.replace("&E", "Subcategory"));

		// Latest config sheet for this pod
		MonitorSheet tempSheet = monitorSheetRepository
				.findTop1ByStatusAndPodPodIdOrderByCreatedDateDesc(Status.CONFIGURATION, podId);

		if (tempSheet == null)
			throw new ServiceException(ErrorConstants.NO_CONFIGURATION_SHEET_CREATED_BY_MANAGER);

		if (tempSheet.getConfigurationVersion().longValue() != monitorSheet.getPod().getConfigurationVersion()
				.longValue())
			throw new ServiceException(ErrorConstants.POD_CONFIGURATION_CHANGED_ASK_MANAGER_TO_UPDATE);

		// Now creating the monitorSheetDTO from the monitor sheet.
		monitorSheetDTO = monitorSheetParserService.convertToMonitorSheetStringDTO(monitorSheet, 0l, false, false);

		monitorSheetDTO.setConfigurationSheetId(tempSheet.getMonitorId());

		logger.info("Successfully generated a blank sheet for podId: " + podId);
		return monitorSheetDTO;

	}

	/**
	 * Used to complete a sheet. Can be done by the operator created the sheet
	 * or supervisor or manager.
	 * 
	 * @param monitorId
	 * @throws ServiceException
	 */
	public void completeMonitorSheet(Long monitorId) throws ServiceException {
		logger.info("Completing monitorId: " + monitorId);
		// Validating monitor id. And is required or mandatory.
		MonitorSheet monitorSheet = monitorSheetRepository.findByMonitorId(monitorId);
		if (monitorSheet == null)
			throw new ServiceException(
					ErrorConstants.ID_INVALID.replace("&E", "Monitor").replace("&V", monitorId.toString()));
		// An approved sheet can't be completed again
		if (monitorSheet.getStatus().getStatus().equalsIgnoreCase(Status.APPROVED.getStatus()))
			throw new ServiceException(ErrorConstants.CANNOT_COMPLETE_APPROVED_SHEET);

		// Only the operator created this sheet and supervisor and manager
		// will be able to complete.
		User currentUser = authenticationService.getAuthenticatedUser();
		if (currentUser.getUserId() != monitorSheet.getCreatedBy().getUserId() && userService.isOperator(currentUser)) {
			throw new ServiceException(ErrorConstants.YOU_CANNOT_MODIFY_THE_SHEET);
		}

		// // Completion can be done after shift end
		// User user = authenticationService.getAuthenticatedUser();
		// if (!userService.isOperator(user)
		// &&
		// monitorSheet.getShiftDate().withTimeAtStartOfDay().isEqual(DateTime.now().withTimeAtStartOfDay())
		// && shiftService.isCurrentShift(monitorSheet.getShift())) {
		// throw new
		// ServiceException(ErrorConstants.CANNOT_COMPLETE_BEFORE_CURRENT_SHIFT_ENDS);
		// }

		// Completion can be done after shift end
		User user = authenticationService.getAuthenticatedUser();
		if (!userService.isOperator(user)
				&& shiftService.isCurrentShift(monitorSheet.getShiftDate(), monitorSheet.getShift().getShiftId())) {
			throw new ServiceException(ErrorConstants.CANNOT_COMPLETE_BEFORE_CURRENT_SHIFT_ENDS);
		}

		// Caution for completing for all channel if it is a saved sheet and
		// enabled channels>channels in DB then all channel data should be
		// saved.
		if (monitorSheet.getStatus().getStatus().equalsIgnoreCase(Status.SAVED.getStatus())
				&& (monitorSheet.getMonitorSheetDetails().size() < channelService
						.findByPodPodIdAndDisabledOrderByCreatedDateAsc(monitorSheet.getPod().getPodId(), false)
						.size())) {
			MonitorSheetDTO monitorSheetDTO = getMonitorSheetList(monitorId, 0l);
			saveMonitorSheet(monitorSheetDTO, null, "complete");
		}
		// Operator cant complete after shift ends
		if (userService.isOperator(user)
				&& !(shiftService.isCurrentShift(monitorSheet.getShiftDate(), monitorSheet.getShift().getShiftId())))
			throw new ServiceException(ErrorConstants.SHIFT_OVER_CANNOT_TAKE_ACTION.replace("&V", "complete"));

		// Supervisor cant complete twice a sheet after shift ends.
		if (userService.isSupervisor(user)
				&& monitorSheet.getStatus().getStatus().equalsIgnoreCase(Status.COMPLETED.getStatus())
				&& !(shiftService.isCurrentShift(monitorSheet.getShiftDate(), monitorSheet.getShift().getShiftId())))
			throw new ServiceException(ErrorConstants.SHIFT_OVER_CANNOT_TAKE_ACTION.replace("&V", "complete"));

		// Storing the first time completer and complete date time.
		if (monitorSheet.getStatus().getStatus().equalsIgnoreCase(Status.SAVED.getStatus())) {
			monitorSheet.setCompleteDate(DateTime.now());
			monitorSheet.setCompleter(user);
		}

		monitorSheet.setStatus(Status.COMPLETED);

		logger.info("Successfully completed the monitorId: " + monitorId);
		monitorSheetRepository.save(monitorSheet);
	}

	/**
	 * Will get the information about the remaining channel data to be filled.
	 * 
	 * @param monitorId
	 * @return
	 * @throws ServiceException
	 */
	public Integer completionEligibility(Long monitorId) throws ServiceException {
		// Validating monitor id. And is required or mandatory.
		MonitorSheet monitorSheet = monitorSheetRepository.findByMonitorId(monitorId);
		if (monitorSheet == null)
			throw new ServiceException(
					ErrorConstants.ID_INVALID.replace("&E", "Monitor").replace("&V", monitorId.toString()));

		User currentUser = authenticationService.getAuthenticatedUser();
		// If different operator is trying to modify.
		if (currentUser.getUserId() != monitorSheet.getCreatedBy().getUserId() && userService.isOperator(currentUser)) {
			throw new ServiceException(ErrorConstants.YOU_CANNOT_MODIFY_THE_SHEET);
		}
		int numberOfChannelFilled = monitorSheet.getMonitorSheetDetails().size();
		int totalChannels = channelService.getAllChannels(null, null, monitorSheet.getPod().getPodId()).size();
		return totalChannels - numberOfChannelFilled;
	}

	/**
	 * Will get the information that if a new monitor sheet can be created for
	 * the given pod for the current shift.
	 * 
	 * @param podId
	 * @return
	 * @throws ServiceException
	 */
	public boolean createEligibility(Long podId) throws ServiceException {
		boolean eligible = false;
		// Checking for valid pod id
		Pod pod = podService.findById(podId);
		if (pod == null)
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Pod").replace("&V", podId.toString()));

		Shift shift = shiftService.getCurrentShift();

		if (monitorSheetRepository.findByPodAndShiftAndShiftDateAndStatus(pod, shift,
				shiftService.getShiftDate(DateTime.now()), Status.SAVED).size() == 0)
			eligible = true;
		return eligible;
	}

	/**
	 * This api will be used to approve a sheet. Supervisor remarks are saved
	 * via saveMonitorSheet api.
	 * 
	 * @param monitorIdList
	 * @throws ServiceException
	 */
	public void approveMonitorSheet(List<Long> monitorIdList) throws ServiceException {

		for (Long monitorId : monitorIdList) {
			logger.info("Approving monitorID: " + monitorId);
			// Validating monitor id. And is required or mandatory.
			MonitorSheet monitorSheet = monitorSheetRepository.findByMonitorId(monitorId);
			if (monitorSheet == null)
				throw new ServiceException(
						ErrorConstants.ID_INVALID.replace("&E", "Monitor").replace("&V", monitorId.toString()));

			// Restrict operators
			User user = authenticationService.getAuthenticatedUser();
			if (userService.isOperator(user))
				throw new ServiceException(ErrorConstants.YOU_CANNOT_MODIFY_THE_SHEET);

			// // Supervisor can't approve twice
			// if
			// (monitorSheet.getStatus().getStatus().equalsIgnoreCase(Status.APPROVED.getStatus())
			// && userService.isSupervisor(user)) {
			// throw new ServiceException("The sheet is already approved");
			// }

			// No one can approve twice
			if (monitorSheet.getStatus().getStatus().equalsIgnoreCase(Status.APPROVED.getStatus())) {
				throw new ServiceException(ErrorConstants.SHEET_ALREADY_APPROVED);
			}

			// // Approval can be done after shift end
			// if
			// (monitorSheet.getShiftDate().withTimeAtStartOfDay().isEqual(DateTime.now().withTimeAtStartOfDay())
			// && shiftService.isCurrentShift(monitorSheet.getShift())) {
			// throw new ServiceException("You can not approve the sheet before
			// the current shift ends.");
			// }

			// Sheet should be completed to be approved.
			if (monitorSheet.getStatus().getStatus().equalsIgnoreCase(Status.SAVED.getStatus())) {
				throw new ServiceException(ErrorConstants.SHEET_NOT_COMPLETED_TO_APPROVE.replace("&V",
						DateUtil.removeTime(monitorSheet.getCreatedDate())));
			}

			// Finding existing sheetApprovalDetail as approver remarks are
			// updated separately by save api.
			SheetApprovalDetail sheetApprovalDetail = monitorSheet.getSheetApprovalDetail();
			if (sheetApprovalDetail == null) {
				sheetApprovalDetail = new SheetApprovalDetail();
			}
			sheetApprovalDetail.setApprover(user);
			sheetApprovalDetail.setApprovedDate(new DateTime());
			monitorSheet.setSheetApprovalDetail(sheetApprovalDetail);

			monitorSheet.setStatus(Status.APPROVED);

			monitorSheetRepository.saveAndFlush(monitorSheet);
			logger.info("Successfully approved monitorId: " + monitorId);
			// Sending email in case summary already approved and all monitor
			// sheets are also getting approved.
			Shift shift = monitorSheet.getShift();
			DateTime shiftDate = monitorSheet.getShiftDate();
			ChannelStatusEnum logState = getLogState(shift, shiftDate);
			ChannelStatusEnum summaryState = shiftSummaryService.getLogState(shift, shiftDate);
			if ((logState.equals(ChannelStatusEnum.APPROVED) || logState.equals(ChannelStatusEnum.NO_ENTRIES))
					&& summaryState.equals(ChannelStatusEnum.APPROVED)) {
				ShiftSummary summary = shiftSummaryService.findByShiftAndShiftDate(shift, shiftDate);

				if (!summary.getMailSent()) {
					// emailService.sendSummaryReport(summary, getPdf(shiftDate,
					// shift.getShiftId()));
					try {
						emailService.sendSummaryReport(summary,
								shiftSummaryService.getPdf(shiftDate, shift.getShiftId()));
					} catch (Exception e) {
						throw new ServiceException(ErrorConstants.SUMMARY_REPORT_EMAIL_SEND_FAILED);
					}
					summary.setMailSent(true);
					shiftSummaryService.save(summary);
				}
			}
		}

	}

	/**
	 * Will be used to get all enabled channels for a pod in case new sheet or
	 * saved sheet. For completed or approved sheets channels will be according
	 * to the sheet in DB.
	 * 
	 * @param monitorId
	 *            is not mandatory
	 * @param podId
	 *            is mandatory
	 * @return
	 * @throws ServiceException
	 */
	public List<ChannelDTO> monitorsheetchannellist(Long monitorId, Long podId) throws ServiceException {
		logger.debug("Getting monitorSheet Channels for monitorId: " + monitorId + ", podId: " + podId);
		List<ChannelDTO> channelDTOList = new ArrayList<>();
		MonitorSheet monitorSheet = null;

		// Validate podId
		if (podService.findById(podId) == null)
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Pod").replace("&V", podId.toString()));

		channelDTOList = channelService.findByPodPodIdAndDisabledOrderByCreatedDateAsc(podId, false);

		if (monitorId != null) {
			monitorSheet = monitorSheetRepository.findByMonitorId(monitorId);
			if (monitorSheet == null)
				throw new ServiceException(
						ErrorConstants.ID_INVALID.replace("&E", "Monitor").replace("&V", monitorId.toString()));

			if (!monitorSheet.getStatus().getStatus().equalsIgnoreCase(Status.SAVED.getStatus())) {
				// In this condition new list to be generated according to the
				// DB
				channelDTOList.clear();
				for (MonitorSheetDetail monitorSheetDetail : monitorSheet.getMonitorSheetDetails()) {
					Channel channel = monitorSheetDetail.getChannel();
					channelDTOList.add(new ChannelDTO(channel.getChannelId(), channel.getChannelName(),
							channel.getNocNumber(), channel.getCreatedDate()));
				}
				// Sorting the list according to channel name
				// channelDTOList = channelDTOList.stream()
				// .sorted((o1, o2) ->
				// o1.getChannelName().compareToIgnoreCase(o2.getChannelName()))
				// .collect(Collectors.toList());
				// Sorting the list according to created date
				channelDTOList = channelDTOList.stream()
						.sorted((o1, o2) -> o1.getCreatedDate().compareTo(o1.getCreatedDate()))
						.collect(Collectors.toList());
			}
		}
		logger.debug("Successfully got all channels for monitorSheetId: " + monitorId + ", podId: " + podId);
		return channelDTOList;
	}

	/**
	 * Return error if there is saved or completed entry for a pod. Boolean type
	 * defines Location for true and Pod for false
	 * 
	 * @param podId
	 * @param type
	 * @return
	 * @throws ServiceException
	 */
	public Boolean configEligibility(Long podId, Boolean type) throws ServiceException {
		Boolean eligibility = true;
		String componentType = null;

		Pod pod = podService.findById(podId);
		if (pod == null)
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Pod").replace("&V", podId.toString()));

		List<Status> statusList = new ArrayList<>();
		statusList.add(Status.SAVED);
		statusList.add(Status.COMPLETED);
		List<MonitorSheet> monitorSheetList = monitorSheetRepository.findByPodAndStatusIn(pod, statusList);
		if (monitorSheetList.size() > 0l)
			eligibility = false;
		if (type)
			componentType = pod.getLocation().getClass().getSimpleName();
		else
			componentType = pod.getClass().getSimpleName();
		if (eligibility == false)
			throw new ServiceException("This " + componentType.toLowerCase() + " has some unapproved sheet(s) for date "
					+ monitorSheetList.get(0).getShiftDate().toString("dd/MM/yyyy") + " in "
					+ monitorSheetList.get(0).getShift().getName() + " shift. Please approve them and try again");
		return eligibility;
	}

	/**
	 * Checking if used in existing sheets.
	 * 
	 * @param subCategoryId
	 * @return
	 */
	public Boolean checkIfSubCategoryExists(Long subCategoryId) {
		if (textFieldRepository.countBySubCategorySubCategoryId(subCategoryId) > 0l)
			return true;

		return false;
	}

	/**
	 * Checking if used in existing sheets.
	 * 
	 * @param channelId
	 * @return
	 */
	public Boolean checkIfChannelExists(Long channelId) {
		if (monitorSheetRepository.countByChannelId(channelId) > 0l)
			return true;

		return false;
	}

	/**
	 * Checking if used in existing sheets.
	 * 
	 * @param categoryId
	 * @return
	 */
	public Boolean checkIfCategoryExists(Long categoryId) {
		Category category = categoryService.findCategoryById(categoryId);
		for (SubCategory subCategory : category.getSubCategoryList()) {
			if (textFieldRepository.countBySubCategorySubCategoryId(subCategory.getSubCategoryId()) > 0l)
				return true;
		}

		return false;
	}

	/**
	 * Checking if used in existing sheets.
	 * 
	 * @param podId
	 * @return
	 */
	public Boolean checkIfPodExists(Long podId) {
		if (monitorSheetRepository.countByPodPodId(podId) > 0l)
			return true;

		return false;
	}

	/**
	 * Used for shiftsummary. Summary management.
	 * 
	 * @param shift
	 * @param shiftDate
	 * @return
	 */
	public ChannelStatusEnum getLogState(Shift shift, DateTime shiftDate) {
		List<Status> statusList = new ArrayList<>();
		statusList.add(Status.SAVED);
		statusList.add(Status.COMPLETED);
		Long notApprovedCount = monitorSheetRepository.countByShiftDateAndShiftShiftIdAndStatusIn(shiftDate,
				shift.getShiftId(), statusList);
		// Configuration Sheets should not be counted.
		Long count = monitorSheetRepository.countByShiftDateAndShiftShiftIdAndStatusNot(shiftDate, shift.getShiftId(),
				Status.CONFIGURATION);

		if (notApprovedCount == 0 && count > 0) {
			return ChannelStatusEnum.APPROVED;
		}

		if (notApprovedCount > 0) {
			return ChannelStatusEnum.PENDING;
		}

		return ChannelStatusEnum.NO_ENTRIES;
	}

	/**
	 * This method is used to get the monitor sheet for report creation(Both pdf
	 * and excel) excluding CONFIGURATION sheets.
	 * 
	 * @param podId
	 * @param shiftId
	 * @param timeBracketId
	 * @param startDate
	 * @return
	 * @throws ServiceException
	 */
	public MonitorSheetDTO findByPodPodIdAndShiftShiftIdAndTimeBracketIdAndCreatedDateBetweenOrderByPodCreatedDateAscModifiedDateAscCreatedDateAsc(
			Long podId, Long shiftId, Long timeBracketId, DateTime startDate)
			throws ServiceException {

		// MonitorSheet monitorSheet = monitorSheetRepository
		// .findByPodPodIdAndShiftShiftIdAndTimeBracketIdAndStatusAndCreatedDateBetweenOrderByPodCreatedDateAscCreatedDateAsc(
		// podId, shiftId, timeBracketId, Status.APPROVED, startDate, endDate);

		MonitorSheet monitorSheet = monitorSheetRepository
				.findByPodPodIdAndShiftShiftIdAndTimeBracketIdAndStatusAndShiftDateOrderByPodCreatedDateAscCreatedDateAsc(
						podId, shiftId, timeBracketId, Status.APPROVED, startDate.withTimeAtStartOfDay());

		if (monitorSheet != null)
			return getMonitorSheetList(monitorSheet.getMonitorId(), null);

		return null;
	}

	/**
	 * Get the sheet for the given filter.
	 * 
	 * @param podList
	 * @param shiftlist
	 * @param timeBracketIdList
	 * @param startDate
	 * @param endDate
	 * @return
	 * @throws ServiceException
	 */
	public MonitorSheet getReportMonitorSheet(Long podId, Long shiftId, Long timeBracketId, DateTime startDate) throws ServiceException {
		MonitorSheet monitorSheet = new MonitorSheet();
		monitorSheet = monitorSheetRepository
				.findByPodPodIdAndShiftShiftIdAndTimeBracketIdAndStatusAndShiftDateOrderByPodCreatedDateAscCreatedDateAsc(
						podId, shiftId, timeBracketId, Status.APPROVED, startDate.withTimeAtStartOfDay());
		return monitorSheet;
	}

	/**
	 * Used to create CONFIGURATION sheet for the manager. With including the
	 * last CONFIGURATION sheet subCategory values. Only can be used by the
	 * manager.
	 * 
	 * @param podId
	 * @return
	 * @throws ServiceException
	 */
	public MonitorSheetDTO createConfigMonitorSheet(Long podId) throws ServiceException {
		logger.info("Creating a configuration sheet for podId: " + podId);
		MonitorSheetDTO monitorSheetDTO = new MonitorSheetDTO();
		MonitorSheet monitorSheet = new MonitorSheet();

		// Checking for valid pod id
		Pod pod = podService.findById(podId);
		if (pod == null)
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Pod").replace("&V", podId.toString()));

		if (pod.getLocation().isDisabled())
			throw new ServiceException(ErrorConstants.IS_DISABLED.replace("&E", "Location"));

		if (pod.isDisabled())
			throw new ServiceException(ErrorConstants.IS_DISABLED.replace("&E", "Pod"));

		// Only manager is authorized for configuring a monitor sheet.
		User user = authenticationService.getAuthenticatedUser();
		if (!userService.isManager(user))
			throw new ServiceException(ErrorConstants.MANAGER_CAN_ONLY_CREATE_CONFIGURATION_SHEET);

		// Ensure that there is no saved or completed sheet in this pod
		// otherwise will throw exception
		configEligibility(podId, false);

		// Setting pod.
		monitorSheet.setPod(pod);

		// Checking for valid shift id
		Shift shift = shiftService.getCurrentShift();
		monitorSheet.setShift(shift);

		// Setting current shift date
		monitorSheet.setShiftDate(shiftService.getShiftDate(DateTime.now()));

		if (channelService.countByPodPodIdAndDisabled(podId, false) == 0)
			throw new ServiceException(
					ErrorConstants.NO_ACTIVE_ENTITY_ASSOCIATED_WITH_THE_POD.replace("&E", "Channel"));

		if (categoryService.countByPodPodIdAndDisabled(podId, false) == 0)
			throw new ServiceException(
					ErrorConstants.NO_ACTIVE_ENTITY_ASSOCIATED_WITH_THE_POD.replace("&E", "Category"));

		if (subCategoryService.countByCategoryPodPodIdAndDisabled(podId, false) == 0)
			throw new ServiceException(
					ErrorConstants.NO_ACTIVE_ENTITY_ASSOCIATED_WITH_THE_POD.replace("&E", "Subcategory"));

		MonitorSheet tempSheet = monitorSheetRepository
				.findTop1ByStatusAndPodPodIdOrderByCreatedDateDesc(Status.CONFIGURATION, podId);

		// if (tempSheet == null) {
		// // Now creating the monitorSheetDTO from the monitor sheet.

		// Creating new sheet for manager with data of the last CONFIGURATION
		// sheet.
		monitorSheetDTO = monitorSheetParserService.convertToMonitorSheetStringDTO(monitorSheet, 0l, true, true);
		// }else {
		// monitorSheetDTO =
		// monitorSheetParserService.convertToMonitorSheetStringDTO(tempSheet,
		// 0l, false, false);
		//// }

		// Storing previous config sheet Id.
		if (tempSheet != null)
			monitorSheetDTO.setConfigurationSheetId(tempSheet.getMonitorId());

		logger.info("Successfully created a configuration sheet for podId: " + podId);
		return monitorSheetDTO;
	}

	/**
	 * Used for saving specially the CONFIGURATION sheets created by the
	 * manager.
	 * 
	 * @param monitorSheetDTO
	 * @return
	 * @throws ServiceException
	 */
	public Long saveConfigMonitorSheet(MonitorSheetDTO monitorSheetDTO) throws ServiceException {
		logger.info("Saving a configuration sheet for podId: " + monitorSheetDTO.getPodId());
		MonitorSheet monitorSheet = null;
		Pod pod = null;

		// Creating new monitor sheet
		monitorSheet = new MonitorSheet();
		// Checking for valid pod id
		if (monitorSheetDTO.getPodId() != null) {
			pod = podService.findById(monitorSheetDTO.getPodId());
			if (pod == null)
				throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Pod").replace("&V",
						monitorSheetDTO.getPodId().toString()));
			monitorSheet.setPod(pod);
		} else {
			throw new ServiceException(ErrorConstants.MANDATORY_FIELD_ID_SHOULD_BE_GIVEN.replace("&E", "Pod"));
		}

		if (monitorSheetDTO.getConfigurationVersion().longValue() != pod.getConfigurationVersion().longValue())
			throw new ServiceException(ErrorConstants.POD_CONFIGURATION_CHANGED_TRY_AGAIN);

		// Latest config sheet for this pod
		MonitorSheet tempSheet = monitorSheetRepository
				.findTop1ByStatusAndPodPodIdOrderByCreatedDateDesc(Status.CONFIGURATION, pod.getPodId());

		// if (monitorSheetDTO.getConfigurationSheetId() != null && tempSheet !=
		// null) {
		// if (monitorSheetDTO.getConfigurationSheetId().longValue() !=
		// tempSheet.getMonitorId().longValue())
		// throw new
		// ServiceException(ErrorConstants.POD_CONFIGURATION_CHANGED_TRY_AGAIN);
		// }

		if (tempSheet != null) {
			if (monitorSheetDTO.getConfigurationSheetId() == null && tempSheet.getMonitorId() != null)
				throw new ServiceException(ErrorConstants.POD_CONFIGURATION_CHANGED_TRY_AGAIN);

			if (monitorSheetDTO.getConfigurationSheetId() != null
					&& (monitorSheetDTO.getConfigurationSheetId().longValue() != tempSheet.getMonitorId().longValue()))
				throw new ServiceException(ErrorConstants.POD_CONFIGURATION_CHANGED_TRY_AGAIN);
		}

		// Checking for valid shift id
		Shift shift = shiftService.getCurrentShift();
		monitorSheet.setShift(shift);

		// Setting current shift date
		monitorSheet.setShiftDate(shiftService.getShiftDate(DateTime.now()));

		// Only manager is authorized for configuring a monitor sheet.
		User user = authenticationService.getAuthenticatedUser();
		if (!userService.isManager(user))
			throw new ServiceException(ErrorConstants.MANAGER_CAN_ONLY_CREATE_CONFIGURATION_SHEET);

		// Ensure that there is no saved or completed sheet in this pod
		// otherwise will throw exception
		configEligibility(pod.getPodId(), false);

		monitorSheet.setCreatedBy(user);

		// Setting status as CONFIGURATION sheet
		monitorSheet.setStatus(Status.CONFIGURATION);

		// Storing config version for future reference
		monitorSheet.setConfigurationVersion(monitorSheet.getPod().getConfigurationVersion());

		storePodHistory(pod, PodAction.SHEETCONFIGURED);

		// Storing time bracket information.
		TimeBracketDTO currentTimeBracket = getCurrentTimeBracket(monitorSheetDTO.getPodId());

		monitorSheet.setTimeBracketId(currentTimeBracket.getTimeBracketId());
		monitorSheet.setTimeBracketInMinutes(currentTimeBracket.getTimeBracketInMinutes());

		// Creating an empty list
		monitorSheet.setMonitorSheetDetails(new ArrayList<>());
		monitorSheet = monitorSheetParserService.convertToMonitorSheetString(monitorSheetDTO, monitorSheet, null, true);
		logger.info("Successfully saved a configuration sheet for podId: " + monitorSheet.getPod().getPodId());
		return monitorSheetRepository.save(monitorSheet).getMonitorId();
	}

	/**
	 * This method will be used to get the time bracket list by of a pod. Shift
	 * id list given will determine the number of timebrackets.
	 * timeBracketInMinutes can be null. In that case pod's time bracket will be
	 * used. If timeBracketInMinutes is given in minutes, it will be considered
	 * to create the timebracketList.
	 * 
	 * @param podId
	 * @param shiftIds
	 * @param timeBracketInMinutes
	 * @return
	 * @throws ServiceException
	 */
	public List<TimeBracketDTO> getTimeBracketList(Long podId, Long[] shiftIds, Integer timeBracketInMinutes)
			throws ServiceException {
		logger.debug("Getting all time brackets for podId: " + podId + " and shift: "
				+ StringUtils.toStringForList(shiftIds));
		List<TimeBracketDTO> timeBracketList = new ArrayList<>();
		List<ShiftDTO> allShift = shiftService.getAllShift();

		// Incase all shifts are selected.
		if (shiftIds == null)
			shiftIds = new Long[allShift.size()];

		List<Long> shiftIdList = Arrays.asList(shiftIds);
		// Validating pod id.
		Pod pod = podService.findById(podId);
		if (pod == null)
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Pod").replace("&V", podId.toString()));

		if (timeBracketInMinutes == null)
			timeBracketInMinutes = pod.getTimeBracketInMinutes();

		// The given time bracket in minutes for a pod should divide a shift
		// into a whole number of time brackets. Like for a 12 hours shift, 30
		// mins of time bracket means total 24 time brackets. Here 24 is a whole
		// number. It should not be like 15.6 or 24.5 etc.
		if ((24 * 60 / allShift.size()) % timeBracketInMinutes != 0)
			throw new ServiceException(ErrorConstants.IS_INVALID.replace("&E", "Time Bracket duration").replace("&V",
					timeBracketInMinutes.toString()));

		// If a single shift is selected.
		if (shiftIdList.size() == 1) {
			// For a particular shift.

			// Shift index calculation is needed because shifts are consecutive
			// and needs to be in order. Assuming they are in order from the
			// shiftService.getAllShift() api.
			int shiftIndex = 0;
			for (ShiftDTO shiftDTO : allShift) {
				if (shiftDTO.getShiftId().longValue() == shiftIdList.get(0))
					shiftIndex = allShift.indexOf(shiftDTO);
			}

			// Checking for valid shift id
			Shift shift = shiftService.findById(shiftIdList.get(0));
			if (shift == null)
				throw new ServiceException(
						ErrorConstants.ID_INVALID.replace("&E", "Shift").replace("&V", shiftIds.toString()));

			DateTime shiftStartTime = new DateTime(shift.getStartTime());
			DateTime shiftEndTime = new DateTime(shift.getEndTime());

			// This if-else statement is used in case the shift contains a date
			// change after 12:00 AM.
			if (shiftStartTime.isBefore(shiftEndTime) || shiftStartTime.isEqual(shiftEndTime)) {
				timeBracketList = addTimeBrackets(shiftStartTime, shiftEndTime, timeBracketList,
						(long) shiftIndex * (24 * 60 / allShift.size()) / timeBracketInMinutes, pod,
						timeBracketInMinutes);
			} else {
				timeBracketList = addTimeBrackets(shiftStartTime, shiftEndTime.plusDays(1), timeBracketList,
						(long) shiftIndex * (24 * 60 / allShift.size()) / timeBracketInMinutes, pod,
						timeBracketInMinutes);
			}

		} else {
			// For all shifts.
			List<Long> allShiftIds = allShift.stream().map(x -> x.getShiftId()).collect(Collectors.toList());
			for (Long id : allShiftIds) {
				Long[] ids = { id };
				for (TimeBracketDTO timeBracketDTO : getTimeBracketList(podId, ids, timeBracketInMinutes)) {
					timeBracketList.add(timeBracketDTO);
				}
			}
		}
		logger.debug("Successfully got all time brackets for podId: " + podId + " and shift: "
				+ StringUtils.toStringForList(shiftIds));
		return timeBracketList;
	}

	/**
	 * addTimeBrackets method is used to create and add time brackets into the
	 * list given and return that list.
	 * 
	 * @param start
	 * @param end
	 * @param timeBracketList
	 * @param count
	 * @param pod
	 * @param timeBracketInMinutes
	 * @return
	 */
	public List<TimeBracketDTO> addTimeBrackets(DateTime start, DateTime end, List<TimeBracketDTO> timeBracketList,
			Long count, Pod pod, Integer timeBracketInMinutes) {
		for (DateTime bracketStartTime = start; bracketStartTime.isBefore(end) || bracketStartTime
				.isEqual(end); bracketStartTime = bracketStartTime.plusMinutes(timeBracketInMinutes)) {
			timeBracketList.add(new TimeBracketDTO(++count, bracketStartTime, timeBracketInMinutes, pod.getPodId()));
		}

		return timeBracketList;
	}

	/**
	 * getTimeBracket is used to get the time bracket of a monitor sheet.
	 * 
	 * @param monitorId
	 * @return
	 * @throws ServiceException
	 */
	public TimeBracketDTO getTimeBracket(Long monitorId) throws ServiceException {
		MonitorSheet monitorSheet = monitorSheetRepository.findByMonitorId(monitorId);
		if (monitorSheet == null)
			throw new ServiceException(
					ErrorConstants.ID_INVALID.replace("&E", "Monitor").replace("&V", monitorId.toString()));

		List<TimeBracketDTO> timeBracketList = getTimeBracketList(monitorSheet.getPod().getPodId(), null, null);
		for (TimeBracketDTO timeBracketDTOTemp : timeBracketList) {
			DateTime bracketStartTime = timeBracketDTOTemp.getTimeBracketStartTime()
					.withDate(monitorSheet.getCreatedDate().toLocalDate());
			DateTime bracketEndTime = bracketStartTime.plusMinutes(monitorSheet.getTimeBracketInMinutes())
					.withDate(monitorSheet.getCreatedDate().toLocalDate());
			if (bracketStartTime.isBefore(monitorSheet.getCreatedDate())
					&& bracketEndTime.isAfter(monitorSheet.getCreatedDate()))
				return timeBracketDTOTemp;
		}
		return null;
	}

	/**
	 * getCurrentTimeBracket is used to get the current running time bracket for
	 * a pod. Specially used while creating a blank sheet for the frontend for
	 * createMinitorSheet api.
	 * 
	 * @param podId
	 * @return
	 * @throws ServiceException
	 */
	public TimeBracketDTO getCurrentTimeBracket(Long podId) throws ServiceException {
		logger.debug("Getting current time bracket for podId: " + podId);
		// Validating pod id.
		Pod pod = podService.findById(podId);
		if (pod == null)
			throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Pod").replace("&V", podId.toString()));

		List<TimeBracketDTO> timeBracketList = getTimeBracketList(podId, null, null);
		for (TimeBracketDTO timeBracketDTOTemp : timeBracketList) {
			DateTime bracketStartTime = timeBracketDTOTemp.getTimeBracketStartTime()
					.withDate(DateTime.now().toLocalDate());
			DateTime bracketEndTime = bracketStartTime.withDate(DateTime.now().toLocalDate())
					.plusMinutes(pod.getTimeBracketInMinutes());
			if (bracketStartTime.isBefore(DateTime.now()) && bracketEndTime.isAfter(DateTime.now()))
				return timeBracketDTOTemp;
		}
		return null;
	}

	/**
	 * Used for getting the TimeBracketDTO list for the given TimeBracketIds
	 * from the timeBracketDTOList given.
	 * 
	 * @param timeBracketIds
	 * @param timeBracketDTOList
	 * @return
	 */
	public List<TimeBracketDTO> getTimeBracketList(Long[] timeBracketIds, List<TimeBracketDTO> timeBracketDTOList) {
		List<TimeBracketDTO> newList = new ArrayList<>();
		List<Long> timeBracketIdList = Arrays.asList(timeBracketIds);
		for (TimeBracketDTO timeBracketDTO : timeBracketDTOList) {
			if (timeBracketIdList.contains(timeBracketDTO.getTimeBracketId().longValue()))
				newList.add(timeBracketDTO);
		}
		return newList;
	}

	/** Get time bracket object by id given.
	 * @param timeBracketId
	 * @param timeBracketDTOList
	 * @return
	 */
	public TimeBracketDTO getTimeBracketList(Long timeBracketId, List<TimeBracketDTO> timeBracketDTOList) {
		for (TimeBracketDTO timeBracketDTO : timeBracketDTOList) {
			if (timeBracketDTO.getTimeBracketId().longValue() == timeBracketId.longValue())
				return timeBracketDTO;
		}
		return null;
	}

	public List<TimeBracketDuration> getTimeBracketDuration() {
		return timeBracketDurationRepository.findAll();
	}

	public MonitorSheet findTop1ByStatusAndPodPodIdAndCreatedDateLessThanOrderByCreatedDateDesc(Status status,
			Long podId, DateTime createdDate) {
		return monitorSheetRepository.findTop1ByStatusAndPodPodIdAndCreatedDateLessThanOrderByCreatedDateDesc(status,
				podId, createdDate);
	}

	public MonitorSheet findTop1ByStatusAndPodPodIdOrderByCreatedDateAsc(Status status, Long podId) {
		return monitorSheetRepository.findTop1ByStatusAndPodPodIdOrderByCreatedDateAsc(status, podId);
	}

	public MonitorSheet findTop1ByStatusAndPodPodIdAndCreatedDateLessThanEqualOrderByCreatedDateAsc(Status status,
			Long podId, DateTime createdDate) {
		return monitorSheetRepository.findTop1ByStatusAndPodPodIdAndCreatedDateLessThanEqualOrderByCreatedDateAsc(
				status, podId, createdDate);
	}

	public void storePodHistory(Pod pod, PodAction podAction) throws ServiceException {
		PodHistory podHistory = new PodHistory();
		podHistory.setConfigurationVersion(pod.getConfigurationVersion());
		podHistory.setDisabled(pod.isDisabled());
		podHistory.setModifier(authenticationService.getAuthenticatedUser());
		podHistory.setPod(pod);
		podHistory.setPodAction(podAction);
		podHistory.setPodName(pod.getPodName());
		podHistory.setTimeBracketInMinutes(pod.getTimeBracketInMinutes());
		podHistoryRepository.saveAndFlush(podHistory);
	}

	/**Get first time bracket id of next date.
	 * @param podId
	 * @return
	 * @throws ServiceException
	 */
	public Long getNextDayFirstTimeBracketId(Long podId) throws ServiceException {
		List<TimeBracketDTO> timeBracketList = getTimeBracketList(podId, null, null);
		for (TimeBracketDTO timeBracketDTO : timeBracketList) {
			if (timeBracketDTO.getTimeBracketStartTime().toLocalDateTime().millisOfDay().get() == 0)
				return timeBracketDTO.getTimeBracketId();
		}
		TimeBracketDTO timeBracketDTO = timeBracketList.stream().min((o1,o2) -> o1.getTimeBracketStartTime().getMillisOfDay() - o2.getTimeBracketStartTime().getMillisOfDay()).get();
		return timeBracketDTO.getTimeBracketId();
	}
	
//	private Boolean checkIfRedOrGreen(MonitorSheetDTO monitorSheetDTO) {
//		for(CategorySheetDto categorySheetDto: monitorSheetDTO.getCategorySheetList()) {
//			for(SubCategorySheet subCategorySheet: categorySheetDto.getSubCategorySheetList()) {
//				if(subCategorySheet.getChannelWiseTextFieldList().parallelStream().anyMatch(x -> x.getSelection().booleanValue() == false))
//					return false;
//			}
//		}
//		return true;
//	}
	
	private Boolean checkIfRedOrGreen(MonitorSheet monitorSheet) {
		for(MonitorSheetDetail monitorSheetDetail: monitorSheet.getMonitorSheetDetails()) {
			if(monitorSheetDetail.getTextFields().parallelStream().anyMatch(x -> x.getSelection() != null && !x.getSelection()))
				return false;
		}
		return true;
	}
}
