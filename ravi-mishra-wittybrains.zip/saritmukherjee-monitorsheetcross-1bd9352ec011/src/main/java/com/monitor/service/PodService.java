package com.monitor.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.monitor.DTO.PodDTO;
import com.monitor.domain.Pod;
import com.monitor.exception.ServiceException;
import com.monitor.repository.PodRepository;
import com.monitor.repository.TimeBracketDurationRepository;

@Service
public class PodService {

	private PodRepository podRepository;
	private TimeBracketDurationRepository timeBracketDurationRepository;
	//private final Logger logger = LoggerFactory.getLogger(this.getClass());


	@Autowired
	public PodService(AuthenticationService authenticationService,PodRepository podRepository, TimeBracketDurationRepository timeBracketDurationRepository) {
		this.podRepository =  podRepository;
		this.timeBracketDurationRepository = timeBracketDurationRepository;
	}

	public List<PodDTO> getAllPods(Long locationId) throws ServiceException {
		Set<Pod> pods= findAllByLocationLocationIdInOrderByCreatedDateAsc(locationId);
		return  getPodDTOList(new ArrayList<Pod>(pods));
	}
	
	public Set<Pod> findAllByLocationLocationIdInOrderByCreatedDateAsc(Long locationId) {
		return podRepository.findAllByLocationLocationIdInOrderByCreatedDateAsc(locationId);
	}

	
	public Pod findById(Long podId) {
		return podRepository.findByPodId(podId);
	}
	
	public Pod findByPodName(String podName) {
		return podRepository.findByPodName(podName);
	}
	
	public Set<Pod> findByPodIn(List<Long> podIds) {
		return podRepository.findByPodIdIn(podIds);
	}
	
	public List<Pod> findAll() {
		return podRepository.findAll();
	}
	
	public Long[] getAllIds() {
		return podRepository.getAllIds();
	}
    public Pod save(Pod pod){
    	return podRepository.save(pod);
    }
    
    public void deletePod(Pod pod){
    	podRepository.delete(pod);
    }

	private List<PodDTO> getPodDTOList(List<Pod> podList){
		List<PodDTO> podDtoList =  new ArrayList<PodDTO>();
		for(Pod pod:podList){
			podDtoList.add(getPodDto(pod));
		}
		return podDtoList;
	}
	
	public PodDTO getPodDto(Pod pod){
		PodDTO dto = new PodDTO();
		dto.setCreatedDate(pod.getCreatedDate());
		dto.setDeletedDate(pod.getDeletedDate());
		dto.setModifiedDate(pod.getModifiedDate());
		dto.setPodId(pod.getPodId());
		dto.setPodName(pod.getPodName());
		dto.setDisabled(pod.isDisabled());
		dto.setTimeBracketDurationId(timeBracketDurationRepository.findByDuration(pod.getTimeBracketInMinutes()).getTimeBracketDurationId());
		return dto;
	}
	
	public Pod findByPodNameInAndLocationLocationIdIn(String podName, Long locationId) {
		return podRepository.findByPodNameInAndLocationLocationIdIn(podName,locationId);
	}
	
	public Pod saveAndFlush(Pod pod) {
		return podRepository.saveAndFlush(pod);
	}
}
