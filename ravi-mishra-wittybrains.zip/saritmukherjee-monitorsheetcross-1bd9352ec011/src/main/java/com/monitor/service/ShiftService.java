package com.monitor.service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.jadira.usertype.dateandtime.joda.util.DateTimeZoneWithOffset;
import org.joda.time.DateTime;
import org.joda.time.DateTimeFieldType;
import org.joda.time.format.DateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.monitor.ApplicationInitializer;
import com.monitor.DTO.ShiftDTO;
import com.monitor.domain.Shift;
import com.monitor.enums.ShiftEnum;
import com.monitor.exception.ServiceException;
import com.monitor.repository.ShiftRepository;
import com.monitor.utils.ErrorConstants;

/**
 * @author Wittybrains
 *
 */
@Service
public class ShiftService {

	private ShiftRepository shiftRepository;
	private AuthenticationService authenticationService;
	private static final Logger logger = LoggerFactory.getLogger(ApplicationInitializer.class);

	@Autowired
	public ShiftService(ShiftRepository shiftRepository,
			AuthenticationService authenticationService) {
		this.shiftRepository = shiftRepository;
		this.authenticationService = authenticationService;
	}

	public List<ShiftDTO> getAllShift() throws ServiceException {
		logger.debug("Getting shift list");
		authenticationService.getAuthenticatedUser();
		
		List<Shift> shifts = shiftRepository.findAll();
		List<ShiftDTO> shiftDtos = new ArrayList<ShiftDTO>();

		for (Shift shift : shifts) {
			ShiftDTO shiftDto = new ShiftDTO();
			shiftDto.setShiftId(shift.getShiftId());
			shiftDto.setName(getShiftName(shift.getName()));
			shiftDto.setStartTime(shift.getStartTime());
			shiftDto.setEndTime(shift.getEndTime());
			shiftDto.setCurrentShift(isCurrentShift(shift));
			shiftDtos.add(shiftDto);
		}
		logger.debug("Successfully got shift list");
		return shiftDtos;
	}

	public ShiftDTO getCurrentShiftStartAndEndDate() throws ServiceException {
		authenticationService.getAuthenticatedUser();
		ShiftDTO shiftDto = new ShiftDTO();
 
		Shift currentShift = getCurrentShift();
		shiftDto.setEndTime(currentShift.getEndTime());
		shiftDto.setStartTime(currentShift.getStartTime());
		shiftDto.setShiftEndDate(getShiftEndTime(currentShift));
		shiftDto.setShiftStartDate(getShiftStartTime(currentShift));
		shiftDto.setCurrentShift(true);
		return shiftDto;
	}
	
	public Shift findById(long shiftId) {
		return shiftRepository.findByShiftId(shiftId);
	}

	List<Shift> findByShiftIdIn(Long[] shiftIds ){
		return shiftRepository.findByShiftIdIn(shiftIds);
	}
	
	public List<Shift> findAll() {
		return shiftRepository.findAll();
	}
	
	public DateTime getShiftStartTime(Shift currentShift){
	   
	    LocalTime shiftStartTime = currentShift.getStartTime().toLocalTime();
	    LocalTime currentDateTime = LocalDateTime.now().toLocalTime();
	    
	    LocalTime diffrene = currentDateTime.minusNanos(shiftStartTime.toNanoOfDay());
	    shiftStartTime.minusNanos(currentDateTime.toNanoOfDay());
	    	    
	    Calendar startTime = Calendar.getInstance();
	    if(shiftStartTime.isAfter(currentDateTime) || currentDateTime.isAfter(shiftStartTime)){
	    	startTime.add(Calendar.HOUR, diffrene.getHour()*-1);
	 	    startTime.add(Calendar.MINUTE, diffrene.getMinute()*-1);
	 	    startTime.add(Calendar.SECOND, diffrene.getSecond()*-1);
	    }else{
	    	startTime.add(Calendar.HOUR, diffrene.getHour());
	 	    startTime.add(Calendar.MINUTE, diffrene.getMinute());
	 	    startTime.add(Calendar.SECOND, diffrene.getSecond());
	    }
	   
	    
	    return new DateTime(startTime);    
	}
	
	
	public DateTime getShiftEndTime(Shift currentShift){	   
	    LocalTime shiftEndTime = currentShift.getEndTime().toLocalTime();
	    LocalTime currentDateTime = LocalDateTime.now().toLocalTime();
	    
	    LocalTime diff= shiftEndTime.minusNanos(currentDateTime.toNanoOfDay());
	    
	    Calendar endTime = Calendar.getInstance();
	    endTime.add(Calendar.HOUR, diff.getHour());
	    endTime.add(Calendar.MINUTE, diff.getMinute());
	    endTime.add(Calendar.SECOND, diff.getSecond());

	    return new DateTime(endTime);    
	}
	
//	public boolean isAfterCurrentShift(MonitorOldSheet monitorSheet) {
//		
//	
//		DateTime sheetCreatedDate = monitorSheet.getCreatedDate();	
//		Shift currentShift = getCurrentShift();
//
//		DateTime currentShiftStart = getShiftStartTime(currentShift); 		
//		DateTime currentShiftEnd = getShiftEndTime(currentShift);		
//		
//		if(sheetCreatedDate.isBefore(currentShiftStart) || sheetCreatedDate.isAfter(currentShiftEnd)){
//			return true;
//		}
//		
//		return false;
//	}
	
	public boolean isAfterCurrentShift(DateTime shiftDate) {
	
		DateTime sheetCreatedDate = shiftDate;	
		Shift currentShift = getCurrentShift();

		DateTime currentShiftStart = getShiftStartTime(currentShift); 		
		DateTime currentShiftEnd = getShiftEndTime(currentShift);		
		
		if(sheetCreatedDate.isBefore(currentShiftStart) || sheetCreatedDate.isAfter(currentShiftEnd)){
			return true;
		}
		
		return false;
	}
	
	public boolean afterCurrentShift(DateTime shiftDate) {
		
		DateTime sheetCreatedDate = shiftDate;	
		Shift currentShift = getCurrentShift();

		DateTime currentShiftStart = getShiftStartTime(currentShift); 		
		DateTime currentShiftEnd = getShiftEndTime(currentShift);		
		
		if(sheetCreatedDate.isAfter(currentShiftEnd)){
			return true;
		}
		
		return false;
	}
	
	public Shift getCurrentShift() {
		List<Shift> shiftList = shiftRepository.findAll();
		Shift currentShift = null;


		for (Shift shift : shiftList) {
			if (isCurrentShift(shift)) {
				currentShift = shift;
				break;
			}

		}
		return currentShift;
	}

	public DateTime addShiftTime(DateTime shiftDate,Shift shift){
		int hours = shift.getStartTime().getHours();
		int mins = shift.getStartTime().getMinutes();
		int seconds =  shift.getStartTime().getSeconds();
		
		DateTime newShiftDate = new DateTime(shiftDate);
		newShiftDate = newShiftDate.withField(DateTimeFieldType.hourOfDay(), hours);
		newShiftDate = newShiftDate.withField(DateTimeFieldType.minuteOfHour(), mins);
		newShiftDate = newShiftDate.withField(DateTimeFieldType.secondOfMinute(), seconds);
		return newShiftDate;
	}
	
	public boolean isCurrentShift(Shift shift) {
		
		LocalDateTime currentDate = LocalDateTime.now();		
		LocalTime currentTime = currentDate.toLocalTime();
		
		LocalTime startTime = shift.getStartTime().toLocalTime();
		LocalTime endTime = shift.getEndTime().toLocalTime();

		
		if (startTime.isAfter(endTime)) {// night shift
	        if (currentTime.isBefore(endTime) || currentTime.isAfter(startTime)) {
	            return true;
	        } else {
	            return false;
	        }
	    } else {// morning shift
	        if (currentTime.isBefore(endTime) && currentTime.isAfter(startTime)) {
	            return true;
	        } else {
	            return false;
	        }
	    }
		

	}

	public String getShiftNameForEmail(String shiftName){
		String shiftNameForEmail="";
		
		switch(shiftName.toLowerCase()){
		case "morning":  shiftNameForEmail = "Day";
        break;
		case "night" :  shiftNameForEmail = "Night";
        break;
		
		}
		
		return shiftNameForEmail;
	}

	private String getShiftName(String shift){
		switch (shift) {
		case "MORNING":
			return ShiftEnum.MORNING.shift();
		case "NIGHT":
			return ShiftEnum.NIGHT.shift();		
		default:
			break;
		}
		return null;
	}

	public Boolean isCurrentShift(String shiftDate, Long shiftId) throws ServiceException {
		DateTime dateTime = DateTimeFormat.forPattern("dd-MM-yyyy").parseDateTime(shiftDate);
		Shift shift = findById(shiftId);
		
		DateTime shiftStartTime = dateTime.withTime(new org.joda.time.LocalTime(shift.getStartTime()));
		DateTime shiftEndTime = dateTime.withTime(new org.joda.time.LocalTime(shift.getEndTime()));
		if(shift.getShiftId().longValue() == 2l)
			shiftEndTime = shiftEndTime.plusDays(1);
//		if(dateTime.withTimeAtStartOfDay().getMillis() != DateTime.now().withTimeAtStartOfDay().getMillis() || !isCurrentShift(shift))
//			throw new ServiceException(ErrorConstants.CANNOT_ADD_SHEET_SHIFT_OVER);
		
		if(!((shiftStartTime.isBefore(DateTime.now()) || shiftStartTime.isEqual(DateTime.now())) && (shiftEndTime.isAfter(DateTime.now()) || shiftEndTime.isEqual(DateTime.now())))) {
			throw new ServiceException(ErrorConstants.CANNOT_ADD_SHEET_SHIFT_OVER);
		}
			
		return true;
	}
	
	public Boolean isCurrentShift(DateTime shiftDate, Long shiftId) throws ServiceException {
		DateTime dateTime = shiftDate;
		Shift shift = findById(shiftId);
		
		DateTime shiftStartTime = dateTime.withTime(new org.joda.time.LocalTime(shift.getStartTime()));
		DateTime shiftEndTime = dateTime.withTime(new org.joda.time.LocalTime(shift.getEndTime()));
		if(shift.getShiftId().longValue() == 2l)
			shiftEndTime = shiftEndTime.plusDays(1);
//		if(dateTime.withTimeAtStartOfDay().getMillis() != DateTime.now().withTimeAtStartOfDay().getMillis() || !isCurrentShift(shift))
//			throw new ServiceException(ErrorConstants.CANNOT_ADD_SHEET_SHIFT_OVER);
		
		if(!((shiftStartTime.isBefore(DateTime.now()) || shiftStartTime.isEqual(DateTime.now())) && (shiftEndTime.isAfter(DateTime.now()) || shiftEndTime.isEqual(DateTime.now())))) {
			return false;
		}
			
		return true;
	}
	
	/** Will be used for getting the shift date of a datetime.
	 * @param date
	 * @return
	 * @throws ServiceException
	 */
	public DateTime getShiftDate(DateTime date) throws ServiceException {
		Shift morningShift = shiftRepository.findByShiftId(1);
		Shift nightShift = shiftRepository.findByShiftId(2);
		DateTime dayStartDateTime = date.withTime(new org.joda.time.LocalTime(morningShift.getStartTime()));
		DateTime dayEndDateTime = date.plusDays(1).withTime(new org.joda.time.LocalTime(nightShift.getEndTime()));
		
		if(date.isBefore(dayStartDateTime)) {
			return date.minusDays(1).withTimeAtStartOfDay();
		}
		if(date.isAfter(dayEndDateTime)) {
			return date.plusDays(1).withTimeAtStartOfDay();
		}
		return date.withTimeAtStartOfDay();
	}
	
	
	/**Is after current shift date. Should only be used for report purpose.
	 * @param date
	 * @return
	 * @throws ServiceException
	 */
	public Boolean isAfterShiftDate(DateTime date) throws ServiceException {
		if(date.isAfter(getShiftDate(DateTime.now().plusDays(1).minusSeconds(1)))) {
			return true;
		}
		return false;
	}
}
