package com.monitor.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.monitor.DTO.CategorySheetDto;
import com.monitor.DTO.ChannelDTO;
import com.monitor.DTO.ChannelWiseTextFieldDto;
import com.monitor.DTO.MonitorSheetDTO;
import com.monitor.DTO.SubCategorySheet;
import com.monitor.domain.Category;
import com.monitor.domain.Channel;
import com.monitor.domain.MonitorSheet;
import com.monitor.domain.MonitorSheetDetail;
import com.monitor.domain.MonitorSheetDetailHistory;
import com.monitor.domain.MonitorSheetHistory;
import com.monitor.domain.SheetApprovalDetail;
import com.monitor.domain.SubCategory;
import com.monitor.domain.TextField;
import com.monitor.domain.TextFieldHistory;
import com.monitor.domain.User;
import com.monitor.enums.Status;
import com.monitor.exception.ServiceException;
import com.monitor.repository.MonitorSheetHistoryRepository;
import com.monitor.repository.MonitorSheetRepository;
import com.monitor.repository.TextFieldRepository;
import com.monitor.servicefinder.utils.Constants;
import com.monitor.utils.ErrorConstants;
import com.monitor.utils.Utility;

/**
 * This service will be used for parsing DTO to Entity and vise versa for
 * monitor sheets.
 * 
 * @author Wittybrains
 *
 */
/**
 * @author Wittybrains
 *
 */
@Service
public class MonitorSheetParserService {

	private MonitorSheetRepository monitorSheetRepository;
	
	private MonitorSheetHistoryRepository monitorSheetHistoryRepository;

	private ChannelService channelService;

	private SubCategoryService subCategoryService;

	private TextFieldRepository textFieldRepository;

	private CategoryService categoryService;

	private MonitorSheetService monitorSheetService;

	@Autowired
	public MonitorSheetParserService(MonitorSheetRepository monitorSheetRepository, ChannelService channelService,
			SubCategoryService subCategoryService, TextFieldRepository textFieldRepository,
			CategoryService categoryService, @Lazy MonitorSheetService monitorSheetService, MonitorSheetHistoryRepository monitorSheetHistoryRepository) {
		this.monitorSheetRepository = monitorSheetRepository;
		this.channelService = channelService;
		this.subCategoryService = subCategoryService;
		this.textFieldRepository = textFieldRepository;
		this.categoryService = categoryService;
		this.monitorSheetService = monitorSheetService;
		this.monitorSheetHistoryRepository = monitorSheetHistoryRepository;
	}

	/**
	 * Used for converting from DTO to Entity of a monitorSheet with subCategory
	 * and string fields.
	 * 
	 * @param monitorSheetDTO
	 * @param monitorSheet
	 * @param channelId
	 * @param config
	 * @return
	 * @throws ServiceException
	 */
	public MonitorSheet convertToMonitorSheetString(MonitorSheetDTO monitorSheetDTO, MonitorSheet monitorSheet,
			Long channelId, boolean config) throws ServiceException {
		List<MonitorSheetDetail> monitorSheetDetails = monitorSheet.getMonitorSheetDetails();
		if (monitorSheetDetails == null)
			monitorSheetDetails = new ArrayList<>();
		// In case channelId not given as it is optional initializing it to 0.
		if (channelId != null) {
			Channel ch = channelService.findById(channelId);
			if (ch == null)
				throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Channel").replace("&V", channelId.toString()));
		} else {
			channelId = 0l;
		}
		for (CategorySheetDto categorySheet : monitorSheetDTO.getCategorySheetList()) {
			for (SubCategorySheet subCategorySheet : categorySheet.getSubCategorySheetList()) {
				for (ChannelWiseTextFieldDto channelWiseTextField : subCategorySheet.getChannelWiseTextFieldList()) {
					// Skipping in case given channel id dont match with
					// requested channel
					if (channelId != 0l && channelWiseTextField.getChannelId().longValue() != channelId.longValue())
						continue;
					Channel channel = channelService.findById(channelWiseTextField.getChannelId());
					Long textFieldId = channelWiseTextField.getTextFieldId();
					String textFieldValue = channelWiseTextField.getTextFieldValue();

					// Setting null in case empty
					if (textFieldValue != null && textFieldValue.trim() == "")
						textFieldValue = null;

					Boolean selection = channelWiseTextField.getSelection();

					// Will validate textField name length
					Utility.validateStringLength(textFieldValue, "Text field", Constants.TEXT_FIELD_LENGTH);

					SubCategory subCategory = subCategoryService
							.findBySubCategoryId(subCategorySheet.getSubCategoryId());

					TextField textField = textFieldRepository.findByTextFieldId(textFieldId) != null
							? textFieldRepository.findByTextFieldId(textFieldId)
							: new TextField(subCategory);

					if (config) {
						textField = new TextField(subCategory);
						textField.setTextFieldValue(textFieldValue);
					}

					if (!config)
						textField.setSelection(selection);

					if (!config && textField.getTextFieldId() == null) {
						textField.setTextFieldValue(textFieldValue);
					}

					MonitorSheetDetail monitorSheetDetail = null;
					// Got channel and subCategory wise textfield data. Now
					// going to add channel,subCategory,textFieldValue to
					// our
					// entity
					if (checkExsistanceEntity(channel.getChannelId(), monitorSheet)) {
						for (MonitorSheetDetail entity : monitorSheet.getMonitorSheetDetails()) {
							if (entity.getChannel().getChannelId() == channel.getChannelId())
								monitorSheetDetail = entity;
						}

						// Getting already created textField list
						List<TextField> textFields = monitorSheetDetail.getTextFields();

						Boolean subCategoryFound = false;
						// updating exsisting
						for (TextField t : textFields) {
							if (t.getSubCategory().getSubCategoryId() == subCategory.getSubCategoryId()) {
								// t.setTextFieldValue(textFieldValue);
								textField.setSelection(selection);
								subCategoryFound = true;
							}
						}
						// creating new if not exist
						if (subCategoryFound == false)
							textFields.add(textField);

						monitorSheetDetail.setTextFields(textFields);
					} else {
						monitorSheetDetail = new MonitorSheetDetail();
						monitorSheetDetail.setChannel(channel);
						List<TextField> textFields = new ArrayList<>();

						textFields.add(textField);
						monitorSheetDetail.setTextFields(textFields);
						monitorSheetDetails.add(monitorSheetDetail);
						monitorSheet.setMonitorSheetDetails(monitorSheetDetails);
					}
				}
			}
		}
		return monitorSheet;

	}

	/**
	 * Channel existance checking in monitor sheet
	 * 
	 * @param channelId
	 * @param monitorSheet
	 * @return
	 */
	private boolean checkExsistanceEntity(long channelId, MonitorSheet monitorSheet) {
		if (channelId != 0) {
			for (MonitorSheetDetail monitorSheetDetail : monitorSheet.getMonitorSheetDetails()) {
				if (monitorSheetDetail.getChannel().getChannelId() == channelId)
					return true;
			}
		}
		return false;
	}

	/**
	 * Used for converting from entity to DTO for a monitor sheet with
	 * subCategory and string fields.
	 * 
	 * @param monitorSheet
	 * @param channelId
	 *            null means all channel needed
	 * @param isCreate
	 *            If true then return first channel info selected.
	 * @param config
	 *            This is used to denote whether to use this method for creating
	 *            configuration sheet.
	 * @return
	 * @throws ServiceException
	 */
	public MonitorSheetDTO convertToMonitorSheetStringDTO(MonitorSheet monitorSheet, Long channelId, Boolean isCreate,
			Boolean config) throws ServiceException {

		boolean allChannel = false;
		if (channelId != null && channelId == 0) {
			allChannel = true;
		}
		MonitorSheetDTO monitorSheetDTO = new MonitorSheetDTO();
		monitorSheetDTO.setMonitorId(monitorSheet.getMonitorId());
		monitorSheetDTO.setPodId(monitorSheet.getPod().getPodId());

		// Null check because of NullPointerException in case of null shift date
		// or creation time.
		monitorSheetDTO.setShiftId(monitorSheet.getShift() != null ? monitorSheet.getShift().getShiftId() : null);
		monitorSheetDTO.setShiftDate(monitorSheet.getShiftDate());

		// Null check because of NullPointerException in case of null operator
		// or creation time.
		monitorSheetDTO
				.setOperatorId(monitorSheet.getCreatedBy() != null ? monitorSheet.getCreatedBy().getUserId() : null);
		monitorSheetDTO.setOperatorName(
				monitorSheet.getCreatedBy() != null ? monitorSheet.getCreatedBy().getFullName() : null);
		monitorSheetDTO.setOperatorRemarks(monitorSheet.getOperatorRemarks());

		// If the sheet is approved then get the approver name and id.Null check
		// because of NullPointerException in case of null Status or creation
		// time.
		SheetApprovalDetail sheetApprovalDetail = monitorSheet.getSheetApprovalDetail();
		if (sheetApprovalDetail != null) {
			monitorSheetDTO.setApproverRemarks(sheetApprovalDetail.getApproverRemarks());
			if (sheetApprovalDetail.getApprover() != null)
				monitorSheetDTO.setApproverName(sheetApprovalDetail.getApprover().getFullName());
		}

		// Null check because of NullPointerException in case of null created
		// and modified date is null.
		// date.
		if (monitorSheet.getCreatedDate() != null && monitorSheet.getModifiedDate() != null) {
			monitorSheetDTO.setStartTime(monitorSheet.getCreatedDate().toString("hh:mm:ss a z"));
			if (monitorSheet.getCompleteDate() == null)
				monitorSheetDTO.setEndTime(monitorSheet.getModifiedDate().toString("hh:mm:ss a z"));
			else
				monitorSheetDTO.setEndTime(monitorSheet.getCompleteDate().toString("hh:mm:ss a z"));
		}
		monitorSheetDTO.setStatus(monitorSheet.getStatus());

		// Using config version in case when an operator submit a sheet with old
		// pod design, and throw error while saving it.
		monitorSheetDTO.setConfigurationVersion(monitorSheet.getPod().getConfigurationVersion());

		List<ChannelDTO> channelDTOList = null;
		channelDTOList = monitorSheetService.monitorsheetchannellist(monitorSheet.getMonitorId(),
				monitorSheetDTO.getPodId());

		List<ChannelDTO> channelDTOList2 = new ArrayList<>(channelDTOList);

		// This channel is used for per channel view where selectedChannel is
		// the given channel.
		Channel selectedChannel = null;
		if (!allChannel) {

			// Setting default channel(1st from the channel list asc order.)
			if (channelId == null)
				channelId = channelDTOList.get(0).getChannelId();
			selectedChannel = channelService.findById(channelId);
			if (selectedChannel == null)
				throw new ServiceException(ErrorConstants.ID_INVALID.replace("&E", "Channel").replace("&V", channelId.toString()));
		}
		// Set Blank sheet table for DTO as frontend asked.
		monitorSheetDTO.setCategorySheetList(new ArrayList<>());
		if (isCreate)
			monitorSheetDTO = createSheetPerChannel(monitorSheet, monitorSheetDTO, selectedChannel, channelDTOList,
					config);
		else {
			// Setting metadata about monitor sheet done.Now going for actual
			// fields.
			List<CategorySheetDto> categorySheetList = monitorSheetDTO.getCategorySheetList();

			// Initializing in case of creation
			if (monitorSheet.getMonitorSheetDetails() == null) {
				monitorSheet.setMonitorSheetDetails(new ArrayList<>());
			}

			for (ChannelDTO channelDTO : channelDTOList2) {
				MonitorSheetDetail monitorSheetDetail = null;
				for (MonitorSheetDetail msd : monitorSheet.getMonitorSheetDetails()) {
					if (channelDTO.getChannelId() == msd.getChannel().getChannelId())
						monitorSheetDetail = msd;
				}
				if (monitorSheetDetail != null) {
					Channel channel = monitorSheetDetail.getChannel();
					// In case selective channel needed but current channel id
					// not match with it.
					if (!allChannel && selectedChannel.getChannelId() != channel.getChannelId()) {
						continue;
					}

					for (TextField textField : monitorSheetDetail.getTextFields()) {
						SubCategory subCategory = textField.getSubCategory();
						Category category = subCategory.getCategory();
						CategorySheetDto categorySheet = null;

						// Getting existing category sheet DTO
						for (CategorySheetDto dto : categorySheetList) {
							if (dto.getCategoryId() == category.getCategoryId())
								categorySheet = dto;
						}

						// If not present in the DB then create new.
						if (categorySheet == null) {
							categorySheet = new CategorySheetDto(category.getCategoryId(), category.getCategoryName());
							categorySheet.setSubCategorySheetList(new ArrayList<>());
							categorySheetList.add(categorySheet);
						}
						addSubCategorySheet(channel, textField, categorySheet, categorySheetList, config);
					}
				} else {
					if (!allChannel && selectedChannel.getChannelId() == channelDTO.getChannelId())
						monitorSheetDTO = createSheetPerChannel(monitorSheet, monitorSheetDTO,
								channelService.findById(channelDTO.getChannelId()), channelDTOList2, config);

					if (allChannel)
						monitorSheetDTO = createSheetPerChannel(monitorSheet, monitorSheetDTO,
								channelService.findById(channelDTO.getChannelId()), channelDTOList2, config);
				}
			}

			monitorSheetDTO.setCategorySheetList(categorySheetList);
		}
		
		if(monitorSheet.getMonitorId() != null)
			monitorSheetDTO.setTimeBracketDTO(monitorSheetService.getTimeBracket(monitorSheet.getMonitorId()));
		else
			monitorSheetDTO.setTimeBracketDTO(monitorSheetService.getCurrentTimeBracket(monitorSheet.getPod().getPodId()));
		return monitorSheetDTO;

	}

	/**
	 * Create a monitor sheet with no db data in it for front end view for a
	 * specific channel. Should not be used for generating sheet with DB data.
	 * 
	 * @param monitorSheet
	 * @param monitorSheetDTO
	 * @param selectedChannel
	 * @param channelDTOList
	 * @return
	 * @throws ServiceException
	 */
	private MonitorSheetDTO createSheetPerChannel(MonitorSheet monitorSheet, MonitorSheetDTO monitorSheetDTO,
			Channel selectedChannel, List<ChannelDTO> channelDTOList, Boolean config) throws ServiceException {
		Set<Category> categorySet = categoryService.findAllCategoryByPodAndDisabled(monitorSheet.getPod().getPodId(),
				false);
		if (monitorSheetDTO.getCategorySheetList() == null)
			monitorSheetDTO.setCategorySheetList(new ArrayList<>());
		for (Category category : categorySet) {
			// Skipping if no active subcategory found in the category
			if (category.getSubCategoryList().stream().filter(sc -> !sc.isDisabled()).collect(Collectors.toList())
					.size() == 0)
				continue;
			CategorySheetDto categorySheet = null;
			for (CategorySheetDto dto : monitorSheetDTO.getCategorySheetList()) {
				if (dto.getCategoryId() == category.getCategoryId())
					categorySheet = dto;
			}
			if (categorySheet == null) {
				categorySheet = new CategorySheetDto(category.getCategoryId(), category.getCategoryName());
				categorySheet.setSubCategorySheetList(new ArrayList<>());
				// Set subCategorySheetDTO
				monitorSheetDTO.getCategorySheetList().add(categorySheet);
			}
			categorySheet = addSubCategorySheet(categorySheet, category, selectedChannel, channelDTOList, config);
		}
		return monitorSheetDTO;

	}

	/**
	 * Create subcategorysheet for a categorysheet given with dummy data for
	 * front end view.Should not be used for generating sheet with DB data.
	 * 
	 * @param categorySheet
	 * @param category
	 * @param selectedChannel
	 * @param channelDTOList
	 * @param config
	 * @return
	 * @throws ServiceException
	 */
	@SuppressWarnings("unused")
	private CategorySheetDto addSubCategorySheet(CategorySheetDto categorySheet, Category category,
			Channel selectedChannel, List<ChannelDTO> channelDTOList, Boolean config) throws ServiceException {
		for (SubCategory subCategory : category.getSubCategoryList()) {
			if (subCategory.isDisabled() == true)
				continue;

			SubCategorySheet subCategorySheet = null;
			for (SubCategorySheet dto : categorySheet.getSubCategorySheetList()) {
				if (subCategory.getSubCategoryId() == dto.getSubCategoryId())
					subCategorySheet = dto;
			}

			if (subCategorySheet == null) {
				subCategorySheet = new SubCategorySheet(subCategory.getSubCategoryId(),
						subCategory.getSubCategoryName(), null);
				categorySheet.getSubCategorySheetList().add(subCategorySheet);
			}
			if (subCategorySheet.getChannelWiseTextFieldList() == null)
				subCategorySheet.setChannelWiseTextFieldList(new ArrayList<>());
			List<ChannelWiseTextFieldDto> channelWiseTextFieldDTOList = subCategorySheet.getChannelWiseTextFieldList();

			String textFieldValue = null;
			if (selectedChannel != null) {
				textFieldValue = getLatestTextFieldValue(selectedChannel.getChannelId(), subCategorySheet, config);
				ChannelWiseTextFieldDto channelWiseTextField = new ChannelWiseTextFieldDto(
						selectedChannel.getChannelId(), selectedChannel.getChannelName(), 0l, textFieldValue);
				channelWiseTextFieldDTOList.add(channelWiseTextField);
				subCategorySheet.setChannelWiseTextFieldList(channelWiseTextFieldDTOList);
			} else {
				for (ChannelDTO channelDTO : channelDTOList) {
					textFieldValue = getLatestTextFieldValue(channelDTO.getChannelId(), subCategorySheet, config);
					ChannelWiseTextFieldDto channelWiseTextField = new ChannelWiseTextFieldDto(
							channelDTO.getChannelId(), channelDTO.getChannelName(), 0l, textFieldValue);
					channelWiseTextFieldDTOList.add(channelWiseTextField);
					subCategorySheet.setChannelWiseTextFieldList(channelWiseTextFieldDTOList);
				}
			}

		}
		return categorySheet;

	}

	/**
	 * This method will be used for adding SubCategorySheet according to the db
	 * data..
	 * 
	 * @param channel,
	 *            need to added for channel wise fields.
	 * @param textField
	 *            contains the field value to be added.
	 * @param categorySheet
	 * @param categorySheetList
	 *            list of all data to be transfered
	 * @param config
	 * @return
	 */
	private CategorySheetDto addSubCategorySheet(Channel channel, TextField textField, CategorySheetDto categorySheet,
			List<CategorySheetDto> categorySheetList, Boolean config) {
		SubCategorySheet subCategorySheet = null;
		List<ChannelWiseTextFieldDto> channelWiseTextFieldDTOList = null;

		for (SubCategorySheet dto : categorySheet.getSubCategorySheetList()) {
			if (textField.getSubCategory().getSubCategoryId() == dto.getSubCategoryId())
				subCategorySheet = dto;
		}

		if (subCategorySheet == null) {
			subCategorySheet = new SubCategorySheet(textField.getSubCategory().getSubCategoryId(),
					textField.getSubCategory().getSubCategoryName(), new ArrayList<>());
			categorySheet.getSubCategorySheetList().add(subCategorySheet);
		}

		channelWiseTextFieldDTOList = subCategorySheet.getChannelWiseTextFieldList() != null
				? subCategorySheet.getChannelWiseTextFieldList()
				: new ArrayList<>();

		ChannelWiseTextFieldDto channelWiseTextField = null;
		// Creating the DTO containing the channel wise fields.
		if (!config) {
			channelWiseTextField = new ChannelWiseTextFieldDto(channel.getChannelId(), channel.getChannelName(),
					textField.getTextFieldId(), textField.getTextFieldValue(), textField.getSelection());
		} else {
			channelWiseTextField = new ChannelWiseTextFieldDto(channel.getChannelId(), channel.getChannelName(),
					textField.getTextFieldId(), textField.getTextFieldValue());
		}
		boolean flag = false;
		for (ChannelWiseTextFieldDto dto : channelWiseTextFieldDTOList) {
			if (dto.getChannelId() == channel.getChannelId()) {
				flag = true;
				channelWiseTextField = dto;
				channelWiseTextField.setTextFieldId(textField.getTextFieldId());
				channelWiseTextField.setTextFieldValue(textField.getTextFieldValue());
				if (!config)
					channelWiseTextField.setSelection(textField.getSelection());
			}
		}
		if (!flag)
			channelWiseTextFieldDTOList.add(channelWiseTextField);
		subCategorySheet.setChannelWiseTextFieldList(channelWiseTextFieldDTOList);
		return categorySheet;
	}

	public String getLatestTextFieldValue(Long channelId, SubCategorySheet subCategorySheet, Boolean config)
			throws ServiceException {
		String textFieldValue = null;
		Channel channel = channelService.findById(channelId);
		// Finding the most updated config sheet
		MonitorSheet configSheet = monitorSheetRepository
				.findTop1ByStatusAndPodPodIdOrderByCreatedDateDesc(Status.CONFIGURATION, channel.getPod().getPodId());

		if (configSheet == null && !config)
			throw new ServiceException(ErrorConstants.NO_CONFIGURATION_SHEET_CREATED_BY_MANAGER);

		if (configSheet != null) {
			for (MonitorSheetDetail monitorSheetDetail : configSheet.getMonitorSheetDetails()) {
				if (monitorSheetDetail.getChannel().getChannelId().longValue() == channel.getChannelId().longValue()) {
					for (TextField textField : monitorSheetDetail.getTextFields()) {
						if (textField.getSubCategory().getSubCategoryId().longValue() == subCategorySheet
								.getSubCategoryId().longValue())
							textFieldValue = textField.getTextFieldValue();
					}
				}
			}
		}
		return textFieldValue;
	}

	// Used to store history(Copy of the sheets) of a sheet after it's first
	// completion.
	public void storeHistory(MonitorSheet monitorSheet, String action, User user) {
		MonitorSheetHistory monitorSheetHistory = new MonitorSheetHistory();

		monitorSheetHistory.setAction(action.toUpperCase());
		monitorSheetHistory.setOperatorRemarks(monitorSheet.getOperatorRemarks());
		monitorSheetHistory.setModifier(user);

		if (monitorSheet.getSheetApprovalDetail() != null)
			monitorSheetHistory.setApproverRemarks(monitorSheet.getSheetApprovalDetail().getApproverRemarks());
		
		monitorSheetHistory.setMonitorSheetDetailHistories(new ArrayList<>());
		for(MonitorSheetDetail monitorSheetDetail : monitorSheet.getMonitorSheetDetails()) {
			MonitorSheetDetailHistory monitorSheetDetailHistory = new MonitorSheetDetailHistory();
			monitorSheetDetailHistory.setChannel(monitorSheetDetail.getChannel());
			monitorSheetDetailHistory.setTextFieldHistories(new ArrayList<>());
			for(TextField textField : monitorSheetDetail.getTextFields()) {
				TextFieldHistory textFieldHistory = new TextFieldHistory();
				textFieldHistory.setSelection(textField.getSelection());
				textFieldHistory.setSubCategory(textField.getSubCategory());
				textFieldHistory.setTextFieldHistoryValue(textField.getTextFieldValue());
				monitorSheetDetailHistory.getTextFieldHistories().add(textFieldHistory);
			}
			monitorSheetHistory.getMonitorSheetDetailHistories().add(monitorSheetDetailHistory);
		}
		monitorSheetHistory.setMonitorSheet(monitorSheet);
		monitorSheetHistoryRepository.save(monitorSheetHistory);
	}
}
