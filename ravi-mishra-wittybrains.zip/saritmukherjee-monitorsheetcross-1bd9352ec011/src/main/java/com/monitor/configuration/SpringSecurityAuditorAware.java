package com.monitor.configuration;

import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.monitor.security.MonitorUserDetails;

public class SpringSecurityAuditorAware implements AuditorAware<Long> {

	public Long getCurrentAuditor() {

		Authentication authentication = SecurityContextHolder.getContext()
				.getAuthentication();

		if (authentication == null || !authentication.isAuthenticated()) {
			return null;
		}

		return ((MonitorUserDetails) authentication.getPrincipal()).getId();
	}
}