package com.monitor.configuration;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
public class PropConfig implements InitializingBean {
	
    private static final Logger logger = LoggerFactory.getLogger(PropConfig.class);
    
    @Value("${database.driver}")
    private String databaseDriver;
    @Value("${icon.base.path}")
    private String iconBasePath;
    @Value("${database.url}")
    private String databaseUrl;
    @Value("${database.username}")
    private String databaseUsername;
    @Value("${database.password}")
    private String databasePassword;
    @Value("${database.showSql}")
    private boolean showSql;
    @Value("${database.generateDdl}")
    private boolean generateDdl;
    @Value("${database.vendor}")
    private org.springframework.orm.jpa.vendor.Database vendor;
    
    
    /**  email settings**/
    @Value("${mail.host}")
    private String mailHost;
    @Value("${mail.port}")
    private String mailPort;
    @Value("${mail.user}")
    private String mailUser;
    @Value("${mail.password}")
    private String mailPassword;
           
    @Value("${mail.toMail}")
    private String toMail;
    
    @Value("${mail.toName}")
    private String toName;
    
    @Value("${mail.testMode.enable}")
    private boolean testMode;
    @Value("${mail.test.emailId}")
    private String testEmailId;
    
    @Value("${mail.summary.includecc}")
    private boolean includeCcInSummaryMails;
    @Value("${mail.summary.cclist}")
    private String summaryMailCcList;
    
    /**
     * Allows a set of command to be run after all properties have been set.
     *
     * @throws Exception the exception
     */
    @Override
    public void afterPropertiesSet() throws Exception 
    {
        logger.debug("Application Properties={}", this);

    }
	
    
    /**
     * Get the database driver.
     *
     * @return String the Database driver in use
     */
    public String getDatabaseDriver() 
    {
        return databaseDriver;
    }

    /**
     * Sets  the database driver.
     *
     * @param databaseDriver the new database driver
     */
    public void setDatabaseDriver(String databaseDriver) 
    {
        this.databaseDriver = databaseDriver;
    }

    /**
     * Get the database url.
     *
     * @return String the database url
     */
    public String getDatabaseUrl() 
    {
        return databaseUrl;
    }

    /**
     * Sets  the database url.
     *
     * @param databaseUrl the database url
     */
    public void setDatabaseUrl(String databaseUrl) 
    {
        this.databaseUrl = databaseUrl;
    }

    /**
     * Get the database user name.
     *
     * @return String database user name
     */
    public String getDatabaseUsername() 
    {
        return databaseUsername;
    }

    /**
     * Sets  the database user name.
     *
     * @param databaseUsername user that will access the database
     */
    public void setDatabaseUsername(String databaseUsername) 
    {
        this.databaseUsername = databaseUsername;
    }

    /**
     * Get the database user's password.
     *
     * @return String user's password
     */
    public String getDatabasePassword() 
    {
        return databasePassword;
    }

    /**
     * Sets  the database user's password.
     *
     * @param databasePassword password of the user that will access the database
     */
    public void setDatabasePassword(String databasePassword) 
    {
        this.databasePassword = databasePassword;
    }

    /**
     * Showsql is set?.
     *
     * @return boolean identify is sql statements will be logged on the output or not
     */
    public boolean isShowSql() 
    {
        return showSql;
    }

    /**
     * Sets  the showsql value. 
     * @param showSql true will dump all sql statements to the output, false will suppress this output
     */
    public void setShowSql(boolean showSql) 
    {
        this.showSql = showSql;
    }

    /**
     * Data definistion language is set?.
     *
     * @return boolean state of generate ddl
     */
    public boolean isGenerateDdl() 
    {
        return generateDdl;
    }

    /**
     * Sets  the generateDdl's value.
     *
     * @param generateDdl true will generate ddl commands false otherwise
     */
    public void setGenerateDdl(boolean generateDdl) 
    {
        //this.generateDdl = generateDdl;
    	this.generateDdl = false;
    }

    /**
     * Get the database's vendor.
     *
     * @return DEFAULT,	DB2, DERBY, H2, HSQL, INFORMIX, MYSQL, ORACLE, POSTGRESQL, SQL_SERVER or SYBASE
     */
    public org.springframework.orm.jpa.vendor.Database getVendor() 
    {
        return vendor;
    }

    /**
     * Sets  database's vendor.
     *
     * @param vendor org.springframework.orm.jpa.vendor.Database (DEFAULT,	DB2, DERBY, H2, HSQL, INFORMIX, MYSQL, ORACLE, POSTGRESQL, SQL_SERVER or SYBASE)
     */
    public void setVendor(org.springframework.orm.jpa.vendor.Database vendor) 
    {
        this.vendor = vendor;
    }
    
    public String getIconBasePath(){
    	return iconBasePath;
    }


	public String getMailHost() {
		return mailHost;
	}


	public void setMailHost(String mailHost) {
		this.mailHost = mailHost;
	}


	public String getMailPort() {
		return mailPort;
	}


	public void setMailPort(String mailPort) {
		this.mailPort = mailPort;
	}


	public String getMailUser() {
		return mailUser;
	}


	public void setMailUser(String mailUser) {
		this.mailUser = mailUser;
	}


	public String getMailPassword() {
		return mailPassword;
	}


	public void setMailPassword(String mailPassword) {
		this.mailPassword = mailPassword;
	}

	public boolean isTestMode() {
		return testMode;
	}


	public void setTestMode(boolean testMode) {
		this.testMode = testMode;
	}


	public String getTestEmailId() {
		return testEmailId;
	}


	public void setTestEmailId(String testEmailId) {
		this.testEmailId = testEmailId;
	}


	public boolean isIncludeCcInSummaryMails() {
		return includeCcInSummaryMails;
	}


	public void setIncludeCcInSummaryMails(boolean includeCcInSummaryMails) {
		this.includeCcInSummaryMails = includeCcInSummaryMails;
	}


	public String getSummaryMailCcList() {
		return summaryMailCcList;
	}


	public void setSummaryMailCcList(String summaryMailCcList) {
		this.summaryMailCcList = summaryMailCcList;
	}


	public void setIconBasePath(String iconBasePath) {
		this.iconBasePath = iconBasePath;
	}

	public List<String> getSummaryMailCcArrayList() {
		return Arrays.asList(summaryMailCcList.split(","));
	}


	public String getToMail() {
		return toMail;
	}


	public void setToMail(String toMail) {
		this.toMail = toMail;
	}


	public String getToName() {
		return toName;
	}


	public void setToName(String toName) {
		this.toName = toName;
	}
	
	
    
}
