package com.monitor.utils;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class DateUtil {

	/**
	 * Reset the time from date (set to 00:00:00)
	 *
	 * @param date the Date
	 * @return the Date
	 */
	public static Date resetTime(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}
	
	/**
	 * Reset the time from date (set to 00:00:00)
	 *
	 * @param date the Date
	 * @return the Date
	 */
	public static DateTime resetTime(DateTime date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date.toDate());
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return new DateTime(cal.getTime());
	}
	
	/**
	 * Remove the time from date
	 *
	 * @param date the Date
	 * @param format the date format (like "MM/dd/YYYY")
	 * @return the date string in above format
	 */
	public static String removeTime(Date date , String format) {
		DateFormat outputFormatter = new SimpleDateFormat(format);
		return outputFormatter.format(date);
	}
	
	/**
	 * Remove the time from date
	 *
	 * @param date the Date
	 * @param format the date format (like "MM/dd/YYYY")
	 * @return the date string in above format
	 */
	public static String removeTime(DateTime date , String format) {
		DateFormat outputFormatter = new SimpleDateFormat(format);
		return outputFormatter.format(date.toDate());
	}
	
	/**
	 * Remove the time from date in and produce date in "dd/MM/yyyy" format
	 * 
	 * @param date the Date
	 * @return the date string
	 */
	public static String removeTime(Date date) {
		DateFormat outputFormatter = new SimpleDateFormat("dd/MM/yyyy");
		return outputFormatter.format(date);
	}
	
	/**
	 * Remove the time from date in and produce date in "dd/MM/yyyy" format
	 * 
	 * @param date the Date
	 * @return the date string
	 */
	public static String removeTime(DateTime date) {
		DateFormat outputFormatter = new SimpleDateFormat("dd/MM/yyyy");
		return outputFormatter.format(date.toDate());
	}
	
	public static DateTime getFormattedDateTime(String dateTime,String format){
		DateTimeFormatter formatter = DateTimeFormat.forPattern(format);
		return formatter.parseDateTime(dateTime);
	}
	
	
	public static String getMonthForInt(int num) {
        String month = "wrong";
        DateFormatSymbols dfs = new DateFormatSymbols();
        String[] months = dfs.getMonths();
        if (num >= 0 && num <= 12 ) {
            month = months[num-1];
        }
        return month;
    }
	
	public static String getDateWithMonthInString(String date){
		return  date.split("-")[0]+" "+getMonthForInt(Integer.parseInt(date.split("-")[1]))+" "+date.split("-")[2]; 
	}
	
	public static String getDayOfMonthSuffix(final int day) {
	    if (day >= 11 && day <= 13) {
	        return "th";
	    }
	    
	    switch (day % 10){
	        case 1:  return "st";
	        case 2:  return "nd";
	        case 3:  return "rd";
	        default: return "th";
	    }
	}
	
	/**
	 * Extract time from DateTime and return it's string format.
	 * @param dateTime
	 * @return String formatted time.
	 */
	public static String getTimeFromDateTime(DateTime dateTime) {
		return dateTime.toString("HH:mm:ss");
	}
}
