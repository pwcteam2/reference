package com.monitor.utils;

/**
 * This class is used to hold all the error messages used in the app. Sentences
 * with word '&E', '&V' will be replaced.
 * 
 *'&E' used for Category, Channel etc entities.
 *'&V' used for name, values or action(Like edit, delete) etc.
 * @author Wittybrains
 *
 */
public class ErrorConstants {

	public static final String AUTHENTICATION_ERROR = "Authentication error";
	public static final String AUTHENTICATION_NULL = "Authentication is null";
	public static final String ACCOUNT_DEACTIVATED = "Your account has been deactivated. Please contact manager";
	public static final String USER_INACTIVE = "The user is not active";
	

	/* POD EMPTY */
	public static final String CANNOT_BE_EMPTY = "&E cannot be empty";
	public static final String DOES_NOT_EXIST = "&E does not exist";
	
	/* ENTITY ERRORS */
	public static final String NAME_CANNOT_BE_EMPTY = "&E name cannot be empty";
	public static final String ID_CANNOT_BE_EMPTY = "&E id cannot be empty";
	public static final String ID_INVALID = "&E id is invalid: '&V'";
	public static final String MANDATORY_FIELD_ID_SHOULD_BE_GIVEN = "&E id is mandatory. It should be given";
	public static final String MANDATORY_FIELD_SHOULD_BE_GIVEN = "&E is mandatory. It should be given";
	public static final String CANNOT_ADD_POD_DISABLED = "You can't add this &E as it's Pod is disabled";
	public static final String CANNOT_ALTER_POD_DISABLED = "You can't alter this &E as it's Pod is disabled";
	public static final String CANNOT_ADD_LOCATION_DISABLED = "You can't add this &E as it's Location is disabled";
	public static final String CANNOT_ALTER_LOCATION_DISABLED = "You can't alter this &E as it's Location is disabled";
	public static final String CANNOT_ADD_CATEGORY_DISABLED = "You can't add this &E as it's Category is disabled";
	public static final String CANNOT_ALTER_CATEGORY_DISABLED = "You can't alter this &E as it's Category is disabled";
	public static final String NAME_ALREADY_EXISTS = "&E with name '&V' already exists";
	public static final String ONLY_MANAGER_CAN_DO_OPERATIONS = "Only Manager can &V &E";
	public static final String CANNOT_DELETE_ASSOCIATED_WITH_ENTITIES = "&E '&&**' contains $$** $$$$ and cannot be &V";
	public static final String IS_DISABLED = "&E is disabled";
	public static final String IS_INVALID = "&E '&V' is invalid";
	public static final String IS_INVALID_TRY_DIFF = "&E '&V' is invalid. Try something different";

	/* MONITOR SHEET RELATED ERRORS */
	public static final String CANNOT_ADD_SHEET_SHIFT_OVER = "You cannot add sheet as the shift is over";
	// '&E' is operation like edit,delete. '&V' is entity like Category,Channel.
	public static final String CANNOT_PERFORM_USED_IN_MONITOR_SHEET = "Can't &V this &E as it's been used in monitor sheets";
	public static final String NO_CONFIGURATION_SHEET_CREATED_BY_MANAGER = "There is no configuration sheet created by the manager for this pod";
	public static final String POD_ID_INVALID_SHEET_CREATED_FOR_DIFF_POD = "Pod id is invalid: '&V'. This sheet was created for different pod";
	public static final String SHIFT_ID_INVALID_SHEET_CREATED_FOR_DIFF_SHIFT = "Shift id is invalid: '&V'. This sheet was created for different Shift";
	public static final String SHIFT_DATE_INVALID_SHEET_CREATED_ON_DIFF_DATE = "Shift date is invalid: '&V'. This sheet was created on different Shift date";
	public static final String YOU_CANNOT_MODIFY_THE_SHEET = "You are not authorised to modify this sheet";
	public static final String ONLY_MANAGER_CAN_ALTER_APPROVED_SHEET = "You cannot save an approved sheet. An approved sheet can only be altered by a manager";
	public static final String SHEET_NOT_COMPLETED_BY_OPERATOR_CANNOT_TAKE_ACTION = "You cannot &V the sheet as it is not completed by the operator";
	public static final String SHIFT_OVER_CANNOT_TAKE_ACTION = "You can't &V this sheet as the shift is over";
	public static final String POD_CONFIGURATION_CHANGED_TRY_AGAIN = "The configuration(s) of this POD is updated. Please try again";
	public static final String SAVED_SHEET_PRESENT_SUBMIT_TO_CREATE_NEW = "You have a monitor sheet already saved in this shift. Submit it to create new";
	public static final String ALL_SHEET_NEED_TO_BE_COMPLETED_TO_CREATE_NEW = "All the saved sheets need to completed for this shift to create a new monitor sheet";
	public static final String NO_ACTIVE_ENTITY_ASSOCIATED_WITH_THE_POD = "There is no active &E associated with this Pod";
	public static final String POD_CONFIGURATION_CHANGED_ASK_MANAGER_TO_UPDATE = "Configuration of this pod has been changed. Please ask your manager to update the sheet to proceed further";
	public static final String CANNOT_COMPLETE_APPROVED_SHEET = "An approved sheet can't be completed again";
	public static final String CANNOT_COMPLETE_BEFORE_CURRENT_SHIFT_ENDS = "You can not complete the sheet before the current shift ends";
	public static final String SHEET_ALREADY_APPROVED = "The sheet is already approved";
	public static final String SHEET_NOT_COMPLETED_TO_APPROVE = "Monitor Sheet dated: &V is not completed. Please complete and then approve it";
	public static final String MANAGER_CAN_ONLY_CREATE_CONFIGURATION_SHEET = "Manager is only authorized to configure a monitor sheet";
	public static final String CANNOT_CREATE_ANOTHER_SHEET_IN_SAME_TIME_BRACKET = "There is already a sheet in this Time bracket '&E'";
	public static final String TIME_BRACKET_CHANGED_REFRESH_THE_PAGE = "The Time bracket '&E' has changed. Please refresh the page and try again";
	public static final String CANNOT_CHANGE_TIMEBRACKET_DURATION_OF_POD_USED_IN_MONITOR_SHEET = "Can't change Time bracket for this Pod as it's been used in monitor sheets";
	
	
	/* EMAIL SEND ERRORS */
	public static final String PASSWORD_RESET_EMAIL_SEND_FAILED = "Please contact System Administrator not able to send email for password reset";
	public static final String SUMMARY_APPROVED_REPORT_EMAIL_SEND_FAILED = "Summary approved successfully. Please contact system administrator not able to send email for summary report";
	public static final String SUMMARY_REPORT_EMAIL_SEND_FAILED = "Please contact system administrator not able to send email for summary report";
	public static final String ONLY_MANAGER_CAN_RESEND = "Only a manager can resend email.";
	
	/* ACCOUNT RELATED ERRORS */
	public static final String DELETED_ACCOUNT_CONTACT_MANAGER = "Deleted Account, Please contact Manager";
	public static final String INACTIVE_ACCOUNT_CONTACT_MANAGER = "Inactive Account, Please contact Manager";
	public static final String EMAIL_OR_PASSWORD_INCORRECT = "The email or password you entered is incorrect";
	public static final String OPERATOR_CANT_CREATE_REPORTS = "An operator is not authorized to create reports";
	public static final String NO_DATA_FOR_SELECTED_FILTERS = "No data available for the selected filters. Please try again with new filters";
	public static final String PASSWORD_CANNOT_BE_EMPTY = "Password cannot be empty";
	public static final String OLD_PASSWORD_CANNOT_BE_BLANK = "Old password cannot be blank";
	public static final String NEW_PASSWORD_DOES_NOT_MATCH = "New password does not match";
	public static final String OLD_PASSWORD_DOES_NOT_MATCH = "Old password does not match";
	
	
	/* USER RELATED ERRORS */
	public static final String ONLY_MANAGER_CAN_PERFORM_THIS_ACTION = "This action can only be performed by a Manager";
	public static final String USER_WITH_EMPLOYEE_CODE_DOES_NOT_EXIST = "User with employee code: '&V' does not exist";
	public static final String USER_WITH_ID_DOES_NOT_EXIST = "User with ID: '&V' does not exist";
	public static final String USER_WITH_EMPLOYEE_CODE_ALREADY_EXISTS = "User with employee code: '&V' already exists";
	public static final String USER_WITH_EMAIL_ALREADY_EXISTS = "User with email: '&V' already exists";
	
	
	/* SUMMARY RELATED ERRORS */
	public static final String OPERATOR_CANT_APPROVE_SUMMARY = "Operator can't approve a summary";
	public static final String SUMMARY_APPROVAL_AFTER_SHIFT_ENDS = "Summary can be approved only after the shift ends";
	public static final String SUMMARY_ALREADY_APPROVED= "Summary has already been approved";
	public static final String CANT_PERFORM_ACTION_TRY_LATER= "Action cannot be performed. Please try again";
	public static final String CANT_SUBMIT_APPROVED_SUMMARY= "You can't submit an approved summary";
	public static final String CANT_SUBMIT_SHIFT_OVER= "You can't submit this summary as the shift is over";
	public static final String EITHER_MONITOR_SHEET_OR_SUMMARY_NOT_APPROVED= "Either the monitor sheets or the summary is not approved for this shift";
	
	/* REPORT RELATED ERRORS */
	public static final String IS_AFTER_CURRENT_SHIFT_DATE = "&V is after current shift date.";
}
