package com.monitor.utils;

import com.monitor.exception.ServiceException;

public class Utility {

	public static boolean isIdEmpty(Long id) {
		if (id == null || id == 0) {
			return true;
		}
		return false;
	}

	public static boolean isStringEmpty(String string) {
		if (string == null || string.isEmpty()) {
			return true;
		}
		return false;
	}

	/**
	 * Will validate string length.
	 * 
	 * @param string
	 * @param length
	 * @return
	 * @throws ServiceException
	 */
	public static boolean validateStringLength(String stringToValidate, String entityName, int length)
			throws ServiceException {
		if (stringToValidate == null || stringToValidate.isEmpty())
			return true;
		if (stringToValidate.length() > length)
			throw new ServiceException("Length of " + entityName + " should not exceed " + length);
		// if (!Pattern.compile("[a-zA-z0-9_
		// ]*").matcher(stringToValidate).matches())
		// throw new ServiceException(entityName + " should be alphanumeric with
		// underscores.");

		return true;
	}
}
