package com.monitor.utils;

public class StringUtils {

	public static boolean isEmpty(String string) {
		if (string == null || string.isEmpty()) {
			return true;
		}
		return false;
	}
	
	public static String toStringForList(Long[] x) {
		String str = "";
		if(x == null)
			return str;
		for(Long l : x) {
			if(l == null)
				continue;
			str= str.concat(l.longValue() + ", ");
		}
		return str;
	}
}
