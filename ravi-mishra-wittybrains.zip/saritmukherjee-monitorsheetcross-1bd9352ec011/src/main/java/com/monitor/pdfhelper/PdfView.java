package com.monitor.pdfhelper;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;

/**
 * Created by Rajiv Singh Gahunia on 2017-06-15.
 */
public class PdfView extends AbstractPdfView {
    @Override
    protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer, HttpServletRequest request, HttpServletResponse response) throws Exception {
        // change the file name
        response.setHeader("Content-Disposition", "attachment; filename=\"my-pdf-file.pdf\"");
        //writer.setPageEvent(new GenericPdf.GenericHeaderFooter("", ""));
       PdfGeneratorHelper generatePdf =  new PdfGeneratorHelper();
       generatePdf.generatePdf(model, document);
	}



		
 
    
	

}
