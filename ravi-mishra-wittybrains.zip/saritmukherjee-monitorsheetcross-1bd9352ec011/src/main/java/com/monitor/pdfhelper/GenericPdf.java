package com.monitor.pdfhelper;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

public class GenericPdf {
	public static Float pagePaddingBase = 36f;
	public static Float headerHeight = 70f;
	public static Float footerHeight = 10f;
	public static Float pagePaddingTop = pagePaddingBase + headerHeight + 5;
	public static Float pagePaddingBottom = pagePaddingBase + footerHeight - 5;
	public static Float pagePaddingSide = pagePaddingBase;

	public static class Fonts {
		public static Integer normalSize = 10;
		public static Integer normalLeading = 12;
		public static Integer largeSize = 14;
		public static Integer extraLargeSize = 18;
		public static Integer largeLeading = 16;
		public static Integer smallSize = 8;
		public static Integer smallLeading = 10;

		public static Font normal = FontFactory.getFont("Helvetica", normalSize, Font.NORMAL);
		public static Font normalBold = FontFactory.getFont("Helvetica", normalSize, Font.BOLD);
		public static Font normalItalic = FontFactory.getFont("Helvetica", normalSize, Font.ITALIC);
		public static Font large = FontFactory.getFont("Helvetica", largeSize, Font.NORMAL);
		public static Font largeBold = FontFactory.getFont("Helvetica", largeSize, Font.BOLD);
		public static Font extraLargeBold = FontFactory.getFont("Helvetica", extraLargeSize, Font.BOLD);
		public static Font largeBoldUnderline = FontFactory.getFont("Helvetica", largeSize, Font.UNDERLINE | Font.BOLD);
		public static Font small = FontFactory.getFont("Helvetica", smallSize, Font.NORMAL);
		public static Font smallBold = FontFactory.getFont("Helvetica", smallSize, Font.BOLD);
		public static Font spacer = FontFactory.getFont("Helvetica", normalSize, Font.NORMAL);
		public static Font underline = FontFactory.getFont("Helvetica", normalSize, Font.UNDERLINE);
		public static Font linkSmall = FontFactory.getFont("Helvetica", smallSize, Font.UNDERLINE);
	}

	public static class GenericHeaderFooter extends PdfPageEventHelper {
		PdfContentByte cb;
		PdfTemplate pageCount;
		String title = "";
		String subString = "";
		//String logoPath = "";

		public GenericHeaderFooter(String title, String subString)
		{
			this.title = title;
			this.subString = subString;
		}
	
		public void onCloseDocument(PdfWriter writer, Document document) {
			   ColumnText.showTextAligned(pageCount, Element.ALIGN_LEFT, new Phrase(String.valueOf(writer.getPageNumber() - 1), Fonts.small), 0, 2, 0);
		}
		
		public void onOpenDocument(PdfWriter writer, Document document) {
			cb = writer.getDirectContent();
			pageCount = writer.getDirectContent().createTemplate(30, 10);
		}

//		public void onEndPage(PdfWriter writer, Document document) {
//			Rectangle page = document.getPageSize();
//			
//			//FOOTER
//			try {
//				PdfPTable foot = new PdfPTable(2);
//				foot.setWidths(new int[] { 52, 48 });
//				foot.setTotalWidth(page.getWidth() - (pagePaddingSide * 2));
//				foot.setLockedWidth(true);
//				foot.getDefaultCell().setBorder(Rectangle.TOP);
//				foot.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
//				foot.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
//				foot.getDefaultCell().setFixedHeight(footerHeight);
//				foot.addCell(new Phrase(String.format("page %d of ", writer.getPageNumber()), Fonts.small));
//				//PdfPCell cell = new PdfPCell(Image.getInstance(pageCount));
//			//	cell.setBorder(Rectangle.TOP);
//			//	foot.addCell(cell);
//			//	foot.writeSelectedRows(0, -1, pagePaddingSide, pagePaddingBase + footerHeight, writer.getDirectContent());
//			} catch (DocumentException de) {
//				throw new ExceptionConverter(de);
//			}
//			
//		}

	}

}
