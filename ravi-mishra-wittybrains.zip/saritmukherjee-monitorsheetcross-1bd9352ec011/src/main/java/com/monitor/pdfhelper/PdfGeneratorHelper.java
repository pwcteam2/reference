package com.monitor.pdfhelper;

import java.awt.Color;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.monitor.DTO.CategorySheetDto;
import com.monitor.DTO.ChannelDTO;
import com.monitor.DTO.ChannelWiseTextFieldDto;
import com.monitor.DTO.MonitorSheetDTO;
import com.monitor.DTO.SubCategorySheet;
import com.monitor.domain.Location;
import com.monitor.domain.MonitorSheet;
import com.monitor.domain.MonitorSheetDetail;
import com.monitor.domain.Pod;
import com.monitor.domain.Shift;
import com.monitor.utils.DateUtil;

public class PdfGeneratorHelper {

	@SuppressWarnings("unchecked")
	public void generatePdf(Map<String, Object> model, Document document) throws DocumentException {
		String baseResourcePath = (String) model.get("iconBasePath");

		CImage na = new CImage(baseResourcePath + "/na.png", 2);
		CImage trueIcon = new CImage(baseResourcePath + "/true.png", 2);
		CImage falseIcon = new CImage(baseResourcePath + "/false.png", 2);
		CTable heading = new CTable(100F, 4, new int[] { 1, 1, 1, 1 });
		heading.AddCell(new CParaPart("Monitor Report", GenericPdf.Fonts.extraLargeBold,
				GenericPdf.Fonts.extraLargeSize, Element.ALIGN_CENTER, 0), new Color(255, 255, 255), 4, true);
		document.add(heading.GetTable());

		List<Pod> podList = (List<Pod>) model.get("podList");
		List<Shift> shiftList = (List<Shift>) model.get("shiftList");
		
		// Start Calculation
		Map<Location, Map<MonitorSheetDTO, List<ChannelDTO>>> map = (Map<Location, Map<MonitorSheetDTO, List<ChannelDTO>>>) model.get("monitorSheetList");

				for (Map.Entry<Location, Map<MonitorSheetDTO, List<ChannelDTO>>> entry : map.entrySet()) {
					String s = "Loc: " + entry.getKey().getLocationName() + ", Size: " + entry.getValue().size();
					System.out.println(s);

					for (Map.Entry<MonitorSheetDTO, List<ChannelDTO>> monitorSheetMap : entry.getValue().entrySet()) {
						document.add(CParagraph.SpacerParagraph());
						
//						This table will be used to show the locations.
						CTable locationHeader = new CTable(100F, 2, new int[] { 1, 1});
						locationHeader.AddCell(
								new CParaPart("Location: " + entry.getKey().getLocationName(), GenericPdf.Fonts.normalBold,
										GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0),
								new Color(255, 255, 255), 2, true);
						document.add(locationHeader.GetTable());
						
						document.add(CParagraph.SpacerParagraph());
						
//						This table will be used to show the attributes like pod,date etc..
						CTable monitorAttr = new CTable(100F, 16, new int[] { 1, 1, 1, 1, 1 , 1, 1, 1, 1, 1, 1, 1, 1 , 1, 1, 1});
						monitorAttr.AddCell(
								new CParaPart("Pod: " + podList.stream().filter(p -> p.getPodId() == monitorSheetMap.getKey().getPodId()).collect(Collectors.toList()).get(0).getPodName(), GenericPdf.Fonts.normalBold,
										GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0),
								new Color(255, 255, 255), 4, true);

						monitorAttr.AddCell(
								new CParaPart(
										"Date: " + DateUtil
												.getDateWithMonthInString(monitorSheetMap.getKey().getShiftDate().toString("dd-MM-yyyy")),
										GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0),
								new Color(255, 255, 255), 3, true);
						
						monitorAttr.AddCell(
								new CParaPart(
										"Time: " + monitorSheetMap.getKey().getEndTime(),
										GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0),
								new Color(255, 255, 255), 3, true);
						
						monitorAttr.AddCell(
								new CParaPart(
										"Shift: " + shiftList.stream().filter(sh -> sh.getShiftId() == monitorSheetMap.getKey().getShiftId()).collect(Collectors.toList()).get(0).getName(),
										GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_RIGHT, 0),
								new Color(255, 255, 255), 2, true);
						
						monitorAttr.AddCell(
								new CParaPart(
										"Checked By: " + monitorSheetMap.getKey().getApproverName(),
										GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_RIGHT, 0),
								new Color(255, 255, 255), 4, true);
						document.add(monitorAttr.GetTable());
						
						
//						This table will be used to show the channels.
//						CTable channelTable = new CTable(100F, 20,  new int[] { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1});
//						channelTable.AddCell(
//								new CParaPart(
//										"Channel",
//										GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0),
//								new Color(255, 255, 255), 1, false);
						
						int columns = monitorSheetMap.getValue().size() + 2;
						int[] columnWidths = new int[columns];
						for(int i = 0; i < columns ; i++)
							columnWidths[i] = 1;
						CTable channels = new CTable(100F, columns, columnWidths);
						
						channels.AddCell(
								new CParaPart(
										"Channel",
										GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
								new Color(255, 255, 255), 2, false);
						
						for(ChannelDTO channelDTO : monitorSheetMap.getValue()) {
							channels.AddCell(
									new CParaPart(
											channelDTO.getChannelName(),
											GenericPdf.Fonts.smallBold, GenericPdf.Fonts.smallLeading, Element.ALIGN_CENTER, 0),
									new Color(255, 255, 255), 1, false);
						}
						document.add(channels.GetTable());
						
						CTable nocs = new CTable(100F, columns, columnWidths);
						
						nocs.AddCell(
								new CParaPart(
										"NOC",
										GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
								new Color(255, 255, 255), 2, false);
						
						for(ChannelDTO channelDTO : monitorSheetMap.getValue()) {
							nocs.AddCell(
									new CParaPart(
											channelDTO.getNocNumber() != null ? channelDTO.getNocNumber() : "",
											GenericPdf.Fonts.smallBold, GenericPdf.Fonts.smallLeading, Element.ALIGN_CENTER, 0),
									new Color(255, 255, 255), 1, false);
						}
						document.add(nocs.GetTable());
						
						for(CategorySheetDto categorySheetDto : monitorSheetMap.getKey().getCategorySheetList()) {
							CTable categoryTable = new CTable(100F, 1, new int[] { 1});
							
							categoryTable.AddCell(
									new CParaPart(
											categorySheetDto.getCategoryName(),
											GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
									new Color(255, 255, 255), 1, false);
							document.add(categoryTable.GetTable());
							
							for(SubCategorySheet subCategorySheet : categorySheetDto.getSubCategorySheetList()) {
								CTable subCategories = new CTable(100F, columns, columnWidths);
								
								subCategories.AddCell(
										new CParaPart(
												subCategorySheet.getSubCategoryName(),
												GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
										new Color(255, 255, 255), 2, false);
								
								for(ChannelWiseTextFieldDto channelWiseTextFieldDto : subCategorySheet.getChannelWiseTextFieldList()) {
									Color c = new Color(0);
									Random r = new Random();
									switch (Math.abs(r.nextInt() % 3)) {
									case 0:
										c = c.DARK_GRAY;
										break;
									case 1:
										c = c.LIGHT_GRAY;
										break;
									case 2:
										c = c.GRAY;
										break;

									default:
										c = c.WHITE;
										break;
									}
									subCategories.AddCell(
											new CParaPart(
													channelWiseTextFieldDto.getTextFieldValue() != null ? channelWiseTextFieldDto.getTextFieldValue() : "",
													GenericPdf.Fonts.smallBold, GenericPdf.Fonts.smallLeading, Element.ALIGN_CENTER, 0),
											c, 1, false);
								}
								document.add(subCategories.GetTable());
							}
						}
						
						CTable operator = new CTable(100F, 2, new int[] { 1, 1 });
//						operator.AddCell(new CParaPart(
//								"Operator Name: ",
//								GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0), 1,
//								true);
						operator.AddCell(new CParaPart(
								"Operator Name: \t" + monitorSheetMap.getKey().getOperatorName(),
								GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0), 1,
								true);
//						operator.AddCell(new CParaPart(
//								"Operator Remarks: ",
//								GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0), 1,
//								true);
						operator.AddCell(new CParaPart(
								"Operator Remarks: \t" + monitorSheetMap.getKey().getOperatorRemarks(),
								GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_RIGHT, 0), 1,
								true);
						
						document.add(operator.GetTable());
						
						CTable approver = new CTable(100F, 1, new int[] { 1 });
						String r = monitorSheetMap.getKey().getApproverRemarks() == null? "" : monitorSheetMap.getKey().getApproverRemarks();
						approver.AddCell(new CParaPart(
								"Approver Remarks: \t" + r,
								GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0), 1,
								true);
						document.add(approver.GetTable());
						
						CTable dateBreak = new CTable(100F, 1, new int[] { 1 });
						dateBreak.AddCell(new CParaPart(
								"------------------------------------------------------------------------------------",
								GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0), 2,
								true);
						document.add(dateBreak.GetTable());
						
						document.add(CParagraph.SpacerParagraph());
						document.add(CParagraph.SpacerParagraph());
					}
				}
//				
//				document.add(CParagraph.SpacerParagraph());
//				CTable ct = new CTable(100F, 8, new int[] { 1,1,1,1,1,1,1,1 });
//				
//				ct.AddCell(new CParaPart("Location: ", GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0), 4, true);
//				ct.AddCell(new CParaPart("Location2: ", GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0), 4, true);
//				document.add(ct.GetTable());
//				
//				document.add(CParagraph.SpacerParagraph());
//				//
//							CTable dateField = new CTable(100F, 2, new int[] { 1, 1 });
//							dateField.AddCell(new CParaPart(
//									"Date : ",
//									GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0), 2,
//									true);
//							document.add(dateField.GetTable());
				
//		@SuppressWarnings("unchecked")
//		List<MonitorSheetOldDTO> monitorSheetListDto = (List<MonitorSheetOldDTO>) model.get("monitorSheetList");
//		Map<String, List<MonitorSheetOldDTO>> monitorSheetPodMap = new HashMap<String, List<MonitorSheetOldDTO>>();
//		Map<String, List<MonitorSheetOldDTO>> monitorSheetLocationMap = new HashMap<String, List<MonitorSheetOldDTO>>();
//
//		Map<DateTime, List<MonitorSheetOldDTO>> monitorSheetDtoMap = monitorSheetListDto.stream()
//				.collect(Collectors.groupingBy(MonitorSheetOldDTO::getShiftDate));
//
//		LinkedHashMap<DateTime, List<MonitorSheetOldDTO>> sortedDate = monitorSheetDtoMap.entrySet().stream()
//				.sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
//						(oldValue, newValue) -> oldValue, LinkedHashMap::new));
//
//		for (DateTime modifiedDate : sortedDate.keySet()) {
//			// groupingLocation wise
//			List<MonitorSheetOldDTO> monitorSheetDtoList = monitorSheetDtoMap.get(modifiedDate);
//			monitorSheetLocationMap = monitorSheetDtoList.stream()
//					.collect(Collectors.groupingBy(MonitorSheetOldDTO::getLocationName));
//			LinkedHashMap<String, List<MonitorSheetOldDTO>> sortedLocation = monitorSheetLocationMap.entrySet().stream()
//					.sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
//							(oldValue, newValue) -> oldValue, LinkedHashMap::new));
//			
//			document.add(CParagraph.SpacerParagraph());
//
//			CTable dateField = new CTable(100F, 2, new int[] { 1, 1 });
//			dateField.AddCell(new CParaPart(
//					"Date : " + DateUtil.getDateWithMonthInString(
//							com.monitor.framework.DateUtil.removeTime(modifiedDate, "dd-MM-yyyy")),
//					GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0), 2,
//					true);
//			document.add(dateField.GetTable());
//
//
//			for (String locationName : sortedLocation.keySet()) {
//
//				// grouping pod wise
//				List<MonitorSheetOldDTO> monitorSheetLocationList = monitorSheetLocationMap.get(locationName);
//				monitorSheetPodMap = monitorSheetLocationList.stream()
//						.collect(Collectors.groupingBy(MonitorSheetOldDTO::getPodName));
//				LinkedHashMap<String, List<MonitorSheetOldDTO>> sortedPod = monitorSheetPodMap.entrySet().stream()
//						.sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey,
//								Map.Entry::getValue, (oldValue, newValue) -> oldValue, LinkedHashMap::new));
//
//				for (String podName : sortedPod.keySet()) {
//					List<MonitorSheetOldDTO> monitorSheetPodList = monitorSheetPodMap.get(podName);
//
//					// grouping channel wise
//					Map<String, List<MonitorSheetOldDTO>> monitorSheetChannelMap = monitorSheetPodList.stream()
//							.collect(Collectors.groupingBy(MonitorSheetOldDTO::getChannelName));
//					LinkedHashMap<String, List<MonitorSheetOldDTO>> sortedChannel = monitorSheetChannelMap.entrySet()
//							.stream().sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey,
//									Map.Entry::getValue, (oldValue, newValue) -> oldValue, LinkedHashMap::new));
//
//				
//					for (String channelName : sortedChannel.keySet()) {
//						List<MonitorSheetOldDTO> monitorSheetChannelList = monitorSheetChannelMap.get(channelName);
//						// grouping shift wise
//						Map<String, List<MonitorSheetOldDTO>> monitorSheetShiftMap = monitorSheetChannelList.stream()
//								.collect(Collectors.groupingBy(MonitorSheetOldDTO::getShiftName));
//						LinkedHashMap<String, List<MonitorSheetOldDTO>> sortedShift = monitorSheetShiftMap.entrySet()
//								.stream().sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey,
//										Map.Entry::getValue, (oldValue, newValue) -> oldValue, LinkedHashMap::new));
//						String supervisorRemark = "";
//
//						for (String shift : sortedShift.keySet()) {
//							List<MonitorSheetOldDTO> finalList = monitorSheetShiftMap.get(shift);
//							finalList.sort((MonitorSheetOldDTO m1, MonitorSheetOldDTO m2) -> m1.getCreatedDate()
//									.compareTo(m2.getCreatedDate()));
//							document.add(CParagraph.SpacerParagraph());
//
//							CTable monitorConfig = new CTable(100F, 8, new int[] { 1,1,1,1,1,1,1,1 });
//							monitorConfig.AddCell(new CParaPart("Location: " + locationName,
//									GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0),
//									2, true);
//							monitorConfig.AddCell(new CParaPart("Pod: " + podName, GenericPdf.Fonts.normalBold,
//									GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0), 2, true);
//							monitorConfig.AddCell(new CParaPart("Channel: " + channelName, GenericPdf.Fonts.normalBold,
//									GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0), 2, true);
//							monitorConfig.AddCell(new CParaPart("Shift: " + shift, GenericPdf.Fonts.normalBold,
//									GenericPdf.Fonts.normalLeading, Element.ALIGN_RIGHT, 0), 2, true);
//
//							document.add(monitorConfig.GetTable());
//							CTable monitorTableDayWise = new CTable(100F, 9, new int[] { 1, 1, 1, 1, 1, 1, 1, 1, 2 });
//							monitorTableDayWise
//									.AddCell(
//											new CParaPart("S No", GenericPdf.Fonts.normalBold,
//													GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
//											new Color(255, 255, 255), 1, false);
//							monitorTableDayWise
//									.AddCell(
//											new CParaPart("Time", GenericPdf.Fonts.normalBold,
//													GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
//											new Color(255, 255, 255), 1, false);
//							monitorTableDayWise.AddCell(
//									new CParaPart("Program", GenericPdf.Fonts.normalBold,
//											GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
//									new Color(255, 255, 255), 1, false);
//							monitorTableDayWise
//									.AddCell(
//											new CParaPart("Audio", GenericPdf.Fonts.normalBold,
//													GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
//											new Color(255, 255, 255), 1, false);
//							monitorTableDayWise
//									.AddCell(
//											new CParaPart("Bug", GenericPdf.Fonts.normalBold,
//													GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
//											new Color(255, 255, 255), 1, false);
//							monitorTableDayWise.AddCell(
//									new CParaPart("Subtitle", GenericPdf.Fonts.normalBold,
//											GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
//									new Color(255, 255, 255), 1, false);
//							monitorTableDayWise
//									.AddCell(
//											new CParaPart("U/O", GenericPdf.Fonts.normalBold,
//													GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
//											new Color(255, 255, 255), 1, false);
//							monitorTableDayWise.AddCell(
//									new CParaPart("Operator", GenericPdf.Fonts.normalBold,
//											GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
//									new Color(255, 255, 255), 1, false);
//							monitorTableDayWise.AddCell(
//									new CParaPart("Remarks", GenericPdf.Fonts.normalBold,
//											GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
//									new Color(255, 255, 255), 1, false);
//
//							int sno = 0;
//							for (MonitorSheetOldDTO sheet : finalList) {
//								++sno;
//								supervisorRemark = sheet.getSupervisorRemark();
//
//								String formattedDate = new SimpleDateFormat("HH:mm:ss")
//										.format(sheet.getCreatedDate().toDate());
//								monitorTableDayWise.AddCell(
//										new CParaPart(sno + "", GenericPdf.Fonts.normalBold,
//												GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
//										new Color(255, 255, 255), 1, false);
//								monitorTableDayWise.AddCell(
//										new CParaPart(formattedDate, GenericPdf.Fonts.normalBold,
//												GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
//										new Color(255, 255, 255), 1, false);
//								monitorTableDayWise.AddCell(getImage(sheet.getProgram(), na, trueIcon, falseIcon), 1,
//										false);
//								monitorTableDayWise.AddCell(getImage(sheet.getAudio(), na, trueIcon, falseIcon), 1,
//										false);
//								monitorTableDayWise.AddCell(getImage(sheet.getBug(), na, trueIcon, falseIcon), 1,
//										false);
//								monitorTableDayWise.AddCell(getImage(sheet.getSubtitle(), na, trueIcon, falseIcon), 1,
//										false);
//								monitorTableDayWise.AddCell(getImage(sheet.getUno(), na, trueIcon, falseIcon), 1,
//										false);
//								monitorTableDayWise.AddCell(
//										new CParaPart(sheet.getOperatorName(), GenericPdf.Fonts.normalBold,
//												GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
//										new Color(255, 255, 255), 1, false);
//								monitorTableDayWise.AddCell(
//										new CParaPart(sheet.getRemark(), GenericPdf.Fonts.normalBold,
//												GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0),
//										new Color(255, 255, 255), 1, false);
//							}
//							document.add(monitorTableDayWise.GetTable());
//						}
//
//						CTable remark = new CTable(100F, 1, new int[] { 1 });
//						remark.AddCell(new CParaPart("Supervisor remark: " + supervisorRemark,
//								GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_LEFT, 0), 2,
//								true);
//						document.add(remark.GetTable());
//					}
//
//					CTable dateBreak = new CTable(100F, 1, new int[] { 1 });
//					dateBreak.AddCell(new CParaPart(
//							"------------------------------------------------------------------------------------ ",
//							GenericPdf.Fonts.normalBold, GenericPdf.Fonts.normalLeading, Element.ALIGN_CENTER, 0), 2,
//							true);
//					document.add(dateBreak.GetTable());
//				}

//			}
	//	}
	}

	private CImage getImage(Boolean boolValue, CImage na, CImage trueIcon, CImage falseIcon) {
		if (boolValue == null) {
			return na;
		}

		if (boolValue) {
			return trueIcon;
		}

		return falseIcon;
	}
}
