package com.monitor.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.monitor.enums.Status;

@Entity
@EntityListeners(AuditingEntityListener.class)
public class MonitorSheet {
	@Id
	@GeneratedValue
	private Long monitorId;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "pod_id", nullable = false, updatable = false)
	private Pod pod;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "shift_id", nullable = false, updatable = false)
	private Shift shift;

	@NotNull
	private DateTime shiftDate;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "operator_id", nullable = false)
	private User createdBy;

	private String operatorRemarks;

	@Enumerated(EnumType.STRING)
	private Status status;

	private boolean deleted = false;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "sheet_approval_id", nullable = true)
	private SheetApprovalDetail sheetApprovalDetail;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "monitor_id", nullable = false, updatable = false)
	private List<MonitorSheetDetail> monitorSheetDetails;

	@NotNull
	@LastModifiedDate
	private DateTime modifiedDate;

	@NotNull
	@CreatedDate
	private DateTime createdDate;
	
	private DateTime completeDate;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "completer", nullable = false)
	private User completer;
	
	private Long configurationVersion;
	
	private Integer timeBracketInMinutes;
	
	private Long timeBracketId;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "monitorSheet")
	private List<MonitorSheetHistory> monitorSheetHistories;

	public MonitorSheet() {
	}

	/**
	 * @return the monitorId
	 */
	public Long getMonitorId() {
		return monitorId;
	}

	/**
	 * @param monitorId the monitorId to set
	 */
	public void setMonitorId(Long monitorId) {
		this.monitorId = monitorId;
	}

	/**
	 * @return the pod
	 */
	public Pod getPod() {
		return pod;
	}

	/**
	 * @param pod the pod to set
	 */
	public void setPod(Pod pod) {
		this.pod = pod;
	}

	/**
	 * @return the shift
	 */
	public Shift getShift() {
		return shift;
	}

	/**
	 * @param shift the shift to set
	 */
	public void setShift(Shift shift) {
		this.shift = shift;
	}

	/**
	 * @return the shiftDate
	 */
	public DateTime getShiftDate() {
		return shiftDate;
	}

	/**
	 * @param shiftDate the shiftDate to set
	 */
	public void setShiftDate(DateTime shiftDate) {
		this.shiftDate = shiftDate;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the operatorRemarks
	 */
	public String getOperatorRemarks() {
		return operatorRemarks;
	}

	/**
	 * @param operatorRemarks the operatorRemarks to set
	 */
	public void setOperatorRemarks(String operatorRemarks) {
		this.operatorRemarks = operatorRemarks;
	}

	/**
	 * @return the status
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Status status) {
		this.status = status;
	}

	/**
	 * @return the deleted
	 */
	public boolean isDeleted() {
		return deleted;
	}

	/**
	 * @param deleted the deleted to set
	 */
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	/**
	 * @return the sheetApprovalDetail
	 */
	public SheetApprovalDetail getSheetApprovalDetail() {
		return sheetApprovalDetail;
	}

	/**
	 * @param sheetApprovalDetail the sheetApprovalDetail to set
	 */
	public void setSheetApprovalDetail(SheetApprovalDetail sheetApprovalDetail) {
		this.sheetApprovalDetail = sheetApprovalDetail;
	}

	/**
	 * @return the monitorSheetDetails
	 */
	public List<MonitorSheetDetail> getMonitorSheetDetails() {
		return monitorSheetDetails;
	}

	/**
	 * @param monitorSheetDetails the monitorSheetDetails to set
	 */
	public void setMonitorSheetDetails(List<MonitorSheetDetail> monitorSheetDetails) {
		this.monitorSheetDetails = monitorSheetDetails;
	}

	/**
	 * @return the modifiedDate
	 */
	public DateTime getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return the createdDate
	 */
	public DateTime getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the completeDate
	 */
	public DateTime getCompleteDate() {
		return completeDate;
	}

	/**
	 * @param completeDate the completeDate to set
	 */
	public void setCompleteDate(DateTime completeDate) {
		this.completeDate = completeDate;
	}

	/**
	 * @return the completer
	 */
	public User getCompleter() {
		return completer;
	}

	/**
	 * @param completer the completer to set
	 */
	public void setCompleter(User completer) {
		this.completer = completer;
	}

	/**
	 * @return the configurationVersion
	 */
	public Long getConfigurationVersion() {
		return configurationVersion;
	}

	/**
	 * @param configurationVersion the configurationVersion to set
	 */
	public void setConfigurationVersion(Long configurationVersion) {
		this.configurationVersion = configurationVersion;
	}

	/**
	 * @return the monitorSheetHistories
	 */
	public List<MonitorSheetHistory> getMonitorSheetHistories() {
		return monitorSheetHistories;
	}

	/**
	 * @param monitorSheetHistories the monitorSheetHistories to set
	 */
	public void setMonitorSheetHistories(List<MonitorSheetHistory> monitorSheetHistories) {
		this.monitorSheetHistories = monitorSheetHistories;
	}

	/**
	 * @return the timeBracketInMinutes
	 */
	public Integer getTimeBracketInMinutes() {
		return timeBracketInMinutes;
	}

	/**
	 * @param timeBracketInMinutes the timeBracketInMinutes to set
	 */
	public void setTimeBracketInMinutes(Integer timeBracketInMinutes) {
		this.timeBracketInMinutes = timeBracketInMinutes;
	}

	/**
	 * @return the timeBracketId
	 */
	public Long getTimeBracketId() {
		return timeBracketId;
	}

	/**
	 * @param timeBracketId the timeBracketId to set
	 */
	public void setTimeBracketId(Long timeBracketId) {
		this.timeBracketId = timeBracketId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MonitorSheet [monitorId=" + monitorId + ", pod=" + pod + ", shift=" + shift + ", shiftDate=" + shiftDate
				+ ", createdBy=" + createdBy + ", operatorRemarks=" + operatorRemarks + ", status=" + status
				+ ", deleted=" + deleted + ", sheetApprovalDetail=" + sheetApprovalDetail + ", monitorSheetDetails="
				+ monitorSheetDetails + ", modifiedDate=" + modifiedDate + ", createdDate=" + createdDate
				+ ", completeDate=" + completeDate + ", completer=" + completer + ", configurationVersion="
				+ configurationVersion + ", timeBracketInMinutes=" + timeBracketInMinutes + ", timeBracketId="
				+ timeBracketId + ", monitorSheetHistories=" + monitorSheetHistories + "]";
	}
}