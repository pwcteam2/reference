package com.monitor.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.monitor.enums.PodAction;

@Entity
@EntityListeners(AuditingEntityListener.class)
public class PodHistory {
	@Id
	@GeneratedValue
	private Long podHistoryId;

	private String podName;

	private Boolean disabled;

	private Long configurationVersion = 0l;

	private Integer timeBracketInMinutes;

	@NotNull
	@CreatedDate
	private DateTime createdDate;

	@Enumerated(EnumType.STRING)
	private PodAction podAction;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "modifier", nullable = false)
	private User modifier;

	@ManyToOne(fetch = FetchType.LAZY)
	private Pod pod;

	public Long getPodHistoryId() {
		return podHistoryId;
	}

	public void setPodHistoryId(Long podHistoryId) {
		this.podHistoryId = podHistoryId;
	}

	public String getPodName() {
		return podName;
	}

	public void setPodName(String podName) {
		this.podName = podName;
	}

	public Boolean getDisabled() {
		return disabled;
	}

	public void setDisabled(Boolean disabled) {
		this.disabled = disabled;
	}

	public Long getConfigurationVersion() {
		return configurationVersion;
	}

	public void setConfigurationVersion(Long configurationVersion) {
		this.configurationVersion = configurationVersion;
	}

	public Integer getTimeBracketInMinutes() {
		return timeBracketInMinutes;
	}

	public void setTimeBracketInMinutes(Integer timeBracketInMinutes) {
		this.timeBracketInMinutes = timeBracketInMinutes;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	public PodAction getPodAction() {
		return podAction;
	}

	public void setPodAction(PodAction podAction) {
		this.podAction = podAction;
	}

	public User getModifier() {
		return modifier;
	}

	public void setModifier(User modifier) {
		this.modifier = modifier;
	}

	public Pod getPod() {
		return pod;
	}

	public void setPod(Pod pod) {
		this.pod = pod;
	}

	@Override
	public String toString() {
		return "PodHistory [podHistoryId=" + podHistoryId + ", podName=" + podName + ", disabled=" + disabled
				+ ", configurationVersion=" + configurationVersion + ", timeBracketInMinutes=" + timeBracketInMinutes
				+ ", createdDate=" + createdDate + ", podAction=" + podAction + ", modifier=" + modifier + ", pod="
				+ pod + "]";
	}
}
