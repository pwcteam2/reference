package com.monitor.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class MonitorSheetDetailHistory {

	@Id
	@GeneratedValue
	private Long monitorSheetDetailHistoryId;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(nullable = false, updatable = false)
	private Channel channel;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "monitor_sheet_detail_history_id", nullable = true, updatable = true)
	private List<TextFieldHistory> textFieldHistories;

	/**
	 * @return the monitorSheetDetailHistoryId
	 */
	public Long getMonitorSheetDetailHistoryId() {
		return monitorSheetDetailHistoryId;
	}

	/**
	 * @param monitorSheetDetailHistoryId the monitorSheetDetailHistoryId to set
	 */
	public void setMonitorSheetDetailHistoryId(Long monitorSheetDetailHistoryId) {
		this.monitorSheetDetailHistoryId = monitorSheetDetailHistoryId;
	}

	/**
	 * @return the channel
	 */
	public Channel getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(Channel channel) {
		this.channel = channel;
	}

	/**
	 * @return the textFieldHistories
	 */
	public List<TextFieldHistory> getTextFieldHistories() {
		return textFieldHistories;
	}

	/**
	 * @param textFieldHistories the textFieldHistories to set
	 */
	public void setTextFieldHistories(List<TextFieldHistory> textFieldHistories) {
		this.textFieldHistories = textFieldHistories;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MonitorSheetDetailHistory [monitorSheetDetailHistoryId=" + monitorSheetDetailHistoryId + ", channel="
				+ channel + ", textFieldHistories=" + textFieldHistories + "]";
	}
}
