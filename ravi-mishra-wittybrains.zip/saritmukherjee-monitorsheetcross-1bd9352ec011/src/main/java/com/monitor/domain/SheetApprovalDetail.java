package com.monitor.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
public class SheetApprovalDetail {

	@Id
	@GeneratedValue
	private Long sheetApprovalId;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "approved_by", nullable = true)
	private User approver;

	private String approverRemarks;

	@NotNull
	@CreatedDate
	private DateTime createdDate;

	@NotNull
	@LastModifiedDate
	private DateTime modifiedDate;

	private DateTime approvedDate;

	public SheetApprovalDetail() {
	}

	public Long getSheetApprovalId() {
		return sheetApprovalId;
	}

	public void setSheetApprovalId(Long sheetApprovalId) {
		this.sheetApprovalId = sheetApprovalId;
	}

	public User getApprover() {
		return approver;
	}

	public void setApprover(User approver) {
		this.approver = approver;
	}

	public String getApproverRemarks() {
		return approverRemarks;
	}

	public void setApproverRemarks(String approverRemarks) {
		this.approverRemarks = approverRemarks;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	public DateTime getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public DateTime getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(DateTime approvedDate) {
		this.approvedDate = approvedDate;
	}

	@Override
	public String toString() {
		return "SheetApprovalDetail [sheetApprovalId=" + sheetApprovalId + ", approver=" + approver
				+ ", approverRemarks=" + approverRemarks + ", createdDate=" + createdDate + ", modifiedDate="
				+ modifiedDate + ", approvedDate=" + approvedDate + "]";
	}
}
