package com.monitor.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class TimeBracketDuration {

	@Id
	@GeneratedValue
	private Long timeBracketDurationId;

	@NotNull
	private Integer duration;

	public Long getTimeBracketDurationId() {
		return timeBracketDurationId;
	}

	public void setTimeBracketDurationId(Long timeBracketDurationId) {
		this.timeBracketDurationId = timeBracketDurationId;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	@Override
	public String toString() {
		return "TimeBracketDuration [timeBracketDurationId=" + timeBracketDurationId + ", duration=" + duration + "]";
	}
}
