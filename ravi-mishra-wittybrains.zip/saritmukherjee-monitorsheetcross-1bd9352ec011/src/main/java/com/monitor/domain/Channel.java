package com.monitor.domain;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.joda.time.DateTime;

@Entity
@Table(name = "channel")
public class Channel {
	@Id
	@GeneratedValue
	private Long channelId;
	@NotNull
	private String channelName;

	private DateTime createdDate;

	private DateTime modifiedDate;

	private String nocNumber;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "added_by", nullable = false, insertable = false, updatable = false)
	private User addedBy;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "pod_id", nullable = false, insertable = false, updatable = false)
	private Pod pod;

	private boolean disabled;

	public Long getChannelId() {
		return channelId;
	}

	public void setChannelId(Long channelId) {
		this.channelId = channelId;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	public DateTime getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getNocNumber() {
		return nocNumber;
	}

	public void setNocNumber(String nocNumber) {
		this.nocNumber = nocNumber;
	}

	public User getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(User addedBy) {
		this.addedBy = addedBy;
	}

	public Pod getPod() {
		return pod;
	}

	public void setPod(Pod pod) {
		this.pod = pod;
	}

	public boolean isDisabled() {
		return disabled;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

}
