package com.monitor.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * For storing data of monitor sheet columnwise.
 * 
 * @author Wittybrains
 *
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
public class MonitorSheetDetail {

	@Id
	@GeneratedValue
	private Long monitorSheetDetailId;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(nullable = false, updatable = false)
	private Channel channel;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "monitor_sheet_detail_id", nullable = true, updatable = true)
	private List<TextField> textFields;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "monitor_sheet_detail_id", nullable = true, updatable = true)
	private List<CategoryWiseField> categoryWiseFieldList;

	@NotNull
	@LastModifiedDate
	private DateTime modifiedDate;

	@NotNull
	@CreatedDate
	private DateTime createdDate;

	public MonitorSheetDetail() {
	}

	/**
	 * @return the monitorSheetDetailId
	 */
	public Long getMonitorSheetDetailId() {
		return monitorSheetDetailId;
	}

	/**
	 * @param monitorSheetDetailId the monitorSheetDetailId to set
	 */
	public void setMonitorSheetDetailId(Long monitorSheetDetailId) {
		this.monitorSheetDetailId = monitorSheetDetailId;
	}

	/**
	 * @return the channel
	 */
	public Channel getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(Channel channel) {
		this.channel = channel;
	}

	/**
	 * @return the textFields
	 */
	public List<TextField> getTextFields() {
		return textFields;
	}

	/**
	 * @param textFields the textFields to set
	 */
	public void setTextFields(List<TextField> textFields) {
		this.textFields = textFields;
	}

	/**
	 * @return the categoryWiseFieldList
	 */
	public List<CategoryWiseField> getCategoryWiseFieldList() {
		return categoryWiseFieldList;
	}

	/**
	 * @param categoryWiseFieldList the categoryWiseFieldList to set
	 */
	public void setCategoryWiseFieldList(List<CategoryWiseField> categoryWiseFieldList) {
		this.categoryWiseFieldList = categoryWiseFieldList;
	}

	/**
	 * @return the modifiedDate
	 */
	public DateTime getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return the createdDate
	 */
	public DateTime getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MonitorSheetDetail [monitorSheetDetailId=" + monitorSheetDetailId + ", channel=" + channel
				+ ", textFields=" + textFields + ", categoryWiseFieldList=" + categoryWiseFieldList + ", modifiedDate="
				+ modifiedDate + ", createdDate=" + createdDate + "]";
	}

}
