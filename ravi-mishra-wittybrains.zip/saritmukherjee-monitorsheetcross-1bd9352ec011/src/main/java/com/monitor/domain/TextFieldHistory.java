package com.monitor.domain;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

@Entity
public class TextFieldHistory {

	@Id
	@GeneratedValue
	private Long textFieldHistoryId;
	
	private String textFieldHistoryValue;

	@NotNull
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(nullable = false, updatable = false)
	private SubCategory subCategory;
	
	private Boolean selection;

	/**
	 * @return the textFieldHistoryId
	 */
	public Long getTextFieldHistoryId() {
		return textFieldHistoryId;
	}

	/**
	 * @param textFieldHistoryId the textFieldHistoryId to set
	 */
	public void setTextFieldHistoryId(Long textFieldHistoryId) {
		this.textFieldHistoryId = textFieldHistoryId;
	}

	/**
	 * @return the textFieldHistoryValue
	 */
	public String getTextFieldHistoryValue() {
		return textFieldHistoryValue;
	}

	/**
	 * @param textFieldHistoryValue the textFieldHistoryValue to set
	 */
	public void setTextFieldHistoryValue(String textFieldHistoryValue) {
		this.textFieldHistoryValue = textFieldHistoryValue;
	}

	/**
	 * @return the subCategory
	 */
	public SubCategory getSubCategory() {
		return subCategory;
	}

	/**
	 * @param subCategory the subCategory to set
	 */
	public void setSubCategory(SubCategory subCategory) {
		this.subCategory = subCategory;
	}

	/**
	 * @return the selection
	 */
	public Boolean getSelection() {
		return selection;
	}

	/**
	 * @param selection the selection to set
	 */
	public void setSelection(Boolean selection) {
		this.selection = selection;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TextFieldHistory [textFieldHistoryId=" + textFieldHistoryId + ", textFieldHistoryValue="
				+ textFieldHistoryValue + ", subCategory=" + subCategory + ", selection=" + selection + "]";
	}
	
}
