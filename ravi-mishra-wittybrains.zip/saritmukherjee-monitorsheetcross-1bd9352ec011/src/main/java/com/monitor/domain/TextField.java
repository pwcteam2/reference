/**
 * 
 */
package com.monitor.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * This entity is used to store each field(String) in the sheet.
 * @author Wittybrains
 *
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
public class TextField {
	
	@Id
	@GeneratedValue
	private Long textFieldId;
	
	private String textFieldValue;

	@NotNull
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(nullable = false, updatable = false)
	private SubCategory subCategory;
	
	@NotNull
	@CreatedDate
	private DateTime createdDate;
	
	@NotNull
	@LastModifiedDate
	private DateTime modifiedDate;
	
	private Boolean selection;
	
	public TextField() {
	}

	public TextField(Long textFieldId, String textFieldValue, SubCategory subCategory) {
		this.textFieldId = textFieldId;
		this.textFieldValue = textFieldValue;
		this.subCategory = subCategory;
	}

	public TextField(SubCategory subCategory) {
		this.subCategory = subCategory;
	}

	/**
	 * @return the textFieldId
	 */
	public Long getTextFieldId() {
		return textFieldId;
	}

	/**
	 * @param textFieldId the textFieldId to set
	 */
	public void setTextFieldId(Long textFieldId) {
		this.textFieldId = textFieldId;
	}

	/**
	 * @return the textFieldValue
	 */
	public String getTextFieldValue() {
		return textFieldValue;
	}

	/**
	 * @param textFieldValue the textFieldValue to set
	 */
	public void setTextFieldValue(String textFieldValue) {
		this.textFieldValue = textFieldValue;
	}

	/**
	 * @return the subCategory
	 */
	public SubCategory getSubCategory() {
		return subCategory;
	}

	/**
	 * @param subCategory the subCategory to set
	 */
	public void setSubCategory(SubCategory subCategory) {
		this.subCategory = subCategory;
	}

	/**
	 * @return the createdDate
	 */
	public DateTime getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the modifiedDate
	 */
	public DateTime getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return the selection
	 */
	public Boolean getSelection() {
		return selection;
	}

	/**
	 * @param selection the selection to set
	 */
	public void setSelection(Boolean selection) {
		this.selection = selection;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TextField [textFieldId=" + textFieldId + ", textFieldValue=" + textFieldValue + ", subCategory="
				+ subCategory + ", createdDate=" + createdDate + ", modifiedDate=" + modifiedDate + ", selection="
				+ selection + "]";
	}
}
