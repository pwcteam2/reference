package com.monitor.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.joda.time.DateTime;

@Entity
@Table(name = "pod")
public class Pod {

	@Id
	@GeneratedValue
	private Long podId;
	private String podName;
	private DateTime deletedDate;
	private DateTime createdDate;
	private DateTime modifiedDate;
	
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "added_by", nullable = false)
	private User addedBy;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "deleted_by", nullable = false)
	private User deletedBy;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "pod_id", nullable = false)
	private List<Channel> channelList;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "pod_id", nullable = false)
	private List<Category> categoryList;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "location_id", nullable = false)
	private Location location;
	
	private boolean disabled;
	
	private Long configurationVersion = 0l;
	
	private Integer timeBracketInMinutes;
	
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY, mappedBy = "pod")
	private List<PodHistory> podHistories;

	public Long getPodId() {
		return podId;
	}

	public void setPodId(Long podId) {
		this.podId = podId;
	}

	public String getPodName() {
		return podName;
	}

	public void setPodName(String podName) {
		this.podName = podName;
	}

	public DateTime getDeletedDate() {
		return deletedDate;
	}

	public void setDeletedDate(DateTime deletedDate) {
		this.deletedDate = deletedDate;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	public DateTime getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public User getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(User addedBy) {
		this.addedBy = addedBy;
	}

	public User getDeletedBy() {
		return deletedBy;
	}

	public void setDeletedBy(User deletedBy) {
		this.deletedBy = deletedBy;
	}

	public List<Channel> getChannelList() {
		return channelList;
	}

	public void setChannelList(List<Channel> channelList) {
		this.channelList = channelList;
	}

	public List<Category> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public boolean isDisabled() {
		return disabled;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	public Long getConfigurationVersion() {
		return configurationVersion;
	}

	public void setConfigurationVersion(Long configurationVersion) {
		this.configurationVersion = configurationVersion;
	}

	/**
	 * @return the timeBracketInMinutes
	 */
	public Integer getTimeBracketInMinutes() {
		return timeBracketInMinutes;
	}

	/**
	 * @param timeBracketInMinutes the timeBracketInMinutes to set
	 */
	public void setTimeBracketInMinutes(Integer timeBracketInMinutes) {
		this.timeBracketInMinutes = timeBracketInMinutes;
	}

	public List<PodHistory> getPodHistories() {
		return podHistories;
	}

	public void setPodHistories(List<PodHistory> podHistories) {
		this.podHistories = podHistories;
	}

}
