package com.monitor.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * This entity will be used for storing history of a monitor sheet after first
 * completion of the sheet.
 * 
 * @author Wittybrains
 *
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
public class MonitorSheetHistory {

	@Id
	@GeneratedValue
	private Long monitorSheetHistoryId;

	@NotNull
	@LastModifiedDate
	private DateTime modifiedDate;

	@NotNull
	@CreatedDate
	private DateTime createdDate;

	@NotNull
	private String action;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "modifier", nullable = false)
	private User modifier;

	private String operatorRemarks;

	private String approverRemarks;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "monitor_sheet_history_id", nullable = false, updatable = false)
	private List<MonitorSheetDetailHistory> monitorSheetDetailHistories;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private MonitorSheet monitorSheet;

	/**
	 * @return the monitorSheetHistoryId
	 */
	public Long getMonitorSheetHistoryId() {
		return monitorSheetHistoryId;
	}

	/**
	 * @param monitorSheetHistoryId
	 *            the monitorSheetHistoryId to set
	 */
	public void setMonitorSheetHistoryId(Long monitorSheetHistoryId) {
		this.monitorSheetHistoryId = monitorSheetHistoryId;
	}

	/**
	 * @return the modifiedDate
	 */
	public DateTime getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate
	 *            the modifiedDate to set
	 */
	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return the createdDate
	 */
	public DateTime getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate
	 *            the createdDate to set
	 */
	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action
	 *            the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return the modifier
	 */
	public User getModifier() {
		return modifier;
	}

	/**
	 * @param modifier
	 *            the modifier to set
	 */
	public void setModifier(User modifier) {
		this.modifier = modifier;
	}

	/**
	 * @return the operatorRemarks
	 */
	public String getOperatorRemarks() {
		return operatorRemarks;
	}

	/**
	 * @param operatorRemarks
	 *            the operatorRemarks to set
	 */
	public void setOperatorRemarks(String operatorRemarks) {
		this.operatorRemarks = operatorRemarks;
	}

	/**
	 * @return the approverRemarks
	 */
	public String getApproverRemarks() {
		return approverRemarks;
	}

	/**
	 * @param approverRemarks
	 *            the approverRemarks to set
	 */
	public void setApproverRemarks(String approverRemarks) {
		this.approverRemarks = approverRemarks;
	}

	/**
	 * @return the monitorSheetDetailHistories
	 */
	public List<MonitorSheetDetailHistory> getMonitorSheetDetailHistories() {
		return monitorSheetDetailHistories;
	}

	/**
	 * @param monitorSheetDetailHistories the monitorSheetDetailHistories to set
	 */
	public void setMonitorSheetDetailHistories(List<MonitorSheetDetailHistory> monitorSheetDetailHistories) {
		this.monitorSheetDetailHistories = monitorSheetDetailHistories;
	}

	/**
	 * @return the monitorSheet
	 */
	public MonitorSheet getMonitorSheet() {
		return monitorSheet;
	}

	/**
	 * @param monitorSheet the monitorSheet to set
	 */
	public void setMonitorSheet(MonitorSheet monitorSheet) {
		this.monitorSheet = monitorSheet;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MonitorSheetHistory [monitorSheetHistoryId=" + monitorSheetHistoryId + ", modifiedDate=" + modifiedDate
				+ ", createdDate=" + createdDate + ", action=" + action + ", modifier=" + modifier
				+ ", operatorRemarks=" + operatorRemarks + ", approverRemarks=" + approverRemarks
				+ ", monitorSheetDetailHistories=" + monitorSheetDetailHistories + ", monitorSheet=" + monitorSheet
				+ "]";
	}

}
