package com.monitor.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.joda.time.DateTime;

@Entity
@Table(name = "location")
public class Location {

	@Id
	@GeneratedValue
	private Long locationId;
	private String locationName;
	private DateTime deletedDate;
	private DateTime createdDate;
	private DateTime modifiedDate;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "added_by", nullable = false)
	private User addedBy;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "deleted_by", nullable = false)
	private User deletedBy;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "location_id")
	private List<Pod> podList;
	
	private boolean disabled;

	public Long getLocationId() {
		return locationId;
	}

	public void setLocationId(Long locationId) {
		this.locationId = locationId;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public DateTime getDeletedDate() {
		return deletedDate;
	}

	public void setDeletedDate(DateTime deletedDate) {
		this.deletedDate = deletedDate;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	public DateTime getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public User getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(User addedBy) {
		this.addedBy = addedBy;
	}

	public User getDeletedBy() {
		return deletedBy;
	}

	public void setDeletedBy(User deletedBy) {
		this.deletedBy = deletedBy;
	}

	public List<Pod> getPodList() {
		return podList;
	}

	public void setPodList(List<Pod> podList) {
		this.podList = podList;
	}

	public boolean isDisabled() {
		return disabled;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}
	
}
