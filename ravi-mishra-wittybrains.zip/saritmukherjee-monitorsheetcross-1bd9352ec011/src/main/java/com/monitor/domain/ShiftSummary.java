package com.monitor.domain;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import org.joda.time.DateTime;

@Entity
public class ShiftSummary {

	@Id
	@GeneratedValue
	private Long shiftSummaryId;
	

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "approved_by", nullable = false)
	private User approvedBy;

	private String summary;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "shift_id", nullable = false)
	private Shift shift;

	@NotNull
	private DateTime createdDate;

	@NotNull
	private DateTime modifiedDate;
	
	private DateTime approvedDate;

	@NotNull
	private DateTime shiftDate;

	@NotNull
	private Boolean approved = false;
	
	@NotNull
	private Boolean mailSent =  false;
	
	
	@Version// added version column for optimistic locking
	private Long version = 0L;

	public Long getShiftSummaryId() {
		return shiftSummaryId;
	}

	public void setShiftSummaryId(Long shiftSummaryId) {
		this.shiftSummaryId = shiftSummaryId;
	}

	public User getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(User approvedBy) {
		this.approvedBy = approvedBy;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public Shift getShift() {
		return shift;
	}

	public void setShift(Shift shift) {
		this.shift = shift;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	public DateTime getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public DateTime getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(DateTime approvedDate) {
		this.approvedDate = approvedDate;
	}

	public DateTime getShiftDate() {
		return shiftDate;
	}

	public void setShiftDate(DateTime shiftDate) {
		this.shiftDate = shiftDate;
	}

	public Boolean getApproved() {
		return approved;
	}

	public void setApproved(Boolean approved) {
		this.approved = approved;
	}

	public Boolean getMailSent() {
		return mailSent;
	}

	public void setMailSent(Boolean mailSent) {
		this.mailSent = mailSent;
	}

	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}
	
}
