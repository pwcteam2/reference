package com.monitor.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**This entity is used to store each field(Boolean) in the sheet.
 * @author Wittybrains
 *
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
public class CategoryWiseField {

	@Id
	@GeneratedValue
	private Long categoryWiseFieldId;
	
	private Boolean categoryWiseFieldValue;

	@NotNull
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(nullable = false, updatable = false)
	private Category category;
	
	@NotNull
	@CreatedDate
	private DateTime createdDate;
	
	@NotNull
	@LastModifiedDate
	private DateTime modifiedDate;
	
	public CategoryWiseField() {
	}

	public CategoryWiseField(Long categoryWiseFieldId, Boolean categoryWiseFieldValue, Category category) {
		this.categoryWiseFieldId = categoryWiseFieldId;
		this.categoryWiseFieldValue = categoryWiseFieldValue;
		this.category = category;
	}

	public Long getCategoryWiseFieldId() {
		return categoryWiseFieldId;
	}

	public void setCategoryWiseFieldId(Long categoryWiseFieldId) {
		this.categoryWiseFieldId = categoryWiseFieldId;
	}

	public Boolean getCategoryWiseFieldValue() {
		return categoryWiseFieldValue;
	}

	public void setCategoryWiseFieldValue(Boolean categoryWiseFieldValue) {
		this.categoryWiseFieldValue = categoryWiseFieldValue;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	public DateTime getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@Override
	public String toString() {
		return "CategoryWiseField [categoryWiseFieldId=" + categoryWiseFieldId + ", categoryWiseFieldValue="
				+ categoryWiseFieldValue + ", category=" + category + ", createdDate=" + createdDate + ", modifiedDate="
				+ modifiedDate + "]";
	}
}
