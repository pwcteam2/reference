package com.monitor.enums;

public enum RoleEnum {

	ADMIN("ADMIN"),
	MANAGER("MANAGER"),
	OPERATOR("OPERATOR"),
	SUPERVISOR("SUPERVISOR");
	
	private String role;
	
	RoleEnum(String role){
		this.role =  role;
	}
	
	public String role(){
		return role;
	}
}
