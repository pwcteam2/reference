package com.monitor.enums;

public enum ChannelStatusEnum {

	APPROVED("Approved"),
	PENDING("Pending"),
	NO_ENTRIES("No Entries");
	
	private final String status;
	
	ChannelStatusEnum(String status){
		this.status = status;
	}
	
	public String getStatus() {
		return status;
	}
}

