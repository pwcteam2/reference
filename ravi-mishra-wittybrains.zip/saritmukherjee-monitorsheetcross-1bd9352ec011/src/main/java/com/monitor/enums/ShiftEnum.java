package com.monitor.enums;

public enum ShiftEnum {

	MORNING("Morning"),
	NIGHT("Night"),
	ALL("All");
	
	private String shift;
	
	ShiftEnum(String shift){
		this.shift =  shift;
	}
	
	public String shift(){
		return shift;
	}
}
