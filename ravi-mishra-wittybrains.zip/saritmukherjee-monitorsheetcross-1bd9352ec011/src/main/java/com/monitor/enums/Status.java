package com.monitor.enums;

/**Used for monitor sheet status.
 * @author Wittybrains
 *
 */
public enum Status {

	APPROVED("Approved"),
	SAVED("Saved"),
	COMPLETED("completed"),
	CONFIGURATION("configuration"),
	PENDING("pending"),
	SENT("sent");
	
	private final String status;
	
	Status(String status){
		this.status = status;
	}
	
	public String getStatus() {
		return status;
	}
}
