package com.monitor.enums;

public enum PodAction {

	SHEETCONFIGURED("Sheet configured"),
	CATEGORYADDED("Category added"),
	CHANNELADDED("Channel added"),
	SUBCATEGORYADDED("Sub category added"),
	CATEGORYDELETED("Category deleted"),
	CHANNELDELETED("Channel deleted"),
	SUBCATEGORYDELETED("Sub category deleted"),
	CATEGORYDISABLED("Category disabled"),
	CHANNELDISABLED("Channel disabled"),
	SUBCATEGORYDISABLED("Sub category disabled"),
	CATEGORYEDITED("Category edited"),
	CHANNELEDITED("Channel edited"),
	SUBCATEGORYEDITED("Sub category edited"),
	PODADDED("Pod added"),
	PODDELETED("Pod deleted"),
	PODDISABLED("Pod disabled"),
	PODEDITED("Pod edited");
	
	private final String action;
	
	PodAction(String action){
		this.action = action;
	}
	
	public String getStatus() {
		return action;
	}
}
