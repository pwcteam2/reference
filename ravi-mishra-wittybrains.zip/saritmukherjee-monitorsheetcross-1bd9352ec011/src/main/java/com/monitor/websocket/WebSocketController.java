package com.monitor.websocket;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageExceptionHandler;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.annotation.SendToUser;
import org.springframework.messaging.simp.annotation.SubscribeMapping;
import org.springframework.web.bind.annotation.RestController;

import com.monitor.domain.Fruit;
import com.monitor.exception.ServiceException;
import com.monitor.service.UserService;

@RestController
public class WebSocketController {

	@Autowired
	private UserService userService;

	@Autowired
	private FruitRepository fruitRepository;

	@Autowired
	private SimpMessagingTemplate simpMessagingTemplate;

	@MessageMapping("/fruit")
	@SendToUser("/queue/fruit")
	public List<Fruit> addFruit(String fruitName, Principal principal) throws ServiceException {
		// simpMessagingTemplate.convertAndSendToUser(principal.getName(),
		// "/queue/message", new
		// User(userService.findByEmail(principal.getName()).getEmail()));
		// if(users == null || users.isEmpty()) {
		// users = new ArrayList<>();
		// users.add(new User("Sarit"));
		// users.add(new User("Sudhir"));
		// users.add(new User("Rajiv"));
		// users.add(new User("ABC"));
		// }
		fruitName = fruitName.replaceAll("\"", "");
		if(fruitName.equalsIgnoreCase("err"))
			throw new ServiceException("There is an exception.");
		if (fruitName != null && !fruitName.isEmpty())
			fruitRepository.save(new Fruit(fruitName));
		return fruitRepository.findAll();
	}

	// @MessageMapping("/user")
	// @SendTo("/topic/user")
	// public UserResponse getUser(User user) throws ServiceException {
	// return new UserResponse("Hi " + user.getName());
	// }
	
	@MessageMapping("/deletefruit")
	@SendToUser("/queue/fruit")
	public List<Fruit> deleteFruit(Long fruitId, Principal principal) throws ServiceException {
		if(fruitId != null)
			fruitRepository.delete(fruitId);
		return fruitRepository.findAll();
	}
	
	@SubscribeMapping("/fruit")
	public List<Fruit> getFruits() throws ServiceException {
		return fruitRepository.findAll();
	}
	
	@MessageExceptionHandler
	@SendToUser("/queue/fruit")
    public String handleException(ServiceException exception) {
        return exception.getMessage();
    }
}
