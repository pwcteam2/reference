package com.monitor.websocket;

public class UserResponse {
    String content;

    public UserResponse() {
    }

    public String getContent() {
        return content;
    }

    public UserResponse(String content) {
        this.content = content;
    }
}
