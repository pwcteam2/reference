package com.monitor.websocket;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.monitor.domain.Fruit;

@Repository
public interface FruitRepository extends JpaRepository<Fruit, Long>{

	public List<Fruit> findAll();
	
	public void deleteByFruitId(Long fruitId);
}
