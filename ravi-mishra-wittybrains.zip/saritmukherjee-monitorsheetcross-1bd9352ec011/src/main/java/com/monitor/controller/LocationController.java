package com.monitor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.monitor.DTO.LocationDTO;
import com.monitor.DTO.LocationReturnDTO;
import com.monitor.exception.ServiceException;
import com.monitor.service.LocationService;

@RestController
@RequestMapping("/location")
public class LocationController {

	private LocationService locationService;

	@Autowired
	public LocationController(LocationService locationService) {
		this.locationService = locationService;
	}

	@PostMapping(value = "/addlocation")
	public LocationDTO addLocation(@RequestBody LocationDTO locationDTO) throws ServiceException {
		return locationService.addLocation(locationDTO);
	}

	@PostMapping(value = "/editlocation")
	public void editLocation(@RequestBody LocationDTO locationDTO) throws ServiceException {
		locationService.editLocation(locationDTO);
	}

	@GetMapping(value = "/locationlist")
	public List<LocationReturnDTO> getAllLocation(@RequestParam(value = "alphabeticalorder", required = false) Boolean alphabeticalOrder) {
		return locationService.findAllByOrderByCreatedDateAsc(alphabeticalOrder);
	}

	@DeleteMapping(value = "/deletelocation/{id}")
	public void deleteLocation(@PathVariable("id") Long locationId) throws ServiceException {
		locationService.deleteLocation(locationId);
	}

	/**Params are required.
	 * @param locationId
	 * @param disable
	 * @throws ServiceException
	 */
	@PostMapping(value = "/disablelocation")
	public void disableLocation(@RequestParam(value = "id", required = true) Long locationId,
			@RequestParam(value = "disable", required = true) Boolean disable) throws ServiceException {
		locationService.disableLocation(locationId, disable);
	}
}
