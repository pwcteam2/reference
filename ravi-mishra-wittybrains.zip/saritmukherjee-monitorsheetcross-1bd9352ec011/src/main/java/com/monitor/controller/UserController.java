package com.monitor.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.monitor.DTO.ChangePasswordDTO;
import com.monitor.DTO.UserDTO;
import com.monitor.domain.Role;
import com.monitor.exception.ServiceException;
import com.monitor.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}

	private UserService userService;

	@RequestMapping(value = "/getrole", method = RequestMethod.GET)
	public Role getRole() throws ServiceException {
		return userService.getUserRole();
	}
	
	@RequestMapping(value = "/userinfo", method = RequestMethod.GET)
	public UserDTO getUserInfoRole() throws ServiceException {
		return userService.getUserInfo();
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public void registerUser(@RequestBody UserDTO user) throws ServiceException {
		userService.registerUser(user);
	}

	@RequestMapping(value = "/activeInactive", method = RequestMethod.POST)
	public void activeInactiveUser(@RequestBody UserDTO user) throws ServiceException {
		userService.activeInactiveUser(user);
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public void editUser(@RequestBody UserDTO user) throws ServiceException {
		userService.editUser(user);
	}
	
	@RequestMapping(value = "/roles", method = RequestMethod.GET)
	public List<Role> getRoles() throws ServiceException{
		return userService.getAllRoles();
	}
	
	@RequestMapping(value = "/allusers", method = RequestMethod.GET)
	public List<UserDTO> getUsersList() throws ServiceException{
		return userService.getAllUsers();
	}
	
	/**
	 * Change the password of an user
	 * Service url: 
	 * /employee/changePassword method: POST 
	 *
	 * @param Change Password DTO
	 * @return void
	 * @throws ServiceException the service exception
	 */
	@RequestMapping(value = "/changepassword", method = RequestMethod.POST)
	void changePassword(@RequestBody ChangePasswordDTO passwordWrapper) throws ServiceException 
	{
		userService.changePassword(passwordWrapper.getOldPassword(), passwordWrapper.getNewPassword());
	}

	/**
	 * Change the password of an user
	 * Service url: 
	 * /employee/changePassword method: POST 
	 *
	 * @param Change Password DTO
	 * @return void
	 * @throws ServiceException the service exception
	 */
	@RequestMapping(value = "/resetpassword", method = RequestMethod.POST)
	void resetPassword(@RequestBody UserDTO user) throws ServiceException 
	{
		userService.resetPassword(user);
	}
}
