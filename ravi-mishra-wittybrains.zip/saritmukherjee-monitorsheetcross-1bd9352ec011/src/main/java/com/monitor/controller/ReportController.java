package com.monitor.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lowagie.text.DocumentException;
import com.monitor.DTO.HtmlReportDTO;
import com.monitor.DTO.LocationReturnDTO;
import com.monitor.DTO.PodDTO;
import com.monitor.DTO.ReportCarrierDTO;
import com.monitor.exception.ServiceException;
import com.monitor.service.ReportService;

@RestController
public class ReportController {

	@Autowired
	public ReportController(ReportService reportService) {
		this.reportService = reportService;
	}

	private ReportService reportService;

	// Used for xls report
	@RequestMapping(value = "/excelreport", method = RequestMethod.GET)
	public void generateExcelReport(@RequestParam("fromdate") String startDate, @RequestParam("todate") String endDate,
			@RequestParam("shift") Long[] shift, @RequestParam(value = "pod", required = true) Long[] pods,
			@RequestParam(value = "location", required = true) Long[] locations,
			@RequestParam(value = "timebracket", required = false) Long[] timeBracketIds, HttpServletRequest request,
			HttpServletResponse response)
			throws ServiceException, DocumentException, IOException, com.itextpdf.text.DocumentException {
		reportService.excelReport(startDate, endDate, shift, pods, locations, timeBracketIds, request, response);
	}

	// Used for pdf report
	@RequestMapping(value = "/generatereport", method = RequestMethod.GET)
	public ReportCarrierDTO generateReport(@RequestParam("fromdate") String startDate,
			@RequestParam("todate") String endDate, @RequestParam("shift") Long[] shift,
			@RequestParam(value = "pod", required = true) Long[] pods,
			@RequestParam(value = "location", required = true) Long[] locations,
			@RequestParam(value = "timebracket", required = false) Long[] timeBracketIds, HttpServletRequest request,
			HttpServletResponse response)
			throws ServiceException, DocumentException, IOException, com.itextpdf.text.DocumentException {
		return reportService.generateReport(startDate, endDate, shift, pods, locations, timeBracketIds, null, null,
				true);
	}

	// Used for html report
	@RequestMapping(value = "/htmlreport", method = RequestMethod.GET)
	public List<HtmlReportDTO> generateHtmlReport(@RequestParam("fromdate") String startDate,
			@RequestParam("todate") String endDate, @RequestParam("shift") Long[] shift,
			@RequestParam(value = "pod", required = true) Long[] pods,
			@RequestParam(value = "location", required = true) Long[] locations,
			@RequestParam(value = "timebracket", required = false) Long[] timeBracketIds, HttpServletRequest request,
			HttpServletResponse response)
			throws ServiceException, DocumentException, IOException, com.itextpdf.text.DocumentException {
		return reportService.htmlReport(startDate, endDate, shift, pods, locations, timeBracketIds, request, response);
	}

	// Used for html error report
	@RequestMapping(value = "/htmlerrorreport", method = RequestMethod.GET)
	public Map<String, Map<String, List<String>>> generateHtmlErrorReport(@RequestParam("fromdate") String startDate,
			@RequestParam("todate") String endDate, @RequestParam("shift") Long[] shift,
			@RequestParam(value = "pod", required = true) Long[] pods,
			@RequestParam(value = "location", required = true) Long[] locations,
			@RequestParam(value = "timebracket", required = false) Long[] timeBracketIds, HttpServletRequest request,
			HttpServletResponse response)
			throws ServiceException, DocumentException, IOException, com.itextpdf.text.DocumentException {
		return reportService.htmlErrorReport(startDate, endDate, shift, pods, locations, timeBracketIds, request,
				response);
	}

	/** The api is used only for getting locations in the report view.
	 * @param startDate
	 * @param endDate
	 * @return
	 * @throws ServiceException 
	 */
	@GetMapping(value = "/reportlocationlist")
	public List<LocationReturnDTO> reportLocationList(@RequestParam("fromdate") String startDate,
			@RequestParam("todate") String endDate) throws ServiceException {
		return reportService.reportLocationList(startDate, endDate, true);
	}

	/** The api is used only for getting pods in the report view.
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@GetMapping(value = "/reportpodlist")
	public List<PodDTO> reportPodList(@RequestParam("fromdate") String startDate,
			@RequestParam("todate") String endDate, @RequestParam("locationid") Long locationId)
			throws ServiceException {
		return reportService.reportPodList(startDate, endDate, locationId, true);
	}

}