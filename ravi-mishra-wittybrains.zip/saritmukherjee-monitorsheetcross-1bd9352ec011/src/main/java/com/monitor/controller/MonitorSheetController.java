package com.monitor.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.monitor.DTO.ChannelDTO;
import com.monitor.DTO.MonitorSheetDTO;
import com.monitor.DTO.SheetAccordianViewDTO;
import com.monitor.DTO.TimeBracketDTO;
import com.monitor.domain.TimeBracketDuration;
import com.monitor.exception.ServiceException;
import com.monitor.service.MonitorSheetService;

/**
 * @author Wittybrains
 *
 */
@RestController
@RequestMapping("/monitorsheet")
public class MonitorSheetController {
	@Autowired
	private MonitorSheetService monitorSheetService;

	/**
	 * For Accordian View podid,shiftdate,shiftid is mandatory. shiftDate format
	 * is dd-MM-yyyy(16-07-2018)
	 * 
	 * @param podId
	 * @param shiftDate
	 * @param shiftId
	 * @return
	 * @throws ServiceException
	 */
	@RequestMapping(value = "/getaccordianlist", method = RequestMethod.GET)
	public List<SheetAccordianViewDTO> getAccordianList(@RequestParam(name = "podid", required = true) Long podId,
			@RequestParam(name = "shiftdate", required = true) String shiftDate,
			@RequestParam(name = "shiftid", required = true) Long shiftId) throws ServiceException {
		return monitorSheetService.getAccordianList(podId, shiftDate, shiftId);

	}

	/**
	 * Get a sheet with the monitorId given. Note Long channelId used as
	 * primitive type not working as optional.
	 * 
	 * @param monitorId
	 *            is mandatory.
	 * @param channelId
	 *            is not mandatory. If not given, then all channel data will be
	 *            given.
	 * @return
	 * @throws ServiceException
	 */
	@GetMapping(value = "/getmonitorsheetlist")
	public MonitorSheetDTO getMonitorSheetList(@RequestParam(name = "monitorid", required = false) Long monitorId,
			@RequestParam(name = "channelid", required = false) Long channelId) throws ServiceException {
		return monitorSheetService.getMonitorSheetList(monitorId, channelId);
	}

	/**
	 * Will be used to create new Sheet with all blank data. Note not persisted
	 * in DB. It will get the first(Alphabetically) channel data of the sheet
	 * only.
	 * 
	 * @param podId
	 *            is mandatory.
	 * @return
	 * @throws ServiceException
	 */
	@PostMapping(value = "/createmonitorsheet")
	private MonitorSheetDTO createMonitorSheet(@RequestParam(name = "podid", required = true) Long podId)
			throws ServiceException {
		return monitorSheetService.createMonitorSheet(podId);
	}

	/**
	 * Will save the data of a particular channel for a sheet if channel id is
	 * given otherwise all channel data will be saved.
	 * 
	 * @param monitorSheetDTO
	 * @param channelId
	 * @return
	 * @throws ServiceException
	 */
	@PostMapping(value = "/savemonitorsheet")
	public Long saveMonitorSheet(@RequestBody MonitorSheetDTO monitorSheetDTO,
			@RequestParam(value = "channelid", required = false) Long channelId,
			@RequestParam(value = "action", required = false) String action) throws ServiceException {
		return monitorSheetService.saveMonitorSheet(monitorSheetDTO, channelId, action);
	}

	/**
	 * @param monitorId
	 * @throws ServiceException
	 */
	@PostMapping(value = "/completemonitorsheet")
	public void completeMonitorSheet(@RequestParam(value = "monitorid", required = true) Long monitorId)
			throws ServiceException {
		monitorSheetService.completeMonitorSheet(monitorId);
	}

	/**
	 * Remaining channel data should be saved before completion for a monitor
	 * sheet.
	 * 
	 * @param monitorId
	 * @return Remaining channel data should be saved before completion.
	 * @throws ServiceException
	 */
	@GetMapping(value = "/completioneligibility")
	public Integer completionEligibility(@RequestParam(value = "monitorid", required = true) Long monitorId)
			throws ServiceException {
		return monitorSheetService.completionEligibility(monitorId);
	}

	/**
	 * Will check if any saved sheet is present for the given pod. Return True
	 * if no saved entry present else false.
	 * 
	 * @param podId
	 * @return
	 * @throws ServiceException
	 */
	@GetMapping(value = "/createeligibility")
	public boolean createEligibility(@RequestParam(value = "podid", required = true) Long podId)
			throws ServiceException {
		return monitorSheetService.createEligibility(podId);
	}

	/**
	 * This api will be used to approve a sheet. Supervisor remarks are saved
	 * via saveMonitorSheet api.
	 * 
	 * @param monitorId
	 * @throws ServiceException
	 */
	@PostMapping(value = "/approvemonitorsheet")
	public void approveMonitorSheet(@RequestParam(value = "monitoridlist", required = true) List<Long> monitorIdList)
			throws ServiceException {
		monitorSheetService.approveMonitorSheet(monitorIdList);
	}

	/**
	 * Will be used to get all enabled channels for a pod in case new sheet or
	 * saved sheet. For completed or approved sheets channels will be according
	 * to the sheet in DB.
	 * 
	 * @param monitorId
	 * @param podId
	 * @return
	 * @throws ServiceException
	 */
	@GetMapping(value = "/monitorsheetchannellist")
	public List<ChannelDTO> monitorsheetchannellist(@RequestParam(value = "monitorid", required = false) Long monitorId,
			@RequestParam(value = "podid", required = true) Long podId) throws ServiceException {
		return monitorSheetService.monitorsheetchannellist(monitorId, podId);
	}

	/**
	 * Will return true if there is no saved or completed sheet for that pod. In
	 * case if saved or completed sheet present it will throw error with a
	 * custom message.
	 * 
	 * @param podId
	 * @return
	 * @throws ServiceException
	 */
	@PostMapping(value = "/configeligibility")
	public Boolean configEligibility(@RequestParam(value = "podid", required = true) Long podId)
			throws ServiceException {
		return monitorSheetService.configEligibility(podId, false);
	}

	/**
	 * This api will only be used by manager for configuring a sheet. The
	 * textfield table will get the values by this api to show to the operator
	 * for selection. New monitor sheet status added "CONFIGURATION" for this
	 * kind of sheet.
	 * 
	 * @param podId
	 * @return
	 * @throws ServiceException
	 */
	@PostMapping(value = "/createconfigmonitorsheet")
	private MonitorSheetDTO createConfigMonitorSheet(@RequestParam(name = "podid", required = true) Long podId)
			throws ServiceException {
		return monitorSheetService.createConfigMonitorSheet(podId);
	}

	/**
	 * This api is used for saving CONFIGURATION sheets. Can only be accessed by
	 * a manager. According to the sheet saved in this api, operator will get
	 * the same sheet text fields in the sheet
	 * 
	 * @param monitorSheetDTO
	 * @param channelId
	 * @param action
	 * @return
	 * @throws ServiceException
	 */
	@PostMapping(value = "/saveconfigmonitorsheet")
	public Long saveConfigMonitorSheet(@RequestBody MonitorSheetDTO monitorSheetDTO) throws ServiceException {
		return monitorSheetService.saveConfigMonitorSheet(monitorSheetDTO);
	}

	/**
	 * This api is used for Getting the time bracket for a pod and for a shift
	 * if given. Podid is mandatory. Shift id is mandatory. ShiftId is an array.
	 * 
	 * @param podId
	 * @param shiftId
	 * @return
	 * @throws ServiceException
	 */
	@PostMapping(value = "/gettimebracketlist")
	public List<TimeBracketDTO> getTimeBracketList(@RequestParam(name = "podid", required = true) Long podId,
			@RequestParam(name = "shiftid", required = true) Long[] shiftIds) throws ServiceException {
		return monitorSheetService.getTimeBracketList(podId, shiftIds, null);
	}

	/**
	 * This api is used for getting the time bracket of a monitor sheet.
	 * 
	 * @param monitorId
	 * @return
	 * @throws ServiceException
	 */
	@PostMapping(value = "/gettimebracket")
	public TimeBracketDTO getTimeBracket(@RequestParam(name = "monitorid", required = true) Long monitorId)
			throws ServiceException {
		return monitorSheetService.getTimeBracket(monitorId);
	}

	/**
	 * This api is used for getting the time bracket durations for the front end
	 * dropdown menu in Pod config.
	 * 
	 * @param monitorId
	 * @return
	 * @throws ServiceException
	 */
	@GetMapping(value = "/gettimebracketduration")
	public List<TimeBracketDuration> getTimeBracketDuration() throws ServiceException {
		return monitorSheetService.getTimeBracketDuration();
	}
}
