package com.monitor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.monitor.DTO.CategoryDTO;
import com.monitor.DTO.SubCategoryDTO;
import com.monitor.exception.ServiceException;
import com.monitor.service.CategoryService;
import com.monitor.service.SubCategoryService;

@RestController
@RequestMapping("/")
public class CategoryController {

	@Autowired
	private CategoryService categoryService;

	@Autowired
	private SubCategoryService subCategoryService;

	@RequestMapping(value = "/category/list/{podid}", method = RequestMethod.GET)
	public List<CategoryDTO> getAllCategory(@PathVariable("podid") Long podId,
			@RequestParam(value = "alphabeticalorder", required = false) Boolean alphabeticalOrder)
			throws ServiceException {
		return categoryService.getAllCategoriesByPod(podId, alphabeticalOrder);
	}

	@RequestMapping(value = "/category/add", method = RequestMethod.POST)
	CategoryDTO addCategory(@RequestBody CategoryDTO categoryDto) throws ServiceException {
		return categoryService.addCategory(categoryDto);
	}

	@RequestMapping(value = "/category/delete/{id}", method = RequestMethod.DELETE)
	public void deleteChannel(@PathVariable("id") Long channelId) throws ServiceException {
		categoryService.deleteCategory(channelId);
	}

	@RequestMapping(value = "/category/edit", method = RequestMethod.POST)
	public CategoryDTO editCategory(@RequestBody CategoryDTO categoryDTO) throws ServiceException {
		return categoryService.editCategory(categoryDTO);
	}

	@RequestMapping(value = "/category/disable", method = RequestMethod.POST)
	public void disableEnableCateoryValue(@RequestBody CategoryDTO categoryDTO) throws ServiceException {
		categoryService.disableCategory(categoryDTO);
	}

	// ******************************sub category
	// apis********************************************

	@RequestMapping(value = "/subcategory/list/{id}", method = RequestMethod.GET)
	public List<SubCategoryDTO> getAllSubCategoryValue(@PathVariable("id") Long categoryID) throws ServiceException {
		return subCategoryService.getSubCategoriesByCategoryID(categoryID);
	}

	@RequestMapping(value = "/subcategory/add", method = RequestMethod.POST)
	SubCategoryDTO addSubCategory(@RequestBody SubCategoryDTO subcategoryDto) throws ServiceException {
		return subCategoryService.addSubcategorie(subcategoryDto);
	}

	@RequestMapping(value = "/subcategory/delete/{id}", method = RequestMethod.DELETE)
	public void deleteSubCateory(@PathVariable("id") Long channelId) throws ServiceException {
		subCategoryService.deleteSubCateory(channelId);
	}

	@RequestMapping(value = "/subcategory/edit", method = RequestMethod.POST)
	public SubCategoryDTO editSubCategory(@RequestBody SubCategoryDTO subCategoryDTO) throws ServiceException {
		return subCategoryService.editSubcategorie(subCategoryDTO);
	}

	@RequestMapping(value = "/subcategory/disable", method = RequestMethod.POST)
	public void disableEnableSubCateoryValue(@RequestBody SubCategoryDTO subCategoryDTO) throws ServiceException {
		subCategoryService.disableSubCategory(subCategoryDTO);
	}

	// ******************************sub category value
	// apis********************************************

	// @RequestMapping(value="/subcategoryvalue/list/{id}",method =
	// RequestMethod.GET)
	// public List<SubCategoryValueDTO> getAllSubCategory(@PathVariable("id")
	// Long subcategoryId) throws ServiceException{
	// return subCategoryValueService.getSubCategorieValueList(subcategoryId);
	// }

	// @RequestMapping(value = "/subcategoryvalue/add", method =
	// RequestMethod.POST)
	// SubCategoryValueDTO addSubCategoryValue(@RequestBody SubCategoryValueDTO
	// subcategoryValueDto) throws ServiceException {
	// return subCategoryValueService.addSubcategorieValue(subcategoryValueDto);
	// }

	// @RequestMapping(value = "/subcategoryvalue/edit", method =
	// RequestMethod.POST)
	// public SubCategoryValueDTO editSubCategory(@RequestBody
	// SubCategoryValueDTO subCategoryValueDTO) throws ServiceException {
	// return subCategoryValueService.editSubcategoryValue(subCategoryValueDTO);
	// }

	// @RequestMapping(value = "/subcategoryvalue/delete/{id}", method =
	// RequestMethod.DELETE)
	// public void deleteSubCateoryValue(@PathVariable("id") Long channelId)
	// throws ServiceException {
	// subCategoryValueService.deleteSubCategoryValue(channelId);
	// }

	// @RequestMapping(value = "/subcategoryvalue/disable", method =
	// RequestMethod.POST)
	// public void disableEnableSubCateoryValue(@RequestBody SubCategoryValueDTO
	// subCategoryValueDTO) throws ServiceException {
	// subCategoryValueService.disableSubCategoryValue(subCategoryValueDTO);
	// }

}
