package com.monitor.controller;

import java.util.List;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.monitor.DTO.ShiftDTO;
import com.monitor.exception.ServiceException;
import com.monitor.service.ShiftService;

@RestController
@RequestMapping("/shift")
public class ShiftController {

	@Autowired
	private ShiftService shiftService;

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public List<ShiftDTO> getShift() throws ServiceException {
		return shiftService.getAllShift();

	}

	@RequestMapping(value = "/shiftstartenddate", method = RequestMethod.GET)
	public ShiftDTO getCurrentShiftStartAndEndDate() throws ServiceException {
		return shiftService.getCurrentShiftStartAndEndDate();

	}

	@GetMapping("/iscurrentshift")
	public Boolean isCurrentShift(@RequestParam(name = "shiftdate", required = true) String shiftDate,
			@RequestParam(name = "shiftid", required = true) Long shiftId) throws ServiceException {
		return shiftService.isCurrentShift(shiftDate, shiftId);
	}
	
	@GetMapping("/getcurrentdatetime")
	public DateTime getCurrentDateTime() throws ServiceException {
		return shiftService.getShiftDate(DateTime.now());
	}
}
