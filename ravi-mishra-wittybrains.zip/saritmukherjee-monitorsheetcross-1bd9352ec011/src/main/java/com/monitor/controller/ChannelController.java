package com.monitor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.monitor.DTO.ChannelDTO;
import com.monitor.DTO.PodDTO;
import com.monitor.exception.ServiceException;
import com.monitor.service.ChannelService;

@RestController
@RequestMapping("/channel")
public class ChannelController {
	@Autowired
	private ChannelService channelService;

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	List<ChannelDTO> getAllByUserAndChannel(@RequestParam(value = "selecteddate", required = false) String selectedDate,
			@RequestParam(value = "shiftid", required = false) Long shiftId,
			@RequestParam(value = "podid", required = true) Long podId) throws ServiceException {
		return channelService.getAllChannels(selectedDate, shiftId, podId);
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	ChannelDTO addChannel(@RequestBody ChannelDTO channelDTO) throws ServiceException {
		return channelService.addChannel(channelDTO);
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
	void deleteChannel(@PathVariable("id") Long channelId) throws ServiceException {
		channelService.deleteChannel(channelId);
	}

	@RequestMapping(value = "/deletepod/{id}", method = RequestMethod.DELETE)
	void deletePod(@PathVariable("id") Long podId) throws ServiceException {
		channelService.deletePod(podId);
	}

	@RequestMapping(value = "/podlist", method = RequestMethod.GET)
	List<PodDTO> getAllPods(@RequestParam(value = "locationid", required = true) Long locationId, @RequestParam(value = "alphabeticalorder", required = false) Boolean alphabeticalOrder)
			throws ServiceException {
		return channelService.getAllPods(locationId, alphabeticalOrder);
	}

	@RequestMapping(value = "/addpod", method = RequestMethod.POST)
	PodDTO addPod(@RequestBody PodDTO podDTO) throws ServiceException {
		return channelService.addPod(podDTO);
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public void editChannel(@RequestBody ChannelDTO channelDTO) throws ServiceException {
		channelService.editChannel(channelDTO);
	}

	@RequestMapping(value = "/editpod", method = RequestMethod.POST)
	public void editPod(@RequestBody PodDTO podDTO) throws ServiceException {
		channelService.editPod(podDTO);
	}

	@PostMapping(value = "/disablechannel")
	public void disableChannel(@RequestParam(value = "id", required = true) Long channelId,
			@RequestParam(value = "disable", required = true) Boolean disable) throws ServiceException {
		channelService.disableChannel(channelId, disable);
	}

	/**
	 * Params are required
	 * 
	 * @param podId
	 * @param disable
	 * @throws ServiceException
	 */
	@PostMapping(value = "/disablepod")
	public void disablePod(@RequestParam(value = "id", required = true) Long podId,
			@RequestParam(value = "disable", required = true) Boolean disable) throws ServiceException {
		channelService.disablePod(podId, disable);
	}
}
