package com.monitor.controller;

import java.util.LinkedHashMap;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.itextpdf.text.DocumentException;
import com.monitor.DTO.ApprovalStateDTO;
import com.monitor.DTO.ShiftSummaryDTO;
import com.monitor.exception.ServiceException;
import com.monitor.service.ShiftSummaryService;

@RestController
@RequestMapping("/shiftsummary")
public class ShiftSummaryController {
	@Autowired
	private ShiftSummaryService shiftSummaryService;

	@RequestMapping(value = "/approve", method = RequestMethod.POST)
	public void getAllByUserAndChannel(@RequestBody ShiftSummaryDTO shiftSummaryDTO)
			throws ServiceException, DocumentException {
		shiftSummaryService.approve( shiftSummaryDTO);
	}

	@RequestMapping(value = "/submit", method = RequestMethod.POST)
	public ShiftSummaryDTO saveOperatorMonitorSheet(@RequestBody ShiftSummaryDTO shiftSummaryDTO)
			throws ServiceException {
		return shiftSummaryService.submit(shiftSummaryDTO);
	}
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public LinkedHashMap<String, TreeMap<String, ShiftSummaryDTO>> getShiftSummary(
			@RequestParam("fromdate") String startDate, @RequestParam("todate") String endDate,
			@RequestParam("shift") Long[] shift) throws ServiceException {
		return shiftSummaryService.getShiftSummary(startDate, endDate, shift);
	}
	
	@RequestMapping(value = "/summarystate", method = RequestMethod.GET)
	public ApprovalStateDTO getSummaryState(
			@RequestParam("shiftid") Long shiftId,
			@RequestParam("shiftdate") String createdDate)
			throws ServiceException {
		return shiftSummaryService.getShiftSummaryState(shiftId, createdDate);
	}
	
	@PostMapping("/resendmail")
	public void resendMail(@RequestParam("id") Long shiftSummaryId) throws ServiceException {
		shiftSummaryService.resendMail(shiftSummaryId);
	}


}
