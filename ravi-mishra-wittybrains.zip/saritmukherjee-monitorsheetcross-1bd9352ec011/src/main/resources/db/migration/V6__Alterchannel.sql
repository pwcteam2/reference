
--
-- Alter channel add created date , modified Date and deleted date`
--


ALTER TABLE channel
ADD deleted_date TIMESTAMP NULL DEFAULT NULL,
ADD created_date timestamp  DEFAULT current_timestamp not  null,
ADD modified_date TIMESTAMP NULL DEFAULT NULL;

