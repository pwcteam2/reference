--
-- Table structure for table `monitor_sheet`
--

DROP TABLE IF EXISTS `shift_summary`;
CREATE TABLE `shift_summary` (
  `shift_summary_id` int NOT NULL AUTO_INCREMENT,
  `approved_by` int NULL,
  `shift_id` int NOT NULL,
  `summary` varchar(1000) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `shift_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `approved_date` datetime NULL,
  `approved` bit(1) NOT NULL default 0,
  `mail_sent` bit(1) NOT NULL default 0,
  PRIMARY KEY (`shift_summary_id`),
  FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  FOREIGN KEY (`shift_id`) REFERENCES `shift` (`shift_id`),
  UNIQUE `unique_index`(`shift_id`,`shift_date`)
);

