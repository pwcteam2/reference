
--
-- CREATE TABLE sub_category
--


DROP TABLE IF EXISTS `sub_category`;
CREATE TABLE `sub_category` (
  `sub_category_id` int NOT NULL AUTO_INCREMENT,
  `sub_category_name` varchar(250) not null,
  `category_id` int NOT NULL,
  `created_date`  TIMESTAMP  DEFAULT '0000-00-00 00:00:00' not  null,
  `modified_date` TIMESTAMP  DEFAULT now() on update now(),
  `disabled` bit(1)  DEFAULT 0,
  PRIMARY KEY (`sub_category_id`),
  FOREIGN KEY (category_id) REFERENCES category(category_id)
);

