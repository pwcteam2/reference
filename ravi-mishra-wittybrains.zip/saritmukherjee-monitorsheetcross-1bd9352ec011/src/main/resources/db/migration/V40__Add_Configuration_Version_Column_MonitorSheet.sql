ALTER TABLE `monitor_sheet` 
ADD COLUMN `configuration_version` BIGINT(20) NULL DEFAULT 0 AFTER `complete_date`;

--Setting current configuration version of the pod to the existing monitor sheets.
update monitor_sheet as ms join pod as p on ms.pod_id = p.pod_id set ms.configuration_version = p.configuration_version ;