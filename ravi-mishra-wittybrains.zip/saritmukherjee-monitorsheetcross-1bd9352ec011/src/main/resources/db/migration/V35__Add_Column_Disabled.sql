ALTER TABLE `channel` 
ADD COLUMN `disabled` BIT(1) NOT NULL AFTER `noc_number`;

ALTER TABLE `location` 
ADD COLUMN `disabled` BIT(1) NOT NULL AFTER `added_by`;

ALTER TABLE `pod` 
ADD COLUMN `disabled` BIT(1) NOT NULL AFTER `location_id`;
