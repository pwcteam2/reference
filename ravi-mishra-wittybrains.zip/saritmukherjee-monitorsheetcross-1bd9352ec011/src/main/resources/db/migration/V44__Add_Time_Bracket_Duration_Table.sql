DROP TABLE IF EXISTS `time_bracket_duration`;
CREATE TABLE `time_bracket_duration` (
  `time_bracket_duration_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `duration` int(11) NOT NULL,
  PRIMARY KEY (`time_bracket_duration_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `time_bracket_duration` (`duration`) VALUES ('15');
INSERT INTO `time_bracket_duration` (`duration`) VALUES ('30');
INSERT INTO `time_bracket_duration` (`duration`) VALUES ('45');
INSERT INTO `time_bracket_duration` (`duration`) VALUES ('60');