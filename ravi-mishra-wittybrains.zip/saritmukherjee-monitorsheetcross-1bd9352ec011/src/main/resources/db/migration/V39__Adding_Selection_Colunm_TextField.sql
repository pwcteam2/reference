ALTER TABLE `text_field` 
ADD COLUMN `selection` BIT(1) NULL AFTER `monitor_sheet_detail_id`;
