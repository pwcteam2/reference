DROP TABLE IF EXISTS `category_wise_field`;
CREATE TABLE `category_wise_field` (
  `category_wise_field_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_wise_field_value` bit(1) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `category` bigint(20) NOT NULL,
  `monitor_sheet_detail_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`category_wise_field_id`),
  KEY `FK_ndwkmnwujv7drnotq82idg231` (`monitor_sheet_detail_id`),
  CONSTRAINT `FK_ndwkmnwujv7drnotq82idg231` FOREIGN KEY (`monitor_sheet_detail_id`) REFERENCES `monitor_sheet_detail` (`monitor_sheet_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;