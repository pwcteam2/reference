
--
-- Alter Sheet table add approvl date column
--


ALTER TABLE  sheet_approval_detail ADD approved_date TIMESTAMP NULL DEFAULT NULL;
update sheet_approval_detail set approved_date = modified_date;
ALTER TABLE monitor_sheet DROP column  approved_date;

