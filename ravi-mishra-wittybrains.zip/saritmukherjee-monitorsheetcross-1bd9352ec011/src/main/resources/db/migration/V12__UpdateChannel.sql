
--
-- UPDATE CHANNEL 
--

-- add pod_id column to channel
ALTER TABLE channel ADD pod_id INTEGER not null;

-- update channel table add pod_ids
 update channel set pod_id = (select pod_id from pod where pod_name='GENERAL') where channel_name in ('Galaxy-625','PELANGI-626',
'TIMES NOW IRD','TRUEVISION HD-801','TRUEVISION SD-802','BEIN NZL-803','HITS-805','TVN REGIONAL-807','TVN SG -808','TVN MY -809');

update channel set pod_id = (select pod_id from pod where pod_name='AMC') where channel_name in
('AMC SGTEL-810','AMC VANILLA TWN-811','AMC-2 THAI-813','AMC KOREA-814','AMC HD-815');

-- insert new channels based on the list 
insert into channel  (channel_name,deleted,pod_id) values('NOC-621-- WAKU WAKU SEA',0,(select pod_id from pod where pod_name='ITX - UPCOMING'));
insert into channel  (channel_name,deleted,pod_id) values('NOC 622 WAKU WAKU TWN',0,(select pod_id from pod where pod_name='ITX - UPCOMING'));
insert into channel  (channel_name,deleted,pod_id) values('NOC 623- WAKU WAKU',0,(select pod_id from pod where pod_name='ITX - UPCOMING'));
insert into channel  (channel_name,deleted,pod_id) values('NOC 624- WAKU WAKU SG',0,(select pod_id from pod where pod_name='ITX - UPCOMING'));
insert into channel  (channel_name,deleted,pod_id) values('NOC 618- LITV',0,(select pod_id from pod where pod_name='ITX - UPCOMING'));
insert into channel  (channel_name,deleted,pod_id) values('NOC 613 HISTORY SH',0,(select pod_id from pod where pod_name='ITX - UPCOMING'));
insert into channel  (channel_name,deleted,pod_id) values('NOC 614- LIFETIME SH',0,(select pod_id from pod where pod_name='ITX - UPCOMING'));
insert into channel  (channel_name,deleted,pod_id) values('MTV INDIA INTERNATIONAL',0,(select pod_id from pod where pod_name='ITX - UPCOMING'));
insert into channel  (channel_name,deleted,pod_id) values('RISHTEY MENA',0,(select pod_id from pod where pod_name='ITX - UPCOMING'));

insert into channel  (channel_name,deleted,pod_id) values('AMC KOREA SAT -814',0,(select pod_id from pod where pod_name='AMC'));
insert into channel  (channel_name,deleted,pod_id) values('SDC MENA-816',0,(select pod_id from pod where pod_name='AMC'));




