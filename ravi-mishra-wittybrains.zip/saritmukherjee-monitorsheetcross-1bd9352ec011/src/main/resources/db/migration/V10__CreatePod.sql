
--
-- CREATE TABLE POD
--


DROP TABLE IF EXISTS `pod`;
CREATE TABLE `pod` (
  `pod_id` int NOT NULL AUTO_INCREMENT,
  `pod_name` varchar(250) DEFAULT NULL,
  `deleted_date`  TIMESTAMP  NULL DEFAULT NULL,
  `created_date`  TIMESTAMP  DEFAULT current_timestamp not  null,
  `modified_date` TIMESTAMP  NULL DEFAULT NULL,
  PRIMARY KEY (`pod_id`)
);

