DROP TABLE IF EXISTS `text_field`;
DROP TABLE IF EXISTS `monitor_sheet_detail`;
DROP TABLE IF EXISTS `monitor_sheet`;
DROP TABLE IF EXISTS `sheet_approval_detail`;

-- Table Structure for SheetApprovalDetail

CREATE TABLE `sheet_approval_detail` (
  `sheet_approval_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `approved_date` datetime DEFAULT NULL,
  `approver_remarks` varchar(255) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `approved_by` bigint(20) NOT NULL,
  PRIMARY KEY (`sheet_approval_id`)
);

-- Table Structure for MonitorSheet

CREATE TABLE `monitor_sheet` (
  `monitor_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `approved_by_supervisor` bit(1) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `deleted` bit(1) NOT NULL,
  `modified_date` datetime NOT NULL,
  `operator_remarks` varchar(255) DEFAULT NULL,
  `shift_date` datetime NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `operator_id` bigint(20) NOT NULL,
  `pod_id` bigint(20) NOT NULL,
  `sheet_approval_id` bigint(20) DEFAULT NULL,
  `shift_id` bigint(20) NOT NULL,
  PRIMARY KEY (`monitor_id`),
  KEY `FK_6xa8y8qx6hok2fm4gf72vtlot` (`sheet_approval_id`),
  CONSTRAINT `FK_6xa8y8qx6hok2fm4gf72vtlot` FOREIGN KEY (`sheet_approval_id`) REFERENCES `sheet_approval_detail` (`sheet_approval_id`)
);

-- Table Structure for MonitorSheetDetail

CREATE TABLE `monitor_sheet_detail` (
  `monitor_sheet_detail_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `channel` bigint(20) NOT NULL,
  `monitor_id` bigint(20) NOT NULL,
  PRIMARY KEY (`monitor_sheet_detail_id`),
  KEY `FK_en15fntxbgfy500s18tu1tiqh` (`monitor_id`),
  CONSTRAINT `FK_en15fntxbgfy500s18tu1tiqh` FOREIGN KEY (`monitor_id`) REFERENCES `monitor_sheet` (`monitor_id`)
);

-- Table Structure for TextField
CREATE TABLE `text_field` (
  `text_field_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `text_field_value` varchar(255) DEFAULT NULL,
  `sub_category` bigint(20) NOT NULL,
  `monitor_sheet_detail_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`text_field_id`),
  KEY `FK_ifwul04qlwbhd44oyryuloooq` (`monitor_sheet_detail_id`),
  CONSTRAINT `FK_ifwul04qlwbhd44oyryuloooq` FOREIGN KEY (`monitor_sheet_detail_id`) REFERENCES `monitor_sheet_detail` (`monitor_sheet_detail_id`)
);