ALTER TABLE `channel` 
CHANGE COLUMN `noc_number` `noc_number` VARCHAR(150) NULL DEFAULT NULL;