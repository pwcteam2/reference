-- Pod changes.
ALTER TABLE `pod` 
ADD COLUMN `time_bracket_in_minutes` INT(11) NULL DEFAULT NULL AFTER `configuration_version`;

--Monitor Sheet changes.
ALTER TABLE `monitor_sheet` 
ADD COLUMN `time_bracket_in_minutes` INT(11) NULL DEFAULT NULL AFTER `completer`,
ADD COLUMN `time_bracket_id` BIGINT(20) NULL DEFAULT NULL AFTER `time_bracket_in_minutes`;