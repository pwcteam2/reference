ALTER TABLE `monitor_sheet` 
DROP COLUMN `approved_by_supervisor`;


