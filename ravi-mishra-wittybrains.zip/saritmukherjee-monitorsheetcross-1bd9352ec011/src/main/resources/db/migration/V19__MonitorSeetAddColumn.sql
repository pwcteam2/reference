
--
-- Alter Sheet table add approvl date column
--


ALTER TABLE  monitor_sheet 
ADD shift_date datetime NOT NULL;

