
--
-- Alter user employee code
--


update user set employee_code=user_id;

