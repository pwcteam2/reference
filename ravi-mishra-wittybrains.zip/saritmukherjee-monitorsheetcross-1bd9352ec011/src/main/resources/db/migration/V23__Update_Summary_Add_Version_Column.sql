--
-- Alter shift_summary add ADD version
--

ALTER TABLE shift_summary ADD version int DEFAULT 0;