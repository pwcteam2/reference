--
-- Alter monitor_sheet add uno column
--

ALTER TABLE  monitor_sheet ADD `uno` bit(1)  DEFAULT NULL;
