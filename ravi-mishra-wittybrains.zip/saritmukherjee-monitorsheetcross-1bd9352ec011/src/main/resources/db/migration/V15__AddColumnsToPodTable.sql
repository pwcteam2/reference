
--
-- UPDATE pod 
--

-- add addedby and deleted by columns
ALTER TABLE pod
  ADD COLUMN deleted_by int(11),
  ADD COLUMN added_by int(11),
  ADD FOREIGN KEY deleted_by(deleted_by) REFERENCES user(user_id),
  ADD FOREIGN KEY added_by(added_by) REFERENCES user(user_id);
