--
-- Table structure for table `monitor_sheet`
--

DROP TABLE IF EXISTS `sheet_approval_detail`;
CREATE TABLE `sheet_approval_detail` (
  `sheet_approval_id` int NOT NULL AUTO_INCREMENT,
  `approved_by` int NOT NULL,
  `supervisor_remark` varchar(250) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`sheet_approval_id`),
  FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`)
);

ALTER TABLE monitor_sheet
ADD approved_by_supervisor bit(1) DEFAULT null,
ADD sheet_approval_id int DEFAULT null;

