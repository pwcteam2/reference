
--
-- Alter table Category add pod id
--


ALTER TABLE category
 ADD COLUMN pod_id int(11),
 ADD  FOREIGN KEY (pod_id) REFERENCES pod(pod_id);

