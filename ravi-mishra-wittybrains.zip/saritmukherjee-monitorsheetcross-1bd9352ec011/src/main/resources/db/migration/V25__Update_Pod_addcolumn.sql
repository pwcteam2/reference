

--
-- UPDATE Pod 
--

-- add location_id

ALTER TABLE pod
  ADD COLUMN location_id int(11),
  ADD CONSTRAINT `fk_location` FOREIGN KEY (location_id) REFERENCES location(location_id);
  