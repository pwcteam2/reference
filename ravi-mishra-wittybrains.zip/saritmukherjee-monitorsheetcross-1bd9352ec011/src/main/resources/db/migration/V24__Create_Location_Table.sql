

--
-- CREATE TABLE Locatiom
--


DROP TABLE IF EXISTS `location`;
CREATE TABLE `location` (
  `location_id` int NOT NULL AUTO_INCREMENT,
  `location_name` varchar(250) DEFAULT NULL,
  `deleted_date`  TIMESTAMP  NULL DEFAULT NULL,
  `created_date`  TIMESTAMP  DEFAULT current_timestamp not  null,
  `modified_date` TIMESTAMP  NULL DEFAULT NULL,
  `deleted_by` int(11),
  `added_by` int(11),
  FOREIGN KEY (`deleted_by`) REFERENCES `user`(`user_id`),
  FOREIGN KEY (`added_by`) REFERENCES `user`(`user_id`),
  PRIMARY KEY (`location_id`),
  UNIQUE KEY (`location_name`)
);
