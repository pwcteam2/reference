
--
-- ADD noc_number column in Channel 
--

ALTER TABLE channel 
ADD noc_number int(11) Default 0;
