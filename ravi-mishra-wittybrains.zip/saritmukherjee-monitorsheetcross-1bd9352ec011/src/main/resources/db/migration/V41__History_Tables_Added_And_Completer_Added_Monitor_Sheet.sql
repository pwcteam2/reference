--Completer added to detect who completed the sheet.
ALTER TABLE `monitor_sheet` 
ADD COLUMN `completer` BIGINT(20) NULL DEFAULT NULL AFTER `configuration_version`;

--Adding History tables.

--Monitor Sheet history
DROP TABLE IF EXISTS `monitor_sheet_history`;
CREATE TABLE `monitor_sheet_history` (
  `monitor_sheet_history_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `approver_remarks` varchar(255) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `operator_remarks` varchar(255) DEFAULT NULL,
  `modifier` bigint(20) NOT NULL,
  `monitor_sheet` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`monitor_sheet_history_id`),
  KEY `FK_fmachtduwf4p03hentgm3uk62` (`monitor_sheet`),
  CONSTRAINT `FK_fmachtduwf4p03hentgm3uk62` FOREIGN KEY (`monitor_sheet`) REFERENCES `monitor_sheet` (`monitor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--Monitor Sheet Detail History
DROP TABLE IF EXISTS `monitor_sheet_detail_history`;
CREATE TABLE `monitor_sheet_detail_history` (
  `monitor_sheet_detail_history_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `channel` bigint(20) NOT NULL,
  `monitor_sheet_history_id` bigint(20) NOT NULL,
  PRIMARY KEY (`monitor_sheet_detail_history_id`),
  KEY `FK_bgpsw87y0gigl5yexrbmirvyk` (`monitor_sheet_history_id`),
  CONSTRAINT `FK_bgpsw87y0gigl5yexrbmirvyk` FOREIGN KEY (`monitor_sheet_history_id`) REFERENCES `monitor_sheet_history` (`monitor_sheet_history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--Text Field History.
DROP TABLE IF EXISTS `text_field_history`;
CREATE TABLE `text_field_history` (
  `text_field_history_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `selection` bit(1) DEFAULT NULL,
  `text_field_history_value` varchar(255) DEFAULT NULL,
  `sub_category` bigint(20) NOT NULL,
  `monitor_sheet_detail_history_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`text_field_history_id`),
  KEY `FK_4knpb0v1jfpgnj8csg49asy1s` (`monitor_sheet_detail_history_id`),
  CONSTRAINT `FK_4knpb0v1jfpgnj8csg49asy1s` FOREIGN KEY (`monitor_sheet_detail_history_id`) REFERENCES `monitor_sheet_detail_history` (`monitor_sheet_detail_history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
