
--
-- CREATE TABLE POD
--


DROP TABLE IF EXISTS `category`;
CREATE TABLE  `category` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(250) not null,
  `created_date`  TIMESTAMP  DEFAULT '0000-00-00 00:00:00' not  null,
  `modified_date` TIMESTAMP  DEFAULT now() on update now(),
  `disabled` bit(1)  DEFAULT 0,
  PRIMARY KEY (`category_id`)
);

