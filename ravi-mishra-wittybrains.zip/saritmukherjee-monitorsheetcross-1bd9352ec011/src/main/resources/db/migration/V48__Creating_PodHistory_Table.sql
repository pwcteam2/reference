DROP TABLE IF EXISTS `pod_history`;
CREATE TABLE `pod_history` (
  `pod_history_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pod_action` varchar(255) NOT NULL,
  `configuration_version` bigint(20) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `disabled` bit(1) DEFAULT NULL,
  `pod_name` varchar(255) DEFAULT NULL,
  `time_bracket_in_minutes` int(11) DEFAULT NULL,
  `modifier` bigint(20) NOT NULL,
  `pod` int(11) DEFAULT NULL,
  PRIMARY KEY (`pod_history_id`),
  KEY `Fkhasgdjhagdjas_idx` (`pod`),
  CONSTRAINT `Fkhasgdjhagdjas` FOREIGN KEY (`pod`) REFERENCES `pod` (`pod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;