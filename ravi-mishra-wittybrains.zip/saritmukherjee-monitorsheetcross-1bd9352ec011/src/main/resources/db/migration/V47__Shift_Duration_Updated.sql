UPDATE `shift` SET `end_time`='19:59:59' WHERE `shift_id`='1';
UPDATE `shift` SET `end_time`='07:59:59' WHERE `shift_id`='2';