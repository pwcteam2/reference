--
-- Table structure for table `channel`
--

DROP TABLE IF EXISTS `channel`;
CREATE TABLE `channel` (
  `channel_id` int NOT NULL AUTO_INCREMENT,
  `channel_name` varchar(150) NOT NULL,
  `deleted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`channel_id`),
  UNIQUE KEY `channel_name_UNIQUE` (`channel_name`)
) ;


--
-- Table structure for table `Shift`
--

DROP TABLE IF EXISTS `shift`;
CREATE TABLE `shift` (
  `shift_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  PRIMARY KEY (`shift_id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
);


--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `role_id` int(4) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(45) NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_name_UNIQUE` (`role_name`)
);



--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(20) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50)  NOT NULL,
  `email` varchar(100)  NOT NULL,
  `sex` varchar(10)  NOT NULL,
  `employee_code` int(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `last_modified_date` datetime  NOT NULL,
  `created_date` datetime NOT NULL,
  `role_id` int NOT NULL,
  `deleted` bit(1) DEFAULT 0,
  `active` bit(1) DEFAULT 1,
  `manager_id` int(11) DEFAULT NULL ,
  PRIMARY KEY (`user_id`),
  FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`),
  FOREIGN KEY (`manager_id`) REFERENCES `user` (`user_id`)
);


--
-- Table structure for table `monitor_sheet`
--

DROP TABLE IF EXISTS `monitor_sheet`;
CREATE TABLE `monitor_sheet` (
  `monitor_id` int NOT NULL AUTO_INCREMENT,
  `channel_id` int NOT NULL,
  `program` bit(1) DEFAULT NULL,
  `audio` bit(1)  DEFAULT NULL,
  `bug` bit(1) DEFAULT NULL,
  `subtitle` bit(1) DEFAULT NULL,
  `remark` varchar(250) DEFAULT NULL,
  `user_id` int NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `shift_id` int NOT NULL,
  `deleted` bit(1) NOT NULL default 0,
  PRIMARY KEY (`monitor_id`),
  FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  FOREIGN KEY (`channel_id`) REFERENCES `channel` (`channel_id`),
  FOREIGN KEY (`shift_id`) REFERENCES `shift` (`shift_id`)
);


