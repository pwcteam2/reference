
--
-- Remove UniqueKey Constraint from Channel Name in Channel 
--

ALTER TABLE channel 
DROP INDEX channel_name_UNIQUE ;