
--
-- INSERT INTO TABLE POD
--


insert into pod(pod_name) values("GENERAL"),("AMC"),("ITX - UPCOMING");

