
--
-- Alter Sheet table add approvl date column
--


ALTER TABLE  monitor_sheet ADD approved_date TIMESTAMP NULL DEFAULT NULL;
update monitor_sheet set approved_date = modified_date;

