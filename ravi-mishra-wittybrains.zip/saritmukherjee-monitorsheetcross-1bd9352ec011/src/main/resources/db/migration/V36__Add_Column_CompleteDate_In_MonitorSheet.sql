ALTER TABLE `monitor_sheet` 
ADD COLUMN `complete_date` DATETIME NULL AFTER `shift_id`;
