ALTER TABLE `sheet_approval_detail` 
CHANGE COLUMN `approved_by` `approved_by` BIGINT(20) NULL DEFAULT NULL;
