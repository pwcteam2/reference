
--
-- Delete column from Channel tables
--
  ALTER TABLE channel drop foreign key `channel_ibfk_1`;

-- DELETE deleted,deleted_date,deleted_by
ALTER TABLE channel
  drop COLUMN  `deleted`,
  drop COLUMN `deleted_date`,
  drop COLUMN `deleted_by`;
