
--
-- Alter user employee code
--


ALTER TABLE user MODIFY column employee_code varchar(20) not null;

