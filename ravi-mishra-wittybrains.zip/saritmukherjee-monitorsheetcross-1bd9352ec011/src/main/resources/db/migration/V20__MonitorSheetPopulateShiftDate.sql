
--
-- Alter Sheet table populate shift_table
-- these changes are being added so that we can set shift date during which the entries were made


update monitor_sheet set shift_date =
(
	case when (shift_id = 2 and 
	(
		DATE_FORMAT(created_date,'%H:%i:%s')>='00:00:00' and DATE_FORMAT(created_date,'%H:%i:%s') <='05:59:00'
    )
) 
 THEN
     DATE_SUB(DATE_FORMAT(created_date, '%Y-%m-%d'), INTERVAL 1 DAY)   
 ELSE
     DATE_FORMAT(created_date, '%Y-%m-%d')
 END) ;