
--
-- Alter user update email
--


update user set email="operator2@gmail.com" where email = "operato2r@gmail.com";

