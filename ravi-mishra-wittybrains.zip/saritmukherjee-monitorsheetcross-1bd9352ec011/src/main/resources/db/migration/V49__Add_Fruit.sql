DROP TABLE IF EXISTS `fruit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fruit` (
  `fruit_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `fruit_name` varchar(255) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`fruit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `fruit` VALUES (1,'2018-12-05 16:54:59','Mango','2018-12-05 16:54:59'),(2,'2018-12-05 16:54:59','Banana','2018-12-05 16:54:59'),(3,'2018-12-05 16:54:59','Coconut','2018-12-05 16:54:59'),(4,'2018-12-05 16:54:59','Cherry','2018-12-05 16:54:59');