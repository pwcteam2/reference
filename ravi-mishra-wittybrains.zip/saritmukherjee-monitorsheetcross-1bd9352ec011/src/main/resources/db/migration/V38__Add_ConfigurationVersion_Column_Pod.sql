ALTER TABLE `pod` 
ADD COLUMN `configuration_version` BIGINT(20) NULL DEFAULT 0 AFTER `disabled`;
