
--
-- UPDATE CHANNEL 
--

-- delete all approval associated to the channel being deleted
delete sa from `sheet_approval_detail` sa 
join monitor_sheet ms on ms.sheet_approval_id = sa.sheet_approval_id
join channel c on c.channel_id = ms.channel_id
where c.pod_id = 0;

-- delete all monitor_sheet associated to the channel being deleted
delete ms from monitor_sheet ms  join channel c on c.channel_id = ms.channel_id where c.pod_id = 0;

delete from channel where pod_id=0;
-- delete no assiciated channels with pods-
delete from channel where pod_id=0;

-- after deleting non associated channels 
ALTER TABLE channel  ADD CONSTRAINT fk_pod_id  FOREIGN KEY(`pod_id`) REFERENCES pod(`pod_id`);
