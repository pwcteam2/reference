INSERT INTO `shift` (`name`, `start_time`, `end_time`) VALUES ('MORNING', '08:00', '19:59'),('NIGHT', '20:00', '07:59');
