var stompClient = null;

function setConnected(connected) {
	$("#connect").prop("disabled", connected);
	$("#disconnect").prop("disabled", !connected);
	if (connected) {
		$("#conversation").show();
	} else {
		$("#conversation").hide();
	}
	$("#userinfo").html("");
}

function connect() {
	let token = "";
	$.ajax({
        url: "oauth/token?grant_type=password&username=" + $("#name").val() + "@gmail.com&password=123456",
        type: 'POST',
        dataType: 'json',
        async:false,
        headers: {
            'Authorization': 'Basic bW9uaXRvci1jaGFubmVsOjEyMzQ1Njc4OTA='
        },
        contentType: 'application/json; charset=utf-8',
        success: function (result) {
        	token = result.access_token;
        },
        error: function (error) {
            
        }
    });
	console.log(token);
	if(!(token.length === 0 || !token.trim()))
	localStorage.setItem("mytoken", token);
	var headers = {
			Authorization: "Bearer " + localStorage.getItem("mytoken")
		    };
	console.log(headers);
	var socket = new SockJS('/monitor-cross-sheet/websocket-example?access_token=' + localStorage.getItem("mytoken"), undefined, {debug:false});
	stompClient = Stomp.over(socket);
	stompClient.debug = () => {};
	stompClient.connect({}, function(frame) {
		setConnected(true);
		console.log('Connected: ' + frame);
		stompClient.subscribe('/user/queue/fruit', function(greeting) {
			showGreeting(JSON.parse(greeting.body));
		});
		stompClient.subscribe('/app/fruit', function(greeting) {
			showGreeting(JSON.parse(greeting.body));
		});
	});
}

function disconnect() {
	if (stompClient !== null) {
		stompClient.disconnect();
	}
	setConnected(false);
	console.log("Disconnected");
}

function sendName() {
	// stompClient.send("/app/user", {}, JSON.stringify({
	// 'name' : $("#name").val()
	// }));
	stompClient.send("/app/fruit", {}, JSON.stringify($("#name").val()));
}

function showGreeting(fruits) {
	$("#userinfo").html("");
	for (let x of fruits) {
	$("#userinfo").append("<tr><td  onclick='deleteFruit(" + x.fruitId + ")'>" + x.fruitName + "</td></tr>");
	}
}

function deleteFruit(id) {
	stompClient.send("/app/deletefruit", {}, JSON.stringify(id));
}
$(function() {
	$("form").on('submit', function(e) {
		e.preventDefault();
	});
	$("#connect").click(function() {
		connect();
	});
	$("#disconnect").click(function() {
		disconnect();
	});
	$("#send").click(function() {
		sendName();
	});
});